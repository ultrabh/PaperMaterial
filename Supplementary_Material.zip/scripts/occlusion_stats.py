"""
P0-1 遮挡统计脚本 (go/no-go 决策点)
================================================================================
目的：实测"视觉不可达但声学可达"的节点对数量，决定项目是否有意义。

这个数字在选题论证中的 CP2 检查点被设为 > 5000 对，但该阈值是拍脑袋定的。
本脚本用真实数据算出真值。

输出：
  1. 三分类分布表（视觉可达/不可达 × 声学可达/不可达）
  2. 涉及的场景数与房间数
  3. 节点高度分布检查（验证 BRIR 仅在 z=1.5m 采样的影响）
  4. 按材质分类的遮挡率
  5. 频带衰减谱统计（替代任意阈值的判定方式）

用法（在 WSL 内，conda activate habitat 后运行）：
  python scripts/occlusion_stats.py --config configs/replica.yaml
  python scripts/occlusion_stats.py --config configs/replica.yaml --smoke  # 快速试跑

作者：fenzhi1
日期：2026-10-09
"""

import argparse
import json
import os
import sys
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

# ==============================================================================
# 配置
# ==============================================================================

@dataclass
class Config:
    """数据路径与参数。默认值对应 SoundSpaces 官方 Replica 布局。"""
    # 数据根路径（WSL 内路径，指向解压后的 SoundSpaces）
    # 实测：解压位置为 /root/data/soundspaces（当前 root 用户）
    data_root: str = "/root/data/soundspaces"

    # SoundSpaces 元数据与场景数据
    metadata_dir: str = "metadata"
    scene_datasets_dir: str = "scene_datasets"
    binaural_rir_dir: str = "binaural_rirs"

    # Replica 场景清单（18 个）
    replica_scenes: list = field(default_factory=lambda: [
        "frl_apartment_0", "frl_apartment_1", "frl_apartment_2",
        "frl_apartment_3", "frl_apartment_4", "frl_apartment_5",
        "apartment_0", "apartment_1", "apartment_2",
        "office_0", "office_1", "office_2", "office_3", "office_4",
        "room_0", "room_1", "room_2",
        "hotel_0",
    ])

    # 声源候选类别
    # 严格对齐 **ObjectGoal 21 类**（SoundSpaces 声学导航任务的标准物体集合），
    # 仅做类别名映射校正，不增删类别，以保持与既有工作的可比性。
    #
    # 名称校正（2026-10-10 核对 Replica 18 场景 90 个class_name）：
    #   ObjectGoal       Replica实际
    #   -----------     --------------------------
    #   plant            indoor-plant
    #   tv_monitor       tv-screen
    #   counter          countertop
    #   shower           shower-stall
    #   chest_of_drawers Replica 无此类 -> nightstand
    #   fireplace        Replica 无此类 -> 剔除
    sounding_categories: list = field(default_factory=lambda: [
        "chair", "table", "picture", "cabinet", "cushion", "sofa",
        "bed", "indoor-plant", "sink", "toilet", "stool", "towel",
        "tv-screen", "shower-stall", "bathtub", "countertop",
        "nightstand", "wardrobe", "refrigerator",
    ])

    # 遮挡体类别：能阻挡视觉与声学的物体
    occluder_categories: list = field(default_factory=lambda: [
        "wall", "door", "window", "curtain", "blinds", "bookshelf",
        "wardrobe", "cabinet", "base-cabinet", "wall-cabinet",
        "kitchen-cabinet", "fridge", "refrigerator", "shelf", "rack",
        "panel", "partition", "wall-plug", "column", "pillar",
    ])

    # 薄遮挡物：视觉阻断但声学可绕射/透射的那一类
    # （百叶窗、玻璃、薄板等）。**不按厚度过滤它们**——
    #   过滤会系统性删除研究假设最需要的样本。详见 薄遮挡物处理决策.md
    thin_occluder_categories: list = field(default_factory=lambda: [
        "window", "curtain", "blinds", "panel", "partition",
    ])

    # chord 阈值（米）—— 声波绕射过渡频率 f_c = c/(2d)
    #   d=0.15 m -> f_c ≈ 1.1 kHz：低于此频率可绕射过
    #   d=0.50 m -> f_c ≈ 343 Hz：  仅超低频可绕射
    chord_thin_m: float = 0.15
    chord_thick_m: float = 0.50

    # 实例过滤（Replica 路径使用）
    # 丢弃最大边小于此值的实例（米）。毫米级碎片对遮挡判定无意义。
    # 注意：**不按厚度过滤** —— 薄物体是声学救援的候选，见 薄遮挡物处理决策.md
    min_instance_size: float = 0.02
    skip_undefined_instances: bool = True

    # 声学频带划分（Hz）——用于频率分辨的衰减谱
    # 依据：绕射能力随频率升高而下降；玻璃/薄墙在中高频有透射通路
    freq_bands: list = field(default_factory=lambda: [
        (0, 500),      # 低频：绕射能力强，多数遮挡仍可通过
        (500, 2000),   # 中频：部分遮挡可透射
        (2000, 8000),  # 中高频：玻璃等薄材质可能透射
        (8000, 16000), # 高频：几乎完全被阻断
    ])

    # 声学可达判定的衰减阈值（dB）—— 各频带独立设定
    # 依据：-6dB 约为人耳感知阈值的一半；-12dB 为明显衰减但仍可闻
    # 设为 None 时只统计衰减谱分布，不做二元判定（推荐首次运行）
    acoustic_threshold_db: dict = field(default_factory=lambda: {
        (0, 500): 12.0,
        (500, 2000): 18.0,
        (2000, 8000): 25.0,
        (8000, 16000): 35.0,
    })

    # 网格采样间隔（m）—— 用于判断节点是否落在 BRIR 采样点上
    grid_res: float = 0.5          # Replica 为 0.5m
    # BRIR 采样点的 z 高度。
    # 实测（2026-10-10，Replica metadata/replica/*/points.txt）：
    #   17 个场景仅 1 个z 值；apartment_0 为双层（z=0.009409 与 2.709409，差 2.7m）
    #   故不做单一高度假设，改为由 load_scene_nodes 读取实际值。
    brir_heights: list = field(default_factory=lambda: [0.009409, 2.709409])
    height_tolerance: float = 0.3  # 判定"是否在采样平面附近"的容差

    # 节点间最小距离（m）—— 过滤过近的节点对（BRIR 分辨率限制）
    min_node_distance: float = 0.5

    # 射线检测采样数—— 遮挡判定的鲁棒性
    ray_samples: int = 17          # 在两点连线上采样检测

    output_dir: str = "/mnt/d/fenzhi1/outputs/p0_occlusion_stats"


# ==============================================================================
# 数据结构
# ==============================================================================

@dataclass
class Node:
    """场景图节点（对应一个物体实例）。"""
    node_id: int
    category: str
    center: np.ndarray          # (3,) 三维包围盒中心
    bbox_size: np.ndarray       # (3,) 三维尺寸
    height: float               # center[2]
    is_sounding_candidate: bool


@dataclass
class PairLabel:
    """节点对的标签统计。"""
    visual_reachable: bool
    acoustic_reachable: Optional[bool]   # None 表示未判定（未设阈值）
    attenuation_db: dict = field(default_factory=dict)  # 频带 -> 衰减量
    blocking_categories: list = field(default_factory=list)  # 遮挡物类别


@dataclass
class SceneStats:
    """单场景的统计结果。"""
    scene: str
    n_nodes: int = 0
    n_pairs: int = 0
    label_counts: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    n_nodes_near_brir_plane: int = 0
    height_stats: dict = field(default_factory=dict)
    occluder_counts: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    attenuation_spectra: list = field(default_factory=list)  # 仅 smoke 模式保留
    pair_mode: str = ""   # "sounding_to_all" | "all_to_all"（退化模式）
    degraded_no_geometry: bool = False   # 退化模式：无几何体，遮挡不可计算
    n_pairs_thin_only: int = 0   # 仅被薄遮挡物阻断的点对数（声学救援候选）
    chord_class_counts: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    chord_values: list = field(default_factory=list)
    occluder_present: list = field(default_factory=list)   # 实际命中的遮挡物类别
    occluder_absent: list = field(default_factory=list)    # 未出现在本场景的类别
    sounding_present: list = field(default_factory=list)   # 命中的发声类别


# ==============================================================================
# 几何工具
# ==============================================================================

def segment_aabb_chord(p0: np.ndarray, p1: np.ndarray,
                       center: np.ndarray, size: np.ndarray
                       ) -> Optional[Tuple[float, float]]:
    """
    线段 p0->p1 与轴对齐包围盒的相交区间（slab method）。

    返回 (t_enter, t_exit) ∈ [0,1]，即射线在盒内的参数区间；不相交返回 None。

    区间长度 t_exit - t_enter 乘以线段总长，即为 **chord**——
    声音实际需要穿过的实体厚度（米）。

    相比"沿路径采样判断点是否在盒内"，区间求交更准确：
    采样法在两个盒子之间恰好擦过时可能漏判。
    """
    half = size / 2.0
    d = p1 - p0
    t_min, t_max = 0.0, 1.0

    for axis in range(3):
        if abs(d[axis]) < 1e-9:
            # 射线平行于该轴：若起点已在盒内则整个线段都在盒内
            if abs(p0[axis] - center[axis]) > half[axis]:
                return None
        else:
            t1 = (center[axis] - half[axis] - p0[axis]) / d[axis]
            t2 = (center[axis] + half[axis] - p0[axis]) / d[axis]
            if t1 > t2:
                t1, t2 = t2, t1
            t_min = max(t_min, t1)
            t_max = min(t_max, t2)
            if t_min > t_max:
                return None
    return (t_min, t_max)


def segment_intersects_aabb(p0: np.ndarray, p1: np.ndarray,
                            center: np.ndarray, size: np.ndarray) -> bool:
    """便捷包装：只判断是否相交，不关心区间。"""
    return segment_aabb_chord(p0, p1, center, size) is not None


def ray_aabb_chord_batch(p0: np.ndarray, centers: np.ndarray,
                         center: np.ndarray, size: np.ndarray,
                         lengths: np.ndarray) -> np.ndarray:
    """
    **向量化**版本：同一个起点p0，同时对 N 个不同终点求 chord。

    这是 P0-2 能跑通的关键——naive 写法是O(N·M) 的 Python 循环，
    向量化后同一批量只需 O(M) 次 NumPy 运算。

    参数
    ----
    p0       : (3,)         射线起点（听者位置）
    centers  : (N, 3)       N 个射线终点（候选节点中心）
    center   : (3,)         障碍物包围盒中心
    size     : (3,)         障碍物包围盒尺寸
    lengths  : (N,)         每条射线的长度 |centers - p0|

    返回
    ----
    (N,) 每条射线穿过的实体厚度（米）；不相交为 0.0
    """
    half = size / 2.0
    d = centers - p0[None, :]          # (N, 3)
    safe = np.where(np.abs(d) < 1e-9, 1e-9, d)

    t_enter = np.zeros(len(centers))
    t_exit = np.ones(len(centers))
    alive = np.ones(len(centers), dtype=bool)

    for axis in range(3):
        # 平行于该轴的分量：起点若在盒外，则整条射线不相交
        par = np.abs(d[:, axis]) < 1e-9
        outside = np.abs(p0[axis] - center[axis]) > half[axis]
        alive &= ~(par & outside)

        t1 = (center[axis] - half[axis] - p0[axis]) / safe[:, axis]
        t2 = (center[axis] + half[axis] - p0[axis]) / safe[:, axis]
        lo = np.minimum(t1, t2)
        hi = np.maximum(t1, t2)

        t_enter = np.maximum(t_enter, lo)
        t_exit = np.minimum(t_exit, hi)
        alive &= t_enter <= t_exit

    chord = np.clip(t_exit - t_enter, 0.0, 1.0) * lengths
    chord[~alive] = 0.0
    return chord


def classify_chord(chord: float, cfg: "Config") -> str:
    """
    按 chord（穿过障碍物的实体厚度，米）分类遮挡物。

    阈值来自声波绕射条件 f_c = c / (2d)：
      d = 0.15 m -> f_c ≈ 1.1 kHz  （低于此频率可绕射过）
      d = 0.50 m -> f_c ≈ 343 Hz    （仅超低频可绕射）

    依据文档：`薄遮挡物处理决策.md`
    """
    if chord < cfg.chord_thin_m:
        return "薄"
    if chord < cfg.chord_thick_m:
        return "中等"
    return "厚"


def check_visual_reachability(node_a: Node, node_b: Node,
                              all_nodes: list, occluder_set: set,
                              cfg: "Config") -> Tuple[bool, list, dict]:
    """
    判断 node_a 与 node_b 之间是否被遮挡物阻断，并给出遮挡物厚度分类。

    做法：对每个潜在遮挡物，用射线-包围盒区间求交算 chord
         （声音实际穿过的实体厚度），取最大 chord 作为该点对的遮挡强度。

    返回：(是否视觉可达, 遮挡物类别列表, 遮挡详情)
      遮挡详情 = {
        "max_chord": 穿过最厚遮挡物的厚度(m)，无可达时为 0.0,
        "max_chord_class": "薄"/"中等"/"厚",
        "only_thin": 是否**仅**被薄遮挡物阻断（→ 声学救援的候选）,
        "chord_by_class": {类别: 最大 chord},
      }

    **决策依据**（见 `薄遮挡物处理决策.md`）：
      不按厚度过滤薄物体——百叶窗/玻璃/窗帘恰是"视觉阻断但声学可绕射/透射"的那一类，
      过滤掉会系统性删除研究假设最需要的样本。
      改为按 chord 分类，薄遮挡物点对即"声学可达候选集"。
    """
    seg_len = float(np.linalg.norm(node_b.center - node_a.center))
    blockers: list = []
    chord_by_class: dict = {}
    max_chord = 0.0

    for other in all_nodes:
        if other.node_id in (node_a.node_id, node_b.node_id):
            continue
        if other.category not in occluder_set:
            continue
        hit = segment_aabb_chord(node_a.center, node_b.center,
                                 other.center, other.bbox_size)
        if hit is None:
            continue
        t0, t1 = hit
        chord = (t1 - t0) * seg_len
        if chord <= 0:
            continue
        if other.category not in blockers:
            blockers.append(other.category)
        prev = chord_by_class.get(other.category, 0.0)
        if chord > prev:
            chord_by_class[other.category] = chord
        if chord > max_chord:
            max_chord = chord

    detail = {
        "max_chord": max_chord,
        "max_chord_class": classify_chord(max_chord, cfg) if max_chord > 0 else "无",
        "only_thin": bool(blockers) and all(
            classify_chord(c, cfg) == "薄" for c in chord_by_class.values()),
        "chord_by_class": chord_by_class,
    }
    return (len(blockers) == 0), blockers, detail


# ==============================================================================
# 声学分析
# ==============================================================================

def load_brir(rir_path: Path) -> np.ndarray:
    """
    加载双耳 BRIR。SoundSpaces 提供 .wav 立体声文件。
    返回 shape (2, N) 的双通道脉冲响应。
    """
    import soundfile as sf
    data, _ = sf.read(str(rir_path), dtype="float32", always_2d=True)
    return data.T  # (2, N)


def compute_band_attenuation(brir: np.ndarray, sample_rate: int,
                             freq_bands: list) -> Dict[Tuple[int, int], float]:
    """
    计算频率分辨的直达声衰减量（dB）。

    做法：对 BRIR 做频域分析，按频带累加能量，得到频带能量谱。
    衰减量定义为"直达段能量 / 混响段能量"之比。

    关键：这是对原始设计的改进——不再用单一总能量 DRR 做二元判定，
    而是保留频率维度。低频绕射强、高频几乎全阻断，频带级信息能区分
    "完全阻断"与"部分透射"（如玻璃）。

    返回：{(f_lo, f_hi): 衰减量 dB}
    """
    # FFT 域能量谱：shape (2, n_freq)
    n = brir.shape[1]
    spectrum = np.abs(np.fft.rfft(brir, axis=1)) ** 2  # (2, n_freq)

    # 直达声与混响段的分界：取前 5ms 作为直达段（按 16kHz 约 80 采样点）
    direct_end = max(8, min(int(sample_rate * 0.005), n))
    freq_bins = spectrum.shape[1]
    bin_hz = (sample_rate / 2) / freq_bins

    result = {}
    for (f_lo, f_hi) in freq_bands:
        lo_bin = max(1, int(f_lo / bin_hz))
        hi_bin = min(freq_bins, int(f_hi / bin_hz))
        if hi_bin <= lo_bin:
            result[(f_lo, f_hi)] = 0.0
            continue

        # 直达段能量（两耳平均）
        direct_energy = spectrum[:, lo_bin:hi_bin][:, :direct_end].sum()
        # 混响段能量
        reverb_energy = spectrum[:, lo_bin:hi_bin][:, direct_end:].sum()

        if reverb_energy < 1e-12:
            ratio_db = 60.0   # 无混响，视为直达主导
        else:
            ratio_db = 10.0 * np.log10(max(direct_energy, 1e-12) / reverb_energy)
        result[(f_lo, f_hi)] = float(ratio_db)
    return result


def judge_acoustic_reachability(attenuation: Dict[Tuple[int, int], float],
                                thresholds: Dict[Tuple[int, int], float]) -> Tuple[bool, float]:
    """
    基于频带衰减谱判定声学可达性。

    规则：**低频可达即视为可达**。
    依据：人耳对低频最敏感，且低频绕射能力最强（波长长，障碍物尺寸
    远小于波长时可发生显著衍射）。若低频（<500Hz）仍被完全阻断，
    则整个宽带信号都不可用。

    返回：(是否可达, 有效衰减量 dB)
    """
    low_band = (0, 500)
    if low_band not in attenuation:
        return False, 0.0
    eff = attenuation[low_band]
    return (eff >= thresholds.get(low_band, 12.0)), eff


# ==============================================================================
# 主流程
# ==============================================================================

def _resolve_scene_dir(cfg: Config) -> Path:
    """
    解析场景网格目录。

    支持两种写法：
      - 绝对路径：直接使用（推荐，可放在 /mnt/d 便于空间管理）
      - 相对路径：相对 data_root拼接

    额外探测几个常见位置，避免用户反复改配置。
    """
    raw = cfg.scene_datasets_dir
    if raw.startswith("/"):
        return Path(raw)

    cands = [
        Path(cfg.data_root) / raw,
        Path("/mnt/d/fenzhi1/data") / raw,
    ]
    for c in cands:
        if c.is_dir():
            return c
    return cands[0]


def load_scene_nodes(scene: str, cfg: Config) -> Tuple[list, dict]:
    """
    从 Replica 数据加载物体节点。

    实测结构（2026-10-10 核实，~/data/soundspaces）：
      metadata/replica/{scene}/points.txt   —— BRIR 采样点，格式 "编号 x y z"
      metadata/replica/{scene}/graph.pkl    —— 可听子集的邻接图（networkx）

    **重要**：metadata 中**没有物体级语义标注**，只有采样点。
    物体实例分割来自 scene_datasets（replica_dataset，需另行下载 ~10GB），
    格式为 {scene}.house + {scene}.semantic.txt。

    因此本函数分两条路径：
      A. 有 .house/.semantic.txt → 加载真实物体节点（完整统计）
      B. 仅有 points.txt        → 以 BRIR 采样点作为"接收端"节点，
                                  视觉遮挡判定仍可做（用采样点间射线求交），
                                  但缺少物体级语义信息。

    路径 B 的意义：**无需等 BRIR 下载即可拿到视觉遮挡比例这一核心数字**，
    它是 go/no-go 判断的一半依据。
    """
    meta_dir = Path(cfg.data_root) / cfg.metadata_dir
    scene_meta = meta_dir / "replica" / scene

    if not scene_meta.exists():
        raise FileNotFoundError(
            f"未找到场景元数据：{scene_meta}\n"
            f"请确认 config.data_root = {cfg.data_root} 且已解压 metadata.tar.xz"
        )

    # ---- 读取 BRIR 采样点（两条路径都需要）----
    points = {}
    pts_file = scene_meta / "points.txt"
    if not pts_file.exists():
        raise FileNotFoundError(f"缺少采样点文件：{pts_file}")
    with open(pts_file, "r") as f:
        for line in f:
            parts = line.split()
            if len(parts) < 4:
                continue
            idx = int(parts[0])
            points[idx] = np.array([float(parts[1]), float(parts[2]), float(parts[3])])

    info = {
        "n_brir_points": len(points),
        "brir_z_values": sorted(set(round(p[2], 6) for p in points.values())),
    }

    # ---- 尝试加载真实物体标注 ----
    # Replica 格式（2026-10-10 实测确认）：
    #   {scene_dir}/{scene}/habitat/info_semantic.json
    #     "objects": [{id, node_id, class_id, class_name,
    #                  oriented_bbox:{abb:{center:[3], sizes:[3]},
    #                                 orientation:{rotation:[4]}}}, ...]
    # 包围盒**已在 json 中给出**，不需要读 ply/ bin，也不需要 plyfile。
    scene_dir = _resolve_scene_dir(cfg)
    info_file = scene_dir / scene / "habitat" / "info_semantic.json"

    if not info_file.exists():
        # 路径 B：退化模式，用 BRIR 采样点作为节点
        info["mode"] = "brir_points_only"
        info["note"] = (
            f"未找到 {info_file}（replica_dataset 未下载或路径不对），"
            "以 BRIR 采样点作为节点。**遮挡率无法计算**——采样点不构成遮挡物。"
        )
        nodes = [
            Node(
                node_id=idx,
                category="brir_sample_point",
                center=pt,
                bbox_size=np.array([cfg.grid_res] * 3),
                height=float(pt[2]),
                is_sounding_candidate=False,   # 采样点本身不是声源
            )
            for idx, pt in points.items()
        ]
        return nodes, info

    # ---- 路径 A：真实物体标注（Replica 格式）----
    try:
        from replica_objects import load_replica_objects
        rnodes, rinfo = load_replica_objects(
            str(scene_dir), scene,
            min_size=cfg.min_instance_size,
            skip_undefined=cfg.skip_undefined_instances,
        )
    except Exception as e:                      # noqa: BLE001
        raise RuntimeError(f"加载 Replica 实例失败：{e}") from e

    if not rnodes:
        info["mode"] = "replica_objects_empty"
        info["note"] = f"{info_file} 中没有有效实例"
        nodes = [
            Node(node_id=idx, category="brir_sample_point", center=pt,
                 bbox_size=np.array([cfg.grid_res] * 3),
                 height=float(pt[2]), is_sounding_candidate=False)
            for idx, pt in points.items()
        ]
        return nodes, info

    info["mode"] = "replica_objects"
    info["replica"] = rinfo

    nodes = []
    sounding_hits = 0
    for r in rnodes:
        cat = r["class_name"]
        is_snd = cat in cfg.sounding_categories
        if is_snd:
            sounding_hits += 1
        nodes.append(Node(
            node_id=r["id"],
            category=cat,
            center=r["center"],              # 已做 z' = -z 变换
            bbox_size=r["bbox_size"],       # 真实包围盒（非占位）
            height=float(r["center"][2]),
            is_sounding_candidate=is_snd,
        ))

    info["n_raw_nodes"] = len(nodes)
    info["n_sounding"] = sounding_hits
    info["class_top10"] = rinfo["class_top10"]
    info["transform"] = rinfo["transform"]
    return nodes, info


def process_scene(scene: str, cfg: Config, smoke: bool = False) -> SceneStats:
    """对单个场景执行遮挡与声学统计。"""
    stats = SceneStats(scene=scene)
    nodes, info = load_scene_nodes(scene, cfg)
    stats.n_nodes = len(nodes)

    sounding = [n for n in nodes if n.is_sounding_candidate]
    # 退化模式检测：全部节点都是 BRIR 采样点，没有物体包围盒，
    # 此时不存在可充当遮挡物的节点，视觉遮挡判定**无法计算**。
    # 若仍按常规逻辑跑，会把全部点对判为"可达"，得出遮挡率 0% 的错误结论。
    degraded = all(n.category == "brir_sample_point" for n in nodes) and nodes
    occluder_set = set(cfg.occluder_categories)

    # 记录实际命中的遮挡物类别，便于发现类别表未覆盖的情况
    present = {n.category for n in nodes}
    stats.occluder_present = sorted(occluder_set & present)
    stats.occluder_absent = sorted(
        c for c in cfg.occluder_categories if c not in present)
    stats.sounding_present = sorted({n.category for n in nodes
                                     if n.is_sounding_candidate})

    # 高度分布统计（验证 BRIR 采样平面的影响）
    # 优先使用本场景实测的 z 值；仅当实测为空时回退到配置中的硬编码列表。
    # 这样即使某些场景的 z 值与 [0.009409, 2.709409] 不同也不会误判。
    brir_z = info.get("brir_z_values") or cfg.brir_heights
    heights = np.array([n.height for n in nodes]) if nodes else np.array([0.0])
    near_plane = np.zeros_like(heights, dtype=bool)
    for h in brir_z:
        near_plane |= (np.abs(heights - h) < cfg.height_tolerance)
    stats.n_nodes_near_brir_plane = int(near_plane.sum())
    stats.height_stats = {
        "min": float(heights.min()),
        "max": float(heights.max()),
        "mean": float(heights.mean()),
        "std": float(heights.std()),
        "frac_near_brir_plane": float(near_plane.mean()),
        "n_distinct_z": len(set(np.round(heights, 6).tolist())),
    }

    # 节点对枚举：优先"可发声候选"作为源节点。
    # 退化模式（brir_points_only）下所有节点 is_sounding_candidate=False，
    # 若仍只取 sounding 会导致节点对数为 0 —— 故此时退化为"全部节点互配对"，
    # 得到的是采样点级别的遮挡率，虽非物体级，但能反映空间的遮挡密度。
    if sounding:
        target_nodes = sounding[:20] if smoke else sounding
        pair_mode = "sounding_to_all"
    else:
        target_nodes = nodes[:20] if smoke else nodes
        pair_mode = "all_to_all"
        stats.height_stats["pair_mode_note"] = (
            "退化模式：无物体语义标注，用采样点互配对估计空间遮挡密度"
        )
    stats.pair_mode = pair_mode

    # 退化模式下无法判定遮挡（没有可充当遮挡物的几何体），
    # 只统计节点对数与距离分布，明确标注遮挡列为"不可计算"。
    if degraded:
        for i, na in enumerate(target_nodes):
            for nb in nodes:
                if na.node_id == nb.node_id:
                    continue
                if np.linalg.norm(na.center - nb.center) < cfg.min_node_distance:
                    continue
                all_pairs += 1
                stats.label_counts["不可计算_退化模式"] += 1
        stats.n_pairs = all_pairs
        stats.degraded_no_geometry = True
        return stats

    all_pairs = 0
    for i, na in enumerate(target_nodes):
        for nb in nodes:
            if na.node_id == nb.node_id:
                continue
            dist = np.linalg.norm(na.center - nb.center)
            if dist < cfg.min_node_distance:
                continue
            all_pairs += 1

            vis_reach, blockers, detail = check_visual_reachability(
                na, nb, nodes, occluder_set, cfg)
            for b in blockers:
                stats.occluder_counts[b] += 1

            # chord 分布：用于判断"仅被薄遮挡物阻断"的候选样本量
            if not vis_reach:
                stats.chord_class_counts[detail["max_chord_class"]] += 1
                if detail["only_thin"]:
                    stats.n_pairs_thin_only += 1
                # 只保留前若干个样本用于绘制分布，避免大场景下内存膨胀
                if len(stats.chord_values) < 20000:
                    stats.chord_values.append(round(detail["max_chord"], 4))

            # 声学部分（需 BRIR，smoke 模式跳过）
            acou_reach = None
            if not smoke:
                rir_path = find_brir_path(scene, na, nb, cfg)
                if rir_path is not None:
                    brir = load_brir(rir_path)
                    atten = compute_band_attenuation(brir, 16000, cfg.freq_bands)
                    acou_reach, _ = judge_acoustic_reachability(
                        atten, cfg.acoustic_threshold_db)
                    if vis_reach is False and acou_reach:
                        stats.attenuation_spectra.append(atten)

            # 统计
            if acou_reach is None:
                key = ("可听" if vis_reach else "遮挡") + "_未判定"
            else:
                key = f"{'可视' if vis_reach else '遮挡'}_{'可听' if acou_reach else '阻隔'}"
            stats.label_counts[key] += 1

    stats.n_pairs = all_pairs
    return stats


def find_brir_path(scene: str, na: Node, nb: Node, cfg: Config) -> Optional[Path]:
    """
    定位两个节点位置对应的 BRIR 文件。

    已核实的事实（2026-10-10）：
      - metadata/replica/{scene}/points.txt 给出全部 BRIR 采样点
        （apartment_0 有 566 个），编号即行首整数
      - graph.pkl 只含其中的可听子集（211 个），且节点 key 非连续
      - 坐标存在 Y-up↔Z-up 转换：graph.z = -txt.y（线性拟合残差 0）

    **尚未确认**：BRIR 文件的实际目录结构与命名规则。
    SoundSpaces 官方布局通常为：
      {binaural_rir_dir}/replica/{scene}/{angle}/{receiver}-{source}.wav
    但本项目的实际路径需以BRIR 下载后的真实文件为准。

    本实现采取"**先探测、后使用**"策略：
      首次调用时扫描场景目录，推断真实的 angle 档位与文件名格式，
      并缓存到 _BRIR_INDEX 中。探测失败则返回 None，
    此时统计脚本仅做视觉部分，且会在报告中明确标注"声学部分未执行"。

    返回 None 的三种情况：
      1. BRIR 未下载（当前状态）
      2. 探测失败（结构与预期不符）
      3. 该点对在采样网格中无对应点
    """
    idx = _BRIR_INDEX.get("scene")
    if idx != scene:
        if not _probe_brir_index(scene, cfg):
            return None
        idx = scene

    entry = _BRIR_INDEX["entry"]
    angle_dirs = entry["angles"]
    pattern = entry["pattern"]
    template = entry["template"]

    # 节点中心 -> 最近的 BRIR 采样点编号
    rid = _nearest_point_id(scene, nb.center, cfg)
    sid = _nearest_point_id(scene, na.center, cfg)
    if rid is None or sid is None:
        return None

    base = Path(cfg.data_root) / cfg.binaural_rir_dir / "replica" / scene
    for angle in angle_dirs:
        p = base / str(angle) / template.format(rid, sid)
        if p.exists():
            return p
        # 兼容顺序颠倒的命名（receiver-source / source-receiver）
        p2 = base / str(angle) / template.format(sid, rid)
        if p2.exists():
            return p2

    if pattern == "v1":
        return None
    return None


# BRIR 目录结构探测结果缓存（避免每个点对都重扫磁盘）
_BRIR_INDEX: dict = {}


def _probe_brir_index(scene: str, cfg: Config) -> bool:
    """
    探测某场景 BRIR 的实际目录结构。

    探测内容：
      1. 场景目录是否存在
      2. 其下有哪些 angle 子目录（推断档位数与命名）
      3. 随便取一个 angle 目录，看文件的命名格式（推断 {receiver}-{source} 或其他）

    探测成功返回 True 并填充 _BRIR_INDEX；失败返回 False。
    """
    _BRIR_INDEX.clear()
    _BRIR_INDEX["scene"] = scene

    # 候选根路径（不同下载包的组织方式可能不同）
    roots = [
        Path(cfg.data_root) / cfg.binaural_rir_dir / "replica" / scene,
        Path(cfg.data_root) / cfg.binaural_rir_dir / scene,
        Path(cfg.data_root) / cfg.binaural_rir_dir / "Replica" / scene,
        Path(cfg.data_root) / cfg.binaural_rir_dir / "binaural_rirs" / "replica" / scene,
    ]
    base = next((r for r in roots if r.is_dir()), None)
    if base is None:
        _BRIR_INDEX["entry"] = {
            "angles": [], "pattern": "none",
            "template": "{0}-{1}.wav", "base": None,
        }
        return False

    angle_dirs = sorted(
        [d for d in base.iterdir() if d.is_dir()],
        key=lambda d: (not d.name.isdigit(), d.name),
    )
    if not angle_dirs:
        _BRIR_INDEX["entry"] = {
            "angles": [], "pattern": "none",
            "template": "{0}-{1}.wav", "base": base,
        }
        return False

    # 探测命名格式：看第一个 angle 目录下的文件名
    template = "{0}-{1}.wav"
    try:
        sample = next(f for f in angle_dirs[0].iterdir() if f.is_file())
        name = sample.name
        # 形如 "123-456.wav" 或 "123_456.wav"
        for sep in ("-", "_"):
            if sep in name:
                head = name.split(sep)[0]
                if head.isdigit():
                    template = "{" + f"0:{sep}" + "}{" + f"1:{sep}" + "}.wav"
                    break
    except StopIteration:
        pass

    _BRIR_INDEX["entry"] = {
        "angles": [d.name for d in angle_dirs],
        "pattern": "v1" if len(angle_dirs) > 1 else "flat",
        "template": template,
        "base": base,
    }
    return True


#采样点坐标缓存： {scene: {point_id: np.array}}
_POINT_CACHE: Dict[str, Dict[int, np.ndarray]] = {}


def _load_points(scene: str, cfg: Config) -> Dict[int, np.ndarray]:
    """加载某场景的全部 BRIR 采样点坐标（含缓存）。"""
    if scene in _POINT_CACHE:
        return _POINT_CACHE[scene]
    f = Path(cfg.data_root) / cfg.metadata_dir / "replica" / scene / "points.txt"
    pts = {}
    with open(f, "r") as fh:
        for line in fh:
            parts = line.split()
            if len(parts) >= 4:
                pts[int(parts[0])] = np.array(
                    [float(parts[1]), float(parts[2]), float(parts[3])])
    _POINT_CACHE[scene] = pts
    return pts


def _nearest_point_id(scene: str, center: np.ndarray,
                      cfg: Config) -> Optional[int]:
    """
    找距给定坐标最近的 BRIR 采样点编号。

    仅在同一层楼板内匹配（z 差超过容差视为不同层，不做跨层匹配），
    因为 BRIR 在垂直方向是离散采样的。
    """
    pts = _load_points(scene, cfg)
    if not pts:
        return None

    c = np.asarray(center, dtype=float)
    best_id, best_d = None, float("inf")
    for idx, p in pts.items():
        if abs(p[2] - c[2]) > cfg.height_tolerance:
            continue
        d = float(np.sum((p - c) ** 2))
        if d < best_d:
            best_d, best_id = d, idx

    if best_id is None:
        return None
    # 超出容差3 倍网格间距视为无对应点
    if best_d > (3 * cfg.grid_res) ** 2:
        return None
    return best_id


def _summarize_chords(chords: list) -> dict:
    """汇总 chord 分布的统计量（用于判断遮挡厚度构成）。"""
    if not chords:
        return {"n": 0}
    a = np.array(chords, dtype=float)
    qs = [10, 25, 50, 75, 90]
    out = {
        "n": int(a.size),
        "mean": float(a.mean()),
        "std": float(a.std()),
        "min": float(a.min()),
        "max": float(a.max()),
        "frac_below_0.05": float((a < 0.05).mean()),
        "frac_below_0.15": float((a < 0.15).mean()),
        "frac_below_0.50": float((a < 0.50).mean()),
    }
    for q in qs:
        out[f"p{q}"] = float(np.percentile(a, q))
    return out


def aggregate(all_stats: list, cfg: Config) -> dict:
    """汇总所有场景的统计。"""
    total = defaultdict(int)
    occluder_total = defaultdict(int)
    height_fracs = []
    scenes_with_core_samples = 0
    n_nodes_all = 0
    n_near_plane = 0
    degraded_any = False
    thin_only_total = 0
    chord_class_total: Dict[str, int] = defaultdict(int)
    all_chords: list = []
    n_pairs_acoustic_measured = 0
    occluder_hit: Dict[str, int] = defaultdict(int)
    occluder_miss: Dict[str, int] = defaultdict(int)
    sounding_hit: Dict[str, int] = defaultdict(int)

    for s in all_stats:
        for k, v in s.label_counts.items():
            total[k] += v
        #统计实际完成声学判定的点对数（键中含"可听"或"阻隔"）
        n_acou = sum(v for k, v in s.label_counts.items()
                     if k.endswith("_可听") or k.endswith("_阻隔"))
        n_pairs_acoustic_measured += n_acou
        for k, v in s.occluder_counts.items():
            occluder_total[k] += v
        if s.height_stats:
            height_fracs.append(s.height_stats["frac_near_brir_plane"])
        n_nodes_all += s.n_nodes
        n_near_plane += s.n_nodes_near_brir_plane
        # 核心样本：该场景是否有"遮挡+可听"样本
        if s.label_counts.get("遮挡_可听", 0) > 0:
            scenes_with_core_samples += 1
        if s.degraded_no_geometry:
            degraded_any = True
        thin_only_total += s.n_pairs_thin_only
        for k, v in s.chord_class_counts.items():
            chord_class_total[k] += v
        all_chords.extend(s.chord_values)
        for c in s.occluder_present:
            occluder_hit[c] += 1
        for c in s.occluder_absent:
            occluder_miss[c] += 1
        for c in s.sounding_present:
            sounding_hit[c] += 1

    core = total.get("遮挡_可听", 0)
    return {
        "total_nodes": n_nodes_all,
        "total_pairs": sum(total.values()),
        "label_distribution": dict(total),
        "n_scenes": len(all_stats),
        "degraded_no_geometry": degraded_any,
        "acoustic_measured": n_pairs_acoustic_measured > 0,
        "n_pairs_acoustic_measured": n_pairs_acoustic_measured,
        "thin_only_candidates": thin_only_total,
        "chord_class_distribution": dict(chord_class_total),
        "chord_stats": _summarize_chords(all_chords),
        "occluder_hit_scenes": dict(occluder_hit),
        "occluder_miss_scenes": dict(occluder_miss),
        "sounding_hit_scenes": dict(sounding_hit),
        "n_scenes_with_core_samples": scenes_with_core_samples,
        "core_sample_count": core,
        "occluder_distribution": dict(sorted(occluder_total.items(),
                                            key=lambda x: -x[1])),
        "brir_plane_stats": {
            "frac_near_plane_mean": float(np.mean(height_fracs)) if height_fracs else 0.0,
            "n_nodes_near_plane": n_near_plane,
            "n_nodes_total": n_nodes_all,
            "interpretation": (
                "实测（2026-10-10）：Replica 的 BRIR 采样点在垂直方向是离散的——"
                "17 个场景为单层 z=0.009409，apartment_0 为双层（+2.709409）。"
                "若该占比显著低于 1.0，说明多数节点不在任何采样层上，"
                "此时三维场景图在声学侧无法直接对应到 BRIR 采样点，"
                "需考虑按物体中心自定义采样（SoundSpaces 2.0 重仿真）。"
            ),
        },
    }


def print_report(agg: dict, cfg: Config, smoke: bool) -> None:
    """打印可读的报告。"""
    print("\n" + "=" * 74)
    print("P0-1 遮挡统计报告")
    if smoke:
        print("*** SMOKE 模式：仅视觉判定，声学部分跳过 ***")
    print("=" * 74)

    print(f"\n场景数: {agg['n_scenes']}")
    print(f"节点总数: {agg['total_nodes']}")
    print(f"节点对总数: {agg['total_pairs']:,}")

    print("\n--- 三分类分布 ---")
    dist = agg["label_distribution"]
    order = ["可视_可听", "可视_未判定", "遮挡_可听", "遮挡_未判定", "遮挡_阻隔", "可视_阻隔"]
    total = max(agg["total_pairs"], 1)
    for k in order:
        if k in dist:
            pct = 100.0 * dist[k] / total
            bar = "#" * int(pct / 2)
            print(f"  {k:<14s} {dist[k]:>9,d}  ({pct:5.2f}%) {bar}")

    core = agg["core_sample_count"]
    print(f"\n--- 决策要点 ---")
    print(f"  核心评测样本（遮挡+可听）: {core:,} 对")
    print(f"  含核心样本的场景数: {agg['n_scenes_with_core_samples']} / {agg['n_scenes']}")

    # 退化模式：遮挡不可计算，不能按"0 个核心样本"解读为方向不成立
    if agg.get("degraded_no_geometry"):
        print("\n" + "!" * 70)
        print("!! 注意：本次运行处于【退化模式】，遮挡率**不可计算**")
        print("!" * 70)
        print("原因：未找到物体语义标注（scene_datasets 未下载），")
        print("      全部节点均为 BRIR 采样点，没有任何可充当遮挡物的几何体，")
        print("      因此无法判定'视觉可达/不可达'。")
        print()
        print("上方'核心样本 = 0'**不表示方向不成立**，只表示本次运行未获得该指标。")
        print()
        print("下一步：下载 Replica 场景网格后重跑")
        print("  菜单选项 10 → 下载 replica_dataset（含 info_semantic.json）")
        print("  然后菜单选项 11 → 重跑本统计")
        print("=" * 70)
        return

    # ---- chord 分布：薄遮挡物候选集 ----
    ccd = agg.get("chord_class_distribution", {})
    thin_n = agg.get("thin_only_candidates", 0)
    cs = agg.get("chord_stats", {})
    occl_total = sum(ccd.values())

    print("\n--- 遮挡物厚度构成（chord = 射线穿过的实体厚度）---")
    if occl_total > 0:
        for k in ["薄", "中等", "厚", "无"]:
            if k in ccd:
                pct = 100.0 * ccd[k] / occl_total
                bar = "#" * int(pct / 2)
                print(f"  {k:<6s} {ccd[k]:>9,d}  ({pct:5.2f}%) {bar}")
        print(f"\n  阈值: 薄< {cfg.chord_thin_m}m | 厚> {cfg.chord_thick_m}m"
              f"  (依据 f_c = c/(2d))")
    if cs.get("n"):
        print(f"\n  chord 分布 (n={cs['n']}):")
        print(f"    中位 {cs['p50']:.3f} m | 均值 {cs['mean']:.3f} ± {cs['std']:.3f}")
        print(f"    分位: p10={cs['p10']:.3f}  p25={cs['p25']:.3f}  "
              f"p75={cs['p75']:.3f}  p90={cs['p90']:.3f}")
        print(f"    <0.05m: {cs['frac_below_0.05']*100:.1f}%  "
              f"<0.15m: {cs['frac_below_0.15']*100:.1f}%  "
              f"<0.50m: {cs['frac_below_0.50']*100:.1f}%")

    print(f"\n--- 声学救援候选集（BRIR 未下载时的上界估计）---")
    print(f"  仅被薄遮挡物阻断的点对: {thin_n:,} 对")
    print(f"  含义: 这些点对视觉不可达，但障碍物足够薄，低频声波可能绕射而过。")
    print(f"  **这是上界** —— BRIR 到位后才能得到真实可达数。")

    if thin_n == 0:
        print("\n  ⚠️ 无薄遮挡候选样本。可能原因：")
        print("· 场景开阔，隔断少")
        print("     · occluder_categories 未覆盖实际类别（见上方类别命中情况）")
    elif thin_n < 1000:
        print("\n  ⚠️ 候选样本偏低（<1000）。建议：放宽 chord_thin_m 或换场景")
    elif thin_n <= 5000:
        print(f"\n  ○ 候选样本中等（{thin_n}）。可做，BRIR 后再看真实可达数")
    else:
        print(f"\n  ● 候选样本充足（{thin_n} > 5000）")

    # 「核心样本」= 遮挡且声学可达。BRIR 未下载时 `core` 恒为 0，
    # 此时**不能**据此判定方向不成立——那只是"该指标未测量"。
    # 改用「薄遮挡候选数」这一BRIR 无关的上界作为判据。
    acoustic_measured = agg.get("acoustic_measured", False)

    if not acoustic_measured:
        print("\n" + "-" * 70)
        print("【注】'核心样本（遮挡+可听）' = 0，是因为 BRIR 尚未下载，")
        print("      声学可达性**未测量**，而非'测得不可达'。")
        print("      本次有效的判据是上面的'薄遮挡候选数'。")
        print("-" * 70)
    elif core == 0:
        print("\n  ⚠️ 结论：无核心样本。声学可达数已实测为 0，")
        print("     该方向在当前数据与配置下不成立，需调整采样或换数据集。")
    elif core < 1000:
        print(f"\n  ⚠️ 结论：样本量偏低（<1000）。建议：")
        print(f"     - 放宽声学阈值，或改用 SoundSpaces 2.0 自定义采样")
        print(f"     - 考虑只保留高频可透射的材质（玻璃、薄墙）作为正样本")
    elif core < 5000:
        print(f"\n  △ 结论：样本量中等（1000-5000）。可做，但泛化实验需谨慎设计。")
    else:
        print(f"\n  ✅ 结论：样本量充足（>{5000}），方向可行。")

    print("\n--- 遮挡物类别分布 ---")
    if agg["occluder_distribution"]:
        for k, v in list(agg["occluder_distribution"].items())[:8]:
            print(f"  {k:<24s} {v:>9,d}")
    else:
        print("  （无数据）")

    # 类别表覆盖情况：确认 occluder_categories 与 sounding_categories 是否完备
    hit = agg.get("occluder_hit_scenes", {})
    miss = agg.get("occluder_miss_scenes", {})
    snd = agg.get("sounding_hit_scenes", {})
    if hit or miss:
        print(f"\n--- 类别表覆盖情况（{agg['n_scenes']} 个场景中出现的场景数）---")
        if hit:
            print(f"  遮挡物类别命中:{sorted(hit.items(), key=lambda kv: -kv[1])}")
        if miss:
            # 只列出**所有场景都没出现**的类别。
            # 部分场景缺失是正常的（该场景确实无此类），不应提示用户。
            never = sorted(c for c, n in miss.items()
                           if n == agg["n_scenes"])
            partial = {c: n for c, n in miss.items()
                       if n < agg["n_scenes"]}
            if never:
                print(f"  全部场景均未出现: {never}")
                print("    （Replica 可能无此类，可从配置移除以免误导）")
            if partial:
                txt = ", ".join(f"{c} {n}/{agg['n_scenes']}"
                                for c, n in sorted(partial.items()))
                print(f"  仅部分场景出现  : {txt}")
            print(f"    （统计口径：{agg['n_scenes']} 个场景中有多少个含该类别）")
        if snd:
            print(f"  发声候选命中     : {sorted(snd.items(), key=lambda kv: -kv[1])}")
        else:
            print("  ** 发声候选一个都没命中**")
            print("     → sounding_categories 的名称可能与 Replica 的 class_name 不符")
            print("     → 需要核对 Replica 的实际类别名（见数据实测记录）")

    bp = agg["brir_plane_stats"]
    print("\n--- BRIR 采样平面影响检查 ---")
    print(f"  节点总数: {bp['n_nodes_total']}")
    print(f"  落在 BRIR 采样层上的节点数: {bp['n_nodes_near_plane']}")
    print(f"  占比: {bp['frac_near_plane_mean'] * 100:.1f}%")
    print(f"  含义: {bp['interpretation']}")

    if bp["frac_near_plane_mean"] < 0.6:
        print("\n  ⚠️ 多数节点远离采样层 —— 建议评估用 SoundSpaces 2.0 重仿真。")

    print("\n" + "=" * 74)


def main():
    # 输出重定向到文件/管道时，Python 会缓冲 stdout，导致进度不可见。
    # 强制行缓冲，保证进度实时显示（也不影响写文件）。
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except Exception:       # noqa: BLE001  （Python < 3.7 无此方法）
        pass

    parser = argparse.ArgumentParser(description="P0-1 遮挡统计")
    parser.add_argument("--config", type=str, default=None, help="配置文件 YAML")
    parser.add_argument("--data-root", type=str, default=None, help="覆盖 data_root")
    parser.add_argument("--output-dir", type=str, default=None, help="覆盖输出目录")
    parser.add_argument("--smoke", action="store_true",
                        help="快速试跑：只算视觉判定，每场景限 20 个节点")
    args = parser.parse_args()

    cfg = Config()
    if args.config:
        import yaml
        with open(args.config, "r", encoding="utf-8") as f:
            for k, v in (yaml.safe_load(f) or {}).items():
                if hasattr(cfg, k):
                    setattr(cfg, k, v)
    if args.data_root:
        cfg.data_root = args.data_root
    if args.output_dir:
        cfg.output_dir = args.output_dir

    print(f"数据根路径: {cfg.data_root}")
    print(f"场景数: {len(cfg.replica_scenes)}")
    print(f"模式: {'SMOKE' if args.smoke else '完整'}")

    all_stats = []
    for i, scene in enumerate(cfg.replica_scenes, 1):
        try:
            s = process_scene(scene, cfg, smoke=args.smoke)
            all_stats.append(s)
            print(f"[{i:2d}/{len(cfg.replica_scenes)}] {scene:<20s} "
                  f"nodes={s.n_nodes:<5d} pairs={s.n_pairs:<7d} "
                  f"core={s.label_counts.get('遮挡_可听', 0)}")
        except FileNotFoundError as e:
            print(f"[{i:2d}/{len(cfg.replica_scenes)}] {scene:<20s} 跳过（数据缺失）")
            print(f"      {e}")
        except Exception as e:  # noqa
            print(f"[{i:2d}/{len(cfg.replica_scenes)}] {scene:<20s} 错误: {e}")
            import traceback
            traceback.print_exc()

    if not all_stats:
        print("\n所有场景均失败。请检查数据路径。")
        return

    agg = aggregate(all_stats, cfg)
    print_report(agg, cfg, args.smoke)

    # 注意：dataclasses.asdict 不能直接用于含 defaultdict 的 dataclass
    # （defaultdict 是 dict 子类，asdict 的类型分派不识别它，会抛
    #  "TypeError: first argument must be callable or None"）。
    # 故手工构造 dict。
    def _scene_to_dict(s: SceneStats) -> dict:
        return {
            "scene": s.scene,
            "n_nodes": s.n_nodes,
            "n_pairs": s.n_pairs,
            "pair_mode": s.pair_mode,
            "degraded_no_geometry": s.degraded_no_geometry,
            "n_pairs_thin_only": s.n_pairs_thin_only,
            "chord_class_counts": dict(s.chord_class_counts),
            "occluder_present": s.occluder_present,
            "occluder_absent": s.occluder_absent,
            "sounding_present": s.sounding_present,
            "label_counts": dict(s.label_counts),
            "n_nodes_near_brir_plane": s.n_nodes_near_brir_plane,
            "height_stats": s.height_stats,
            "occluder_counts": dict(s.occluder_counts),
        }

    out = Path(cfg.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    suffix = "_smoke" if args.smoke else ""
    with open(out / f"occlusion_stats{suffix}.json", "w", encoding="utf-8") as f:
        json.dump({
            "config": {
                "data_root": cfg.data_root,
                "grid_res": cfg.grid_res,
                "brir_heights": cfg.brir_heights,
                "height_tolerance": cfg.height_tolerance,
                "min_node_distance": cfg.min_node_distance,
                "ray_samples": cfg.ray_samples,
                "n_scenes": len(cfg.replica_scenes),
            },
            "aggregate": agg,
            "per_scene": [_scene_to_dict(s) for s in all_stats],
        }, f, ensure_ascii=False, indent=2)
    print(f"\n结果已保存: {out / f'occlusion_stats{suffix}.json'}")


if __name__ == "__main__":
    main()