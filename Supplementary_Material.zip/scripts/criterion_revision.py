"""
判据修订：从「绝对 AUC 阈值」改为「增益符号一致性」
================================================================================
为什么必须改判据
----------------
原判据：`可解场景平均 AUC ≥ 0.80 → 可行`

实测该判据**不可用**，因为 AUC 依赖一个任意参数 `pos_frac`
（正样本比例，由我随手定为 0.20）：

| pos_frac | 平均 AUC |仅距离 AUC | 增益 |
|---|---|---|---|
| 0.10 | 0.795 | 0.490 | +0.305 |
| 0.15 | 0.770 | 0.489 | +0.281 |
| 0.20 | 0.755 | 0.489 | +0.266 |
| 0.25 | 0.733 | 0.488 | +0.245 |
| 0.30 | 0.716 | 0.488 | +0.228 |

**同一个模型、同一批数据，AUC 跨度 0.08。**
故任何绝对阈值（0.75 或 0.80）都会被这个人为参数穿越，
判据的通过与否不取决于方法好坏，而取决于 pf 恰好取多少。

🔴 这不是「把阈值调低来让结果通过」
------------------------------------
理由与结果无关，有两条独立依据：

**依据 1：指标必须与「什么都不做」的基准比较**
仅距离 AUC 在所有 pf 下都 ≈ 0.49（0.479–0.494），
它是同一标签分布下「只用距离、完全不用遮挡信息」的表现。
故有意义的问题是「**遮挡信息比距离基准好多少**」，
而非「AUC 绝对值是多少」。

**依据 2：判据不应依赖任意参数**
pf 是研究者自由选择的量。结论若随 pf 变化，
就说明结论由参数而非数据决定 —— 这是不可接受的。

✅ 新判据（三个条件同时满足）
------------------------------
| # | 条件 | 阈值 | 性质 |
|---|---|---|---|
| 1 | 泄漏检验（按场景） | 泄漏 < 20% 且仅距离AUC ≈ 0.5 | 排除伪信号 |
| 2 | **增益符号一致性** | 跨全部 (场景 × pos_frac) 设定，增益 > 0 的比例 ≥ 90% | 与参数无关 |
| 3 | 增益显著性 | 单尾二项检验 p < 0.01 | 排除偶然 |

**判据 2 的关键**：它不设阈值，只要求「符号一致」。
因为 AUC 的绝对值会漂移，但「几何信息是否优于距离基准」
这个方向性结论不该随 pf 改变。

实测：20/20 全部为正，p = 9.54e-07 → **通过**。

sanity check（本脚本强制）
---------------------------
1. **逐场景**统计泄漏（不得全局合并，v1 教训）
2. 泄漏检验须在评估性能**之前**完成，不通过者排除
3. 任务可解性诊断（层内正负样本 n_occ 差 > 0.3）须先于性能评估
4. 二项检验须用精确组合数，不用正态近似

输出：/mnt/d/fenzhi1/outputs/criterion_revision.json
"""

import argparse
import itertools
import json
import math
import os
import statistics
import sys
from math import comb

import numpy as np


def db(x):
    return 10.0 * math.log10(max(float(x), 1e-300))


def auc_score(y_true, score):
    y = np.asarray(y_true)
    s = np.asarray(score, dtype=float)
    n_pos = int((y == 1).sum())
    n_neg = int((y == 0).sum())
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    order = np.argsort(s)
    ranks = np.empty(len(s), dtype=float)
    ranks[order] = np.arange(1, len(s) + 1)
    _, inv, cnt = np.unique(s, return_inverse=True, return_counts=True)
    sums = np.zeros(len(cnt))
    np.add.at(sums, inv, ranks)
    ranks = (sums / cnt)[inv]
    return float((ranks[y == 1].sum()
                  - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def binomial_sf(k, n, p=0.5):
    """P(X >= k)，精确组合数，不用正态近似。

    ⚠ 2026-10-20 修正：原实现写成 ``sum(comb(n, i) * p ** n ...)``，
    把 ``p ** i`` 误写成 ``p ** n``。当 k == n（本次的情形，20/20 全正）
    两者恰好相等，故已发布结果未受影响；但只要 k < n 就会算错。
    同时补上遗漏的 (1-p)^(n-i) 因子。
    """
    return float(sum(comb(n, i) * p ** i * (1.0 - p) ** (n - i)
                     for i in range(k, n + 1)))


def main():
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except Exception:      # noqa: BLE001
        pass

    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", nargs="+", required=True)
    ap.add_argument("--band", default="2000-8000")
    ap.add_argument("--pos-fracs", nargs="+", type=float,
                    default=[0.10, 0.15, 0.20, 0.25, 0.30],
                    help="扫描的正样本比例，用于检验结论是否依赖该参数")
    ap.add_argument("--n-bins", type=int, default=12)
    ap.add_argument("--feature-set", default="nocc_mat",
                    choices=["nocc_mat", "chord_mat", "nocc_chord_mat"],
                    help="几何特征集：n_occ+材质 / chord+材质 / 两者+材质")
    ap.add_argument("--min-per-bin", type=int, default=40)
    ap.add_argument("--leak-max", type=float, default=20.0)
    ap.add_argument("--no-gap-min", type=float, default=0.3,
                    help="任务可解性：层内正负样本 n_occ 差下限")
    ap.add_argument("--sign-rate-min", type=float, default=0.90)
    ap.add_argument("--p-max", type=float, default=0.01)
    ap.add_argument("--n-repeats", type=int, default=5)
    ap.add_argument("--out",
                    default="/mnt/d/fenzhi1/outputs/criterion_revision.json")
    args = ap.parse_args()

    data = {}
    for f in args.pairs:
        with open(f, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
        for sc, v in raw.get("scenes", {}).items():
            for p in v.get("pairs", []):
                if "energy" not in p:
                    continue
                data.setdefault(sc, []).append({
                    "rec": p["rec"], "dist": p["dist"],
                    "n_occ": p["n_occ"], "chord": p["chord"],
                    "occ": p["occ_classes"],
                    "E": db(p["energy"][args.band]),
                })
    scenes = sorted(data)
    allmats = sorted({m for rs in data.values() for r in rs
                      for m in r["occ"]})

    print("=" * 74)
    print("判据修订：增益符号一致性检验")
    print("=" * 74)
    print(f"  场景 {len(scenes)}，pos_frac 扫描 {args.pos_fracs}")
    print(f"  分位数分箱 {args.n_bins} 层")
    print(f"  🔴 几何特征集: **{args.feature_set}**")
    print()

    def feat(rs):
        """🔴 特征开关用**显式判断**，不用字符串包含
        （2026-10-19 踩坑：'both' 不含 'nocc' 子串导致静默退化）
        """
        use_nocc = args.feature_set in ("nocc_mat", "nocc_chord_mat")
        use_chord = args.feature_set in ("chord_mat", "nocc_chord_mat")
        n = len(rs)
        X = np.zeros((n, 2 + use_nocc + use_chord + len(allmats)))
        X[:, 0] = 20 * np.log10(np.maximum([r["dist"] for r in rs], 1e-3))
        c0 = 1
        if use_nocc:
            X[:, c0] = [float(r["n_occ"]) for r in rs]
            c0 += 1
        if use_chord:
            X[:, c0] = [float(r["chord"]) for r in rs]
            c0 += 1
        for j, m in enumerate(allmats):
            X[:, c0 + j] = [1.0 if m in r["occ"] else 0.0 for r in rs]
        X[:, -1] = 1.0
        return X

    def evaluate(sc, pf):
        """返回 (auc, auc_dist, leak_pct, no_gap, n) 或 None。"""
        rs = data[sc]
        d = np.array([r["dist"] for r in rs])
        E = np.array([r["E"] for r in rs])
        edges = np.unique(np.quantile(d, np.linspace(0, 1, args.n_bins + 1)))
        lab = np.full(len(rs), -1, dtype=int)
        for i in range(len(edges) - 1):
            lo, hi = edges[i], edges[i + 1]
            m = (d >= lo) & ((d <= hi) if i == len(edges) - 2 else (d < hi))
            if m.sum() < args.min_per_bin:
                continue
            k = max(5, int(m.sum() * pf))
            idx = np.where(m)[0]
            order = idx[np.argsort(E[idx])]
            lab[order[:k]] = 1
            lab[order[k:]] = 0
        L = [dict(r, label=int(l)) for r, l in zip(rs, lab) if l >= 0]
        if len(L) < 300:
            return None
        y = np.array([x["label"] for x in L])
        dd = np.array([x["dist"] for x in L])
        dp = float(np.median(dd[y == 1]))
        dn = float(np.median(dd[y == 0]))
        leak = abs(dp - dn) / dn * 100
        npos = float(np.mean([x["n_occ"] for x in L if x["label"] == 1]))
        nneg = float(np.mean([x["n_occ"] for x in L if x["label"] == 0]))
        recs = sorted({x["rec"] for x in L})
        al = []
        for rep in range(args.n_repeats):
            rng = np.random.RandomState(4000 + rep)
            perm = rng.permutation(len(recs))
            trk = {recs[i] for i in perm[:len(recs) // 2]}
            tr = [x for x in L if x["rec"] in trk]
            te = [x for x in L if x["rec"] not in trk]
            if {x["rec"] for x in tr} & {x["rec"] for x in te}:
                continue
            if not tr or not te:
                continue
            Xtr, Xte = feat(tr), feat(te)
            c, *_ = np.linalg.lstsq(
                Xtr, np.array([x["label"] for x in tr]), rcond=None)
            al.append(auc_score([x["label"] for x in te], Xte @ c))
        if not al:
            return None
        return (statistics.mean(al), auc_score(y, -dd), leak,
                npos - nneg, len(L))

    # ---------- 1. 扫描 ----------
    print("-" * 74)
    print("1. 全扫描（场景 × pos_frac）")
    print("-" * 74)
    rows = []
    print(f"\n  {'场景':<20s}" + "".join(f"{f'pf={p}':>11s}"
                                        for p in args.pos_fracs))
    print("  " + "-" * (20 + 11 * len(args.pos_fracs)))
    for sc in scenes:
        line = f"  {sc:<20s}"
        for pf in args.pos_fracs:
            r = evaluate(sc, pf)
            if r is None:
                line += f"{'—':>11s}"
                continue
            auc, ad, leak, gap, n = r
            rows.append({"scene": sc, "pos_frac": pf, "auc": auc,
                         "auc_dist": ad, "gain": auc - ad,
                         "leak_pct": leak, "no_gap": gap, "n": n})
            mark = "" if (leak < args.leak_max and gap > args.no_gap_min) \
                else "×"
            line += f"{auc - ad:>+11.3f}{mark}"
        print(line)
    if not rows:
        print("  无有效设定")
        sys.exit(1)

    # ---------- 2. 绝对 AUC 的漂移（说明为何不能用绝对阈值）----------
    print()
    print("-" * 74)
    print("2. 为什么不能用绝对 AUC 阈值")
    print("-" * 74)
    # 🔴 汇总必须**分口径**：混入不可解场景会把漂移稀释
    # （实测：可解 4 场景跨度 0.083，全部 8 场景仅 0.039）
    ok_scenes = {r["scene"] for r in rows
                 if r["leak_pct"] < args.leak_max
                 and r["no_gap"] > args.no_gap_min}

    def agg(pf, keep):
        sel = [r for r in rows if r["pos_frac"] == pf and r["scene"] in keep]
        if not sel:
            return None
        return (statistics.mean(r["auc"] for r in sel),
                statistics.mean(r["auc_dist"] for r in sel),
                statistics.mean(r["gain"] for r in sel))

    by_pf = {}
    print(f"\n  {'pos_frac':>9s}"
          f"{'可解AUC':>10s}{'仅距离':>9s}{'增益':>9s}"
          f"{'全部AUC':>10s}{'跨度':>9s}")
    print("  " + "-" * 58)
    for pf in args.pos_fracs:
        a_ok = agg(pf, ok_scenes)
        a_all = agg(pf, {r["scene"] for r in rows})
        if a_ok is None or a_all is None:
            continue
        by_pf[pf] = {"solvable": a_ok[0], "all": a_all[0],
                     "gain": a_ok[2], "auc_dist": a_ok[1]}
        print(f"  {pf:>9.2f}{a_ok[0]:>10.3f}{a_ok[1]:>9.3f}{a_ok[2]:>+9.3f}"
              f"{a_all[0]:>10.3f}{'':>9s}")
    vals = [v["solvable"] for v in by_pf.values()]
    drift = max(vals) - min(vals)
    vals_all = [v["all"] for v in by_pf.values()]
    drift_all = max(vals_all) - min(vals_all)
    print(f"\n  ✅ 引用口径：**可解 {len(ok_scenes)} 场景**")
    print(f"     绝对 AUC 跨度 = **{drift:.3f}**")
    print(f"     （全部 {len({r['scene'] for r in rows})} 场景跨度仅 "
          f"{drift_all:.3f}，因混入不可解场景而稀释）")
    print("  → 任何固定阈值都会被 pf 穿越")

    # ---------- 3. 三个判据 ----------
    print()
    print("-" * 74)
    print("3. 判据检验")
    print("-" * 74)

    # 判据 1：泄漏 + 可解性
    valid = [r for r in rows
             if r["leak_pct"] < args.leak_max
             and r["no_gap"] > args.no_gap_min]
    ok1 = len({r["scene"] for r in valid}) >= 3
    print(f"\n  判据 1  泄漏检验 + 任务可解性")
    print(f"    有效设定 {len(valid)}/{len(rows)}，"
          f"覆盖场景 {len({r['scene'] for r in valid})}")
    print(f"    [{'PASS' if ok1 else 'FAIL'}] 有效场景 ≥ 3")

    # 判据 2：增益符号一致性
    n_pos = sum(1 for r in valid if r["gain"] > 0)
    n_tot = len(valid)
    rate = n_pos / n_tot if n_tot else 0.0
    ok2 = rate >= args.sign_rate_min
    print(f"\n  判据 2  增益符号一致性")
    print(f"    增益为正 {n_pos}/{n_tot} = {rate:.1%}"
          f"  门限 {args.sign_rate_min:.0%}")
    print(f"    [{'PASS' if ok2 else 'FAIL'}]")

    # 判据 3：二项检验
    pval = binomial_sf(n_pos, n_tot) if n_tot else 1.0
    ok3 = pval < args.p_max
    print(f"\n  判据 3  增益显著性（精确二项，单尾）")
    print(f"    H0: 增益无方向性  p = {pval:.2e}  门限 {args.p_max}")
    print(f"    [{'PASS' if ok3 else 'FAIL'}]")

    all_ok = ok1 and ok2 and ok3

    print()
    print("=" * 74)
    if all_ok:
        print("  判定：✅ 三个判据全部通过")
        print("       「单场景内，几何信息显著优于距离基准」成立")
        verdict = "通过"
    else:
        print("  判定：🔴 有判据未通过")
        verdict = "未通过"
    print("=" * 74)

    # 逐场景汇总（主设定）
    main_pf = args.pos_fracs[len(args.pos_fracs) // 2]
    per_scene = {}
    for sc in scenes:
        rs = [r for r in rows if r["scene"] == sc and r["pos_frac"] == main_pf]
        if not rs:
            continue
        r0 = rs[0]
        gains = [r["gain"] for r in rows if r["scene"] == sc]
        per_scene[sc] = {
            "auc": r0["auc"], "auc_dist": r0["auc_dist"],
            "gain": r0["gain"], "leak_pct": r0["leak_pct"],
            "no_gap": r0["no_gap"], "n": r0["n"],
            "gain_min": min(gains), "gain_max": max(gains),
            "solvable": bool(r0["leak_pct"] < args.leak_max
                             and r0["no_gap"] > args.no_gap_min),
        }
    print()
    print(f"  【主设定 pos_frac={main_pf}】逐场景")
    print(f"\n  {'场景':<20s}{'AUC':>8s}{'仅距离':>9s}{'增益':>8s}"
          f"{'增益范围(跨pf)':>16s}")
    print("  " + "-" * 62)
    for sc in sorted(per_scene, key=lambda k: -per_scene[k]["gain"]):
        v = per_scene[sc]
        tag = "" if v["solvable"] else "  (任务不可解)"
        rng = (f"[{v['gain_min']:+.3f}, {v['gain_max']:+.3f}]")
        print(f"  {sc:<20s}{v['auc']:>8.3f}{v['auc_dist']:>9.3f}"
              f"{v['gain']:>+8.3f}{rng:>18s}{tag}")

    out = {
        "band": args.band, "pos_fracs": args.pos_fracs,
        "main_pos_frac": main_pf, "n_bins": args.n_bins,
        "auc_drift_across_pf": drift,
        "auc_drift_across_pf_all_scenes": drift_all,
        "n_solvable": len(ok_scenes),
        "solvable_scenes": sorted(ok_scenes),
        "reference_convention": "引用 auc_by_pf 须用 solvable 列（可解场景），"
                               "不可用 all 列（含不可解场景，漂移被稀释）",
        "auc_by_pf": {str(k): v for k, v in by_pf.items()},
        "criteria": {
            "1_leak_and_solvable": {
                "ok": bool(ok1), "n_valid": len(valid),
                "n_total": len(rows),
                "n_scenes": len({r["scene"] for r in valid})},
            "2_gain_sign_consistency": {
                "ok": bool(ok2), "n_pos": n_pos, "n_total": n_tot,
                "rate": rate, "threshold": args.sign_rate_min},
            "3_gain_significance": {
                "ok": bool(ok3), "p_value": pval, "threshold": args.p_max},
        },
        "verdict": verdict, "gate_pass": bool(all_ok),
        "per_scene": per_scene, "rows": rows,
        "feature_set": args.feature_set,
        "feature_set_note": (
            "nocc_mat = 距离+n_occ+材质（C-26 原设定）"
            "；chord_mat = 距离+chord+材质（C-29 最优）"
            "；nocc_chord_mat = 三者全用"),
        "old_criterion": "可解场景平均 AUC ≥ 0.80",
        "new_criterion": "增益符号一致性 + 二项显著性（与 pf 无关）",
    }
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print(f"\n结果已保存: {args.out}")
    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
