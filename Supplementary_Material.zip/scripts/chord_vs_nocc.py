"""
C-21 推翻条件验证：场景内 chord vs n_occ
================================================================================
要检验什么
------------
C-21（2026-10-19 修正版）声称：

| 设定 | 特征排序 |
|---|---|
| 跨场景 | n_occ > 材质 > chord（chord 无效，R² 降 0.100） |
| **单场景内分层** | **chord > n_occ**（3/4 场景单调，效应达 7 dB） |

C-21 写下的**推翻条件**：
> 若在场景内用 chord 替换 n_occ 后分类增益未提升，
> 则「chord 在场景内更优」不成立。

🔴 三种可能，必须区分
--------------------
| 结果 | 含义 |
|---|---|
| chord 替换后增益提升 | ✅ 「chord 在场景内更优」成立 |
| 增益不变 | ⚠️ chord 只是 n_occ 的**冗余代理**，两者信息等价 |
| **增益下降** | ❌ chord 是**噪声**，之前的分层分析有偏 |

第三种必须能识别——因为**分层分析只看单调性，
不检验「在已有 n_occ 的前提下 chord 是否还有增量」**。

🔴 评估设定（与 criterion_revision 完全一致）
------------------------------------------------
1. 距离分层 + 每层等比例标签（matched design）
2. 按 rec 划分（测试 rec 未在训练出现）
3. 泄漏检验逐场景
4. 任务可解性诊断（层内正负样本 n_occ 差 > 0.3）

**唯一变量**：特征集。其余全部固定。

sanity check
------------
1. 测试 rec 零重叠（代码断言）
2. 泄漏逐场景，不通过者排除
3. **逐场景评估有效**（场景间增益须有差异，防混算）
4. 报告每场景的改善幅度，而不只报均值

输出：/mnt/d/fenzhi1/outputs/chord_vs_nocc.json
"""

import argparse
import json
import math
import os
import statistics
import sys

import numpy as np


def db(x):
    return 10.0 * math.log10(max(float(x), 1e-300))


def auc_score(y_true, score):
    y = np.asarray(y_true)
    s = np.asarray(score, dtype=float)
    n_pos = int((y == 1).sum())
    n_neg = int((y == 0).sum())
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    order = np.argsort(s)
    ranks = np.empty(len(s), dtype=float)
    ranks[order] = np.arange(1, len(s) + 1)
    _, inv, cnt = np.unique(s, return_inverse=True, return_counts=True)
    sums = np.zeros(len(cnt))
    np.add.at(sums, inv, ranks)
    ranks = (sums / cnt)[inv]
    return float((ranks[y == 1].sum()
                  - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def main():
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except Exception:      # noqa: BLE001
        pass

    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", nargs="+", required=True)
    ap.add_argument("--band", default="2000-8000")
    ap.add_argument("--n-bins", type=int, default=12)
    ap.add_argument("--pos-frac", type=float, default=0.20)
    ap.add_argument("--min-per-bin", type=int, default=40)
    ap.add_argument("--n-repeats", type=int, default=5)
    ap.add_argument("--out",
                    default="/mnt/d/fenzhi1/outputs/chord_vs_nocc.json")
    args = ap.parse_args()

    data = {}
    for f in args.pairs:
        with open(f, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
        for sc, v in raw.get("scenes", {}).items():
            for p in v.get("pairs", []):
                if "energy" not in p:
                    continue
                data.setdefault(sc, []).append({
                    "rec": p["rec"], "dist": p["dist"],
                    "n_occ": p["n_occ"], "chord": p["chord"],
                    "occ": p["occ_classes"],
                    "E": db(p["energy"][args.band]),
                })
    scenes = sorted(data)
    mats = sorted({m for rs in data.values() for r in rs
                   for m in r["occ"]})
    print("=" * 74)
    print("C-21 推翻条件验证：场景内 chord vs n_occ")
    print("=" * 74)
    print(f"  场景 {len(scenes)}，频带 {args.band}")
    print(f"  设定：距离分层 {args.n_bins} 层 + 每层等比例 {args.pos_frac}")
    print()

    def make_labels(rs):
        d = np.array([r["dist"] for r in rs])
        E = np.array([r["E"] for r in rs])
        edges = np.unique(np.quantile(d, np.linspace(0, 1, args.n_bins + 1)))
        lab = np.full(len(rs), -1, dtype=int)
        used = 0
        for i in range(len(edges) - 1):
            lo, hi = edges[i], edges[i + 1]
            m = (d >= lo) & ((d <= hi) if i == len(edges) - 2
                             else (d < hi))
            if m.sum() < args.min_per_bin:
                continue
            k = max(5, int(m.sum() * args.pos_frac))
            idx = np.where(m)[0]
            order = idx[np.argsort(E[idx])]
            lab[order[:k]] = 1
            lab[order[k:]] = 0
            used += 1
        return [dict(r, label=int(l)) for r, l in zip(rs, lab) if l >= 0], used

    # 🔴 显式三元组 (n_occ, chord, 材质)，不用字符串匹配
    #   （曾因 'both' 不含 'nocc' 字符串而静默退化成「仅距离」）
    VARIANTS = [
        ("仅距离",              (False, False, False)),
        ("距离+n_occ",          (True,  False, False)),
        ("距离+chord",          (False, True,  False)),
        ("距离+n_occ+chord",    (True,  True,  False)),
        ("距离+n_occ+材质",     (True,  False, True)),
        ("距离+chord+材质",     (False, True,  True)),
        ("全部",                (True,  True,  True)),
    ]

    def feat2(rs, flags):
        """🔴 显式分配二维数组，避免列维度不一致（曾踩坑）。"""
        has_nocc, has_chord, has_mat = flags
        n = len(rs)
        X = np.zeros((n, 1 + has_nocc + has_chord
                      + (len(mats) if has_mat else 0) + 1))
        X[:, 0] = 20 * np.log10(np.maximum([r["dist"] for r in rs], 1e-3))
        c0 = 1
        if has_nocc:
            X[:, c0] = [float(r["n_occ"]) for r in rs]
            c0 += 1
        if has_chord:
            X[:, c0] = [float(r["chord"]) for r in rs]
            c0 += 1
        if has_mat:
            for j, m in enumerate(mats):
                X[:, c0 + j] = [1.0 if m in r["occ"] else 0.0 for r in rs]
            c0 += len(mats)
        X[:, c0] = 1.0
        return X

    print("-" * 74)
    print("逐场景 AUC（按 rec 划分，测试 rec 未在训练出现）")
    print("-" * 74)
    names = [v[0] for v in VARIANTS]
    print(f"\n  {'场景':<20s}{'n':>7s}" + "".join(f"{x:>12s}" for x in names))
    print("  " + "-" * (27 + 12 * len(names)))
    per_scene = {}
    for sc in scenes:
        rs, used = make_labels(data[sc])
        if len(rs) < 300:
            continue
        y_all = np.array([r["label"] for r in rs])
        d_all = np.array([r["dist"] for r in rs])
        dp = float(np.median(d_all[y_all == 1]))
        dn = float(np.median(d_all[y_all == 0]))
        leak = abs(dp - dn) / dn * 100
        gap = (float(np.mean([r["n_occ"] for r in rs if r["label"] == 1]))
               - float(np.mean([r["n_occ"] for r in rs if r["label"] == 0])))
        if leak >= 20.0 or gap <= 0.3:
            print(f"  {sc:<20s}{len(rs):>7d}   [泄漏 {leak:.1f}% / n_occ差 "
                  f"{gap:+.2f} → 排除]")
            continue
        recs = sorted({r["rec"] for r in rs})
        res = {nm: [] for nm, _ in VARIANTS}
        for rep in range(args.n_repeats):
            rng = np.random.RandomState(6000 + rep)
            perm = rng.permutation(len(recs))
            trk = {recs[i] for i in perm[:len(recs) // 2]}
            tr = [r for r in rs if r["rec"] in trk]
            te = [r for r in rs if r["rec"] not in trk]
            # ✅ sanity：测试 rec 零重叠
            if {r["rec"] for r in tr} & {r["rec"] for r in te}:
                continue
            if len(tr) < 100 or len(te) < 100:
                continue
            ytr = np.array([r["label"] for r in tr])
            yte = [r["label"] for r in te]
            for nm, var in VARIANTS:
                Xtr = feat2(tr, var)
                Xte = feat2(te, var)
                c, *_ = np.linalg.lstsq(Xtr, ytr, rcond=None)
                res[nm].append(auc_score(yte, Xte @ c))
        if not res[names[0]]:
            continue
        line = f"  {sc:<20s}{len(rs):>7d}"
        row = {}
        for nm, _ in VARIANTS:
            a = statistics.mean(res[nm])
            row[nm] = a
            line += f"{a:>12.3f}"
        per_scene[sc] = {"n": len(rs), "leak_pct": leak, "no_gap": gap,
                         **row}
        print(line)
    print()

    if not per_scene:
        print("无有效场景")
        sys.exit(1)

    print("=" * 74)
    print("汇总（可解场景平均）")
    print("=" * 74)
    summary = {}
    for nm, _ in VARIANTS:
        summary[nm] = statistics.mean(v[nm] for v in per_scene.values())
    print(f"\n  {'特征组合':<22s}{'平均AUC':>10s}{'vs仅距离':>11s}")
    print("  " + "-" * 43)
    base_auc = summary["仅距离"]
    for nm, _ in VARIANTS:
        d = summary[nm] - base_auc
        star = " ★" if nm in ("距离+chord", "距离+chord+材质") else ""
        print(f"  {nm:<22s}{summary[nm]:>10.3f}{d:>+11.3f}{star}")
    print()

    # ---- 核心对照 ----
    nocc_only = summary["距离+n_occ"]
    chord_only = summary["距离+chord"]
    both = summary["距离+n_occ+chord"]
    diff = chord_only - nocc_only
    print("  【C-21 核心对照】")
    print(f"    距离+n_occ  {nocc_only:.3f}")
    print(f"    距离+chord  {chord_only:.3f}   差 {diff:+.3f}")
    print(f"    两者同时    {both:.3f}")
    if diff > 0.02:
        verdict = "chord 在场景内更优"
        print("    → ✅ **C-21 场景内排序成立**")
    elif diff > -0.02:
        verdict = "两者等价"
        print("    → ⚠️ **等价** —— chord 只是 n_occ 的冗余代理，"
              "分层单调性不代表增量信息")
    else:
        verdict = "chord 更差"
        print("    → ❌ **不成立** —— chord 引入噪声，"
              "此前分层单调性分析有偏")
    print()

    # 逐场景改善
    print("  逐场景改善（距离+chord 减 距离+n_occ）")
    print(f"\n  {'场景':<20s}{'n_occ':>9s}{'chord':>9s}{'改善':>9s}")
    print("  " + "-" * 47)
    deltas = []
    for sc, v in sorted(per_scene.items(),
                        key=lambda kv: -(kv[1]["距离+chord"]
                                         - kv[1]["距离+n_occ"])):
        d = v["距离+chord"] - v["距离+n_occ"]
        deltas.append(d)
        print(f"  {sc:<20s}{v['距离+n_occ']:>9.3f}{v['距离+chord']:>9.3f}"
              f"{d:>+9.3f}")
    n_imp = sum(1 for d in deltas if d > 0)
    print(f"\n  改善场景 {n_imp}/{len(deltas)}，平均改善 "
          f"{statistics.mean(deltas):+.3f}")
    print()

    # sanity：逐场景评估有效
    vals = {v["距离+chord"] for v in per_scene.values()}
    ok_distinct = len(vals) > 1
    print(f"  [{'PASS' if ok_distinct else 'FAIL'}] 逐场景评估有效"
          f"（chord AUC 取值数 {len(vals)}）")

    ok = diff > 0.02 and n_imp > len(deltas) / 2
    print(f"\n  判定：{'✅ C-21 场景内排序成立' if ok else '🔴 C-21 场景内排序不成立'}")
    print(f"  （门禁：差 > 0.02 且过半场景改善）")

    out = {
        "band": args.band, "n_bins": args.n_bins,
        "pos_frac": args.pos_frac, "scenes": scenes,
        "summary": summary,
        "core_compare": {"nocc_only": nocc_only, "chord_only": chord_only,
                         "both": both, "diff": diff},
        "verdict": verdict,
        "n_improved": n_imp, "n_scenes": len(deltas),
        "mean_delta": statistics.mean(deltas),
        "per_scene": per_scene,
        "gate": {"per_scene_distinct": bool(ok_distinct),
                 "pass": bool(ok)},
    }
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print(f"\n结果已保存: {args.out}")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
