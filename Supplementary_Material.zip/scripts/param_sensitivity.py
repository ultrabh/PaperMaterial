"""
优化点 0：分析参数敏感性测绘（band × min_per_bin）
================================================================================
为什么做这个
------------
`criterion_revision.py` 把判据从「绝对 AUC 阈值」改为「增益符号一致性」，
使结论不再依赖 `pos_frac`（实测漂移 0.083）。

但仍有**两个分析参数从未测过敏感性**：

| 参数 | 当前值 | 风险 |
|---|---|---|
| `band` | 2000–8000 | 🔴 未知，可能影响结论 |
| `min_per_bin` | 40 | 🟡 未知，与层数耦合 |

若任一参数会翻转结论符号，则C-26「符号一致性」需降级。

🔴 已先做小样本探查，推翻了原假设
----------------------------------------
**原假设**：遮挡透射率有频率依赖（高频更易衰减），
故低频段的几何增益应更高；若成立，是「免费的方法学提升」。

**实测（ΔE = ≥2层 − 无遮挡的中位能量差）**：

| 场景 | 0–500 | 500–2000 | 2000–8000 | 8000–20000 | 20000–22000 |
|---|---|---|---|---|---|
| hotel_0 | **−19.04** | −15.23 | −15.65 | −15.90 | −16.02 |
| frl_apartment_2 | **−13.16** | −10.72 | −11.28 | −11.31 | −11.62 |
| apartment_0 | **−14.78** | −12.34 | −12.07 | −12.30 | −12.37 |

**ΔE 跨频段几乎恒定，无频率依赖** → 「换频带提升增益」**不成立**。

但**0–500 Hz 确实明显更大**（hotel_0 差 3.4 dB），需在本脚本中确认
它是否转化为更高的分类增益。

🔴 20–22 kHz 频段必须处理
--------------------------
该频段能量极低（hotel_0 中位 **−12.7 dB**，min −31.3），
接近仿真噪声底。取 dB 会放大噪声。
本脚本**单独报告但不用于主结论**，并在 gate 中标记。

sanity check
------------
1. 每个频段须逐场景做泄漏检验（不得全局合并）
2. 增益符号须在**所有频段**上为正，否则 C-26 需降级
   （频段数仅 4 个，**不用二项检验**做判据——功效不足；
     改为直接检查「各频段的最小场景增益 > 0」）
3. 报告 20–22 kHz 的噪声警告
4. 二项检验用精确组合数

输出：/mnt/d/fenzhi1/outputs/param_sensitivity.json
"""

import argparse
import json
import math
import os
import statistics
import sys
from math import comb

import numpy as np


def db(x):
    return 10.0 * math.log10(max(float(x), 1e-300))


def auc_score(y_true, score):
    y = np.asarray(y_true)
    s = np.asarray(score, dtype=float)
    n_pos = int((y == 1).sum())
    n_neg = int((y == 0).sum())
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    order = np.argsort(s)
    ranks = np.empty(len(s), dtype=float)
    ranks[order] = np.arange(1, len(s) + 1)
    _, inv, cnt = np.unique(s, return_inverse=True, return_counts=True)
    sums = np.zeros(len(cnt))
    np.add.at(sums, inv, ranks)
    ranks = (sums / cnt)[inv]
    return float((ranks[y == 1].sum()
                  - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def binomial_sf(k, n, p=0.5):
    return float(sum(comb(n, i) * p ** n for i in range(k, n + 1)))


def main():
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except Exception:      # noqa: BLE001
        pass

    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", nargs="+", required=True)
    ap.add_argument("--bands", nargs="+",
                    default=["0-500", "500-2000", "2000-8000",
                             "8000-20000", "20000-22000"])
    ap.add_argument("--noisy-bands", nargs="+", default=["20000-22000"],
                    help="接近噪声底的频段，单列报告但不进主结论")
    ap.add_argument("--pos-fracs", nargs="+", type=float,
                    default=[0.10, 0.20, 0.30])
    ap.add_argument("--min-per-bins", nargs="+", type=int,
                    default=[30, 40, 60, 80])
    ap.add_argument("--n-bins", type=int, default=12)
    ap.add_argument("--leak-max", type=float, default=20.0)
    ap.add_argument("--no-gap-min", type=float, default=0.3)
    ap.add_argument("--n-repeats", type=int, default=3)
    ap.add_argument("--out",
                    default="/mnt/d/fenzhi1/outputs/param_sensitivity.json")
    args = ap.parse_args()

    raw_rows = []
    all_bands = None
    for f in args.pairs:
        with open(f, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
        for sc, v in raw.get("scenes", {}).items():
            for p in v.get("pairs", []):
                if "energy" not in p:
                    continue
                if all_bands is None:
                    all_bands = set(p["energy"].keys())
                raw_rows.append({"scene": sc, "rec": p["rec"],
                                 "dist": p["dist"],
                                 "n_occ": p["n_occ"],
                                 "occ": p["occ_classes"],
                                 "energy": p["energy"]})
    scenes = sorted({r["scene"] for r in raw_rows})
    usable = [b for b in args.bands if b in (all_bands or set())]
    mats = sorted({m for r in raw_rows for m in r["occ"]})
    print("=" * 74)
    print("优化点 0：分析参数敏感性（band × min_per_bin）")
    print("=" * 74)
    print(f"  样本 {len(raw_rows)}，场景 {len(scenes)}")
    print(f"  可用频段 {sorted(all_bands or [])}")
    print(f"  参与检验的频段 {usable}")
    print(f"  噪声警告频段 {args.noisy_bands}")
    print()

    def feat(rs, band):
        n = len(rs)
        X = np.zeros((n, 3 + len(mats)))
        X[:, 0] = 20 * np.log10(np.maximum([r["dist"] for r in rs], 1e-3))
        X[:, 1] = [float(r["n_occ"]) for r in rs]
        for j, m in enumerate(mats):
            X[:, 2 + j] = [1.0 if m in r["occ"] else 0.0 for r in rs]
        X[:, 2 + len(mats)] = 1.0
        return X

    _cache = {}
    _by_scene = {}

    def evaluate(band, scene, pf, min_per_bin):
        """**逐场景**评估。返回 (auc, auc_dist, leak, no_gap, n) 或 None。

        🔴 2026-10-19 修正：本函数原本**不接收 scene 参数**，
        内部按「全部场景混合」计算，却在外层循环里打印 8 次，
        导致所有场景数字相同、泄漏检验被跳过、门禁失效。
        现在 scene 是必需参数，且只取该场景的样本。
        """
        key = (band, scene, round(pf, 4), min_per_bin)
        if key in _cache:
            return _cache[key]
        v = _evaluate(band, scene, pf, min_per_bin)
        _cache[key] = v
        return v

    def _evaluate(band, scene, pf, min_per_bin):
        # 🔴 按场景预构建 dB 数组（缓存 dB 转换，但**绝不混合场景**）
        per_scene = _by_scene.setdefault(band, {})
        if not per_scene:
            for r in raw_rows:
                per_scene.setdefault(r["scene"], []).append(
                    dict(r, E=db(r["energy"][band])))
        rs = per_scene.get(scene, [])
        if len(rs) < 300:
            return None
        d = np.array([r["dist"] for r in rs])
        E = np.array([r["E"] for r in rs])
        edges = np.unique(np.quantile(d, np.linspace(0, 1, args.n_bins + 1)))
        lab = np.full(len(rs), -1, dtype=int)
        for i in range(len(edges) - 1):
            lo, hi = edges[i], edges[i + 1]
            m = (d >= lo) & ((d <= hi) if i == len(edges) - 2
                             else (d < hi))
            if m.sum() < min_per_bin:
                continue
            k = max(5, int(m.sum() * pf))
            idx = np.where(m)[0]
            order = idx[np.argsort(E[idx])]
            lab[order[:k]] = 1
            lab[order[k:]] = 0
        L = [(r, l) for r, l in zip(rs, lab) if l >= 0]
        if len(L) < 300:
            return None
        Lr = [r for r, _ in L]
        y = np.array([l for _, l in L])
        dd = np.array([r["dist"] for r in Lr])
        dp = float(np.median(dd[y == 1]))
        dn = float(np.median(dd[y == 0]))
        if dn <= 0:
            return None
        leak = abs(dp - dn) / dn * 100
        npos = float(np.mean([r["n_occ"] for r, l in L if l == 1]))
        nneg = float(np.mean([r["n_occ"] for r, l in L if l == 0]))
        recs = sorted({r["rec"] for r in Lr})
        if len(recs) < 6:
            return None
        al = []
        for rep in range(args.n_repeats):
            rng = np.random.RandomState(5000 + rep)
            perm = rng.permutation(len(recs))
            trk = {recs[i] for i in perm[:len(recs) // 2]}
            tr = [r for r in Lr if r["rec"] in trk]
            te = [r for r in Lr if r["rec"] not in trk]
            if {r["rec"] for r in tr} & {r["rec"] for r in te}:
                continue
            if len(tr) < 100 or len(te) < 100:
                continue
            Xtr, Xte = feat(tr, band), feat(te, band)
            ytr = np.array([l for r, l in L if r["rec"] in trk])
            c, *_ = np.linalg.lstsq(Xtr, ytr, rcond=None)
            al.append(auc_score([l for r, l in L if r["rec"] not in trk],
                                Xte @ c))
        if not al:
            return None
        return (statistics.mean(al), auc_score(y, -dd), leak,
                npos - nneg, len(L))

    # ---------- 1. band 扫描 ----------
    print("-" * 74)
    print("1. band 扫描（主设定 pf=0.20, min_per_bin=40）")
    print("-" * 74)
    main_pf = 0.20 if 0.20 in args.pos_fracs else args.pos_fracs[0]
    band_rows = []
    print(f"\n  {'频段':<14s}{'场景':<6s}{'AUC':>8s}{'仅距离':>9s}"
          f"{'增益':>9s}{'泄漏%':>8s}{'n_occ差':>9s}  判定")
    print("  " + "-" * 70)
    band_summary = {}
    for band in usable:
        gains = []
        for sc in scenes:
            r = evaluate(band, sc, main_pf, 40)
            if r is None:
                continue
            auc, ad, leak, gap, n = r
            ok = leak < args.leak_max and gap > args.no_gap_min
            if ok:
                gains.append(auc - ad)
            noisy = " 🔇" if band in args.noisy_bands else ""
            print(f"  {band:<14s}{sc[:4]:<6s}{auc:>8.3f}{ad:>9.3f}"
                  f"{auc - ad:>+9.3f}{leak:>8.1f}{gap:>+9.2f}"
                  f"  {'PASS' if ok else 'fail'}{noisy}")
            band_rows.append({"band": band, "scene": sc, "auc": auc,
                              "auc_dist": ad, "gain": auc - ad,
                              "leak_pct": leak, "no_gap": gap,
                              "pass": bool(ok), "n": n})
        if gains:
            band_summary[band] = {
                "mean_gain": statistics.mean(gains),
                "min_gain": min(gains), "max_gain": max(gains),
                "n_pass": len(gains),
                "noisy": band in args.noisy_bands,
            }
            print(f"  {'':<14s}{'→ 有效场景':<6s}"
                  f"{'平均增益 ' + format(statistics.mean(gains), '.3f'):>26s}"
                  f"   范围 [{min(gains):+.3f}, {max(gains):+.3f}]"
                  f"{'  🔇 噪声频段' if band in args.noisy_bands else ''}")
        print()

    # ---------- 2. min_per_bin 扫描 ----------
    print("-" * 74)
    print(f"2. min_per_bin 扫描（band={args.bands[2] if len(args.bands) > 2 else usable[0]}）")
    print("-" * 74)
    probe_band = (args.bands[2] if len(args.bands) > 2 else usable[0])
    if probe_band not in usable:
        probe_band = usable[0]
    mpb_rows = []
    print(f"\n  {'min_per_bin':<13s}{'有效场景':>9s}{'平均增益':>10s}"
          f"{'最小增益':>10s}")
    print("  " + "-" * 44)
    mpb_summary = {}
    for mpb in args.min_per_bins:
        gains = []
        for sc in scenes:
            r = evaluate(probe_band, sc, main_pf, mpb)
            if r is None:
                continue
            auc, ad, leak, gap, n = r
            if leak < args.leak_max and gap > args.no_gap_min:
                gains.append(auc - ad)
        if not gains:
            print(f"  {mpb:<13d}{'0':>9d}{'（无有效场景）':>20s}")
            mpb_summary[mpb] = {"n_pass": 0}
            continue
        mpb_summary[mpb] = {"mean_gain": statistics.mean(gains),
                            "min_gain": min(gains), "n_pass": len(gains)}
        print(f"  {mpb:<13d}{len(gains):>9d}"
              f"{statistics.mean(gains):>+10.3f}{min(gains):>+10.3f}")
    print()

    # ---------- 3. 门禁 ----------
    print("=" * 74)
    print("门禁")
    print("=" * 74)
    clean = {b: v for b, v in band_summary.items() if not v["noisy"]}

    ok1 = len(clean) > 0
    print(f"  [{'PASS' if ok1 else 'FAIL'}] 有非噪声频段参与检验"
          f"（{len(clean)} 个）")

    all_gains = [v["mean_gain"] for v in clean.values()]
    min_mean = min(all_gains) if all_gains else float("nan")
    ok2 = all_gains and min_mean > 0
    print(f"  [{'PASS' if ok2 else 'FAIL'}] 所有非噪声频段的平均增益 > 0"
          f"（最小 {min_mean:+.3f}）")

    # 🔴 频段数很少（4 个），二项检验功效不足
    #   实测：只测 1 个频段时 p 恒为 0.5，必然 FAIL —— 这是检验设计的错，
    #   不是结论的错。改用**直接符号检查**（无统计功效要求）。
    n_pos = sum(1 for v in clean.values() if v["min_gain"] > 0)
    n_tot = len(clean)
    pval = binomial_sf(n_pos, n_tot) if n_tot else 1.0
    ok3 = n_tot > 0 and n_pos == n_tot
    print(f"  [{'PASS' if ok3 else 'FAIL'}] 跨频段符号一致"
          f"（各频段**最小**场景增益均 > 0：{n_pos}/{n_tot}）")
    print(f"       注：频段数仅 {n_tot} 个，二项检验功效不足"
          f"（p = {pval:.3f}，仅供参考，不作判据）")

    mpb_ok = [v for v in mpb_summary.values()
              if v.get("n_pass", 0) > 0 and v["mean_gain"] > 0]
    ok4 = len(mpb_ok) == len([v for v in mpb_summary.values()
                              if v.get("n_pass", 0) > 0])
    print(f"  [{'PASS' if ok4 else 'FAIL'}] 所有 min_per_bin 设定增益 > 0"
          f"（{len(mpb_ok)}/{len(mpb_summary)}）")

    # 🔴 sanity：逐场景评估必须有差异
    #   （2026-10-20事故：函数不接收 scene，导致 8 场景数字全同）
    per_band_vals = {}
    for band in usable:
        vals = {r["gain"] for r in band_rows if r["band"] == band}
        per_band_vals[band] = len(vals)
    degenerate = [b for b, n in per_band_vals.items() if n <= 1]
    ok5 = not degenerate
    print(f"  [{'PASS' if ok5 else 'FAIL'}] 逐场景评估有效"
          f"（各频段场景间增益取值数：{per_band_vals}）")
    if degenerate:
        print(f"       🔴 频段 {degenerate} 的所有场景数值相同 —— "
              f"说明 scene 参数未生效，评估被混算了")

    all_ok = ok1 and ok2 and ok3 and ok4 and ok5
    print()
    print(f"  判定：{'✅ 参数不敏感，结论稳健' if all_ok else '🔴 结论依赖参数'}")
    if all_ok:
        print("  → C-26「增益符号一致性」**可升级为参数无关的结论**")
    else:
        print("  → C-26 需降级为「在指定参数下成立」")

    # 噪声频段警告
    noisy = {b: v for b, v in band_summary.items() if v["noisy"]}
    if noisy:
        print()
        print("  ⚠ 噪声频段（不用于主结论）：")
        for b, v in noisy.items():
            print(f"     {b:<14s} 平均增益 {v['mean_gain']:+.3f}"
                  f" —— 该频段能量接近噪声底，dB 值放大噪声")

    out = {
        "n_samples": len(raw_rows), "scenes": scenes,
        "bands_available": sorted(all_bands or []),
        "bands_tested": usable,
        "noisy_bands": args.noisy_bands,
        "main_pos_frac": main_pf, "n_bins": args.n_bins,
        "band_scan": band_summary, "band_rows": band_rows,
        "min_per_bin_scan": mpb_summary,
        "probe_band_for_mpb": probe_band,
        "gate": {"nonnoisy_present": bool(ok1),
                 "all_gains_positive": bool(ok2),
                 "sign_consistency": bool(ok3),
                 "min_per_bin_positive": bool(ok4),
                 "per_scene_distinct": bool(ok5),
                 "pass": bool(all_ok)},
        "sign_p_value_across_bands": pval,
        "conclusion": ("参数不敏感，结论稳健" if all_ok
                       else "结论依赖参数，C-26 需降级"),
    }
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print(f"\n结果已保存: {args.out}")
    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
