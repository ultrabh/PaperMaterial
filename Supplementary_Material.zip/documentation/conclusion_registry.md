# Conclusion Registry

> **Mandatory rule:** an entry whose *refutation condition* is empty is an
> incomplete conclusion and must not be used as supporting evidence.
> Every new conclusion is registered here before it is written into any
> document or report.
> Basis: `analysis_gates.md`.

---

## How to read this file

| Field | Meaning |
|---|---|
| **Gate** | G0 alignment / G1 data / G2 collinearity / G3 extrapolation / G4 refutation condition |
| **Refutation condition** | What new evidence would overturn this conclusion. **The most important field** |
| **Confidence** | High: multiple scenes and all gates passed; Medium: some gates passed; Low: single scene, or a gate failed |
| **Status** | Valid / Conditional / Retracted / Pending review |

**On file paths in the evidence fields.** Most evidence pointers name files in
the author's working tree, which is not distributed with this package because
it contains the full per-pair records (about 270 MB) and intermediate
artifacts. The subset that is distributed is listed in `MANIFEST.json`; the
analysis scripts that regenerate every number are in `scripts/`. Where a
pointer names a file that is not shipped, the conclusion rests on the reported
values rather than on a re-runnable artifact, and this is stated in the entry.

---

## 1. Currently valid conclusions

### C-01 BRIR data format

| Item | Content |
|---|---|
| **Conclusion** | SoundSpaces BRIR is IEEE float32 / 44100 Hz / two channels |
| **Gate** | G0 pass (first 128 bytes parsed to identify the chunk) |
| **Evidence** | `fmt: format_tag=3, ch=2, sr=44100, bits=32`; peak 5.2 (not normalised); frame count matches file size exactly |
| **Potential confounds** | None |
| **Refutation condition** | If BRIR for other scenes shows a different format_tag or sample rate |
| **Confidence** | High |
| **Status** | Valid |

### C-02 BRIR is the full Cartesian product of navigation points

| Item | Content |
|---|---|
| **Conclusion** | Both rec and src in the BRIR are navigation-point ids from `points.txt`, and the set is a complete Cartesian product (self-pairs included) |
| **Gate** | G0 pass (id-space comparison: 100% of rec/src fall inside the points id set) |
| **Evidence** | 1369 = 37², 2304 = 48², 2601 = 51²; verified against a directory listing to be the complete Cartesian product |
| **Potential confounds** | None |
| **Refutation condition** | If an official updated release changes the id semantics |
| **Confidence** | High |
| **Status** | Valid |

### C-03 The RIR contains no propagation delay

| Item | Content |
|---|---|
| **Conclusion** | The first ~2.27 ms of every RIR is strictly silent; the time axis carries no propagation-delay information |
| **Gate** | G0 pass, G1 pass (zero-variance detection) |
| **Evidence** | rms over the first 200 samples is exactly 0.000000; three independent onset-detection methods all fail to recover a delay |
| **Potential confounds** | None |
| **Refutation condition** | If a time-aligned variant of the BRIR exists |
| **Confidence** | High |
| **Status** | Valid |

### C-04 ILD is reliable, ITD is not

| Item | Content |
|---|---|
| **Conclusion** | ILD carries azimuth information (69.5% agreement); ITD is unreliable because of reverberative decorrelation (33% reliable) |
| **Gate** | G0 pass (the left/right convention was determined by exhaustive test) |
| **Evidence** | ILD range −12.6 to +15.1 dB, perfectly symmetric at 30 left / 30 right; cross-correlation peak only 0.18–0.46 |
| **Potential confounds** | The conclusion fails if the left/right convention is reversed in some scenes |
| **Refutation condition** | If ITD remains below 50% reliability when re-measured on 8 or more scenes, ITD is confirmed unusable for any modelling |
| **Confidence** | Medium (ILD high, ITD medium) |
| **Status** | Valid |

### C-05 The geometric path must be a navigation-point pair

| Item | Content |
|---|---|
| **Conclusion** | When analysing BRIR, the geometric path must be *src navigation point → rec navigation point*, not *object centre → listener* |
| **Gate** | G0 pass (both paths measured and compared) |
| **Evidence** | Median chord 0.644 m on path A vs 0.115 m on path B (5.6×); corr(A) = −0.147 vs corr(B) = −0.471 |
| **Potential confounds** | None |
| **Refutation condition** | If the BRIR source turns out to be at the object position rather than at a navigation point |
| **Confidence** | High |
| **Status** | Valid |

### C-06 Source height is a property of the semantic class

| Item | Content |
|---|---|
| **Conclusion** | Source height can be predicted from the class label: the between-class spread is 10.7× the within-class IQR |
| **Gate** | G1 pass (21 classes, sufficient samples in each) |
| **Evidence** | Median within-class IQR 0.123 m, median between-class span 1.323 m |
| **Potential confounds** | None |
| **Refutation condition** | If the between-class / within-class ratio falls below 3× on more scenes |
| **Confidence** | High |
| **Status** | Valid |

### C-08 Thin occlusion is common under the navigation-point convention

| Item | Content |
|---|---|
| **Conclusion** | 16 of the 18 scenes have enough thin-occlusion samples (≥ 50 pairs) for the question to be answerable |
| **Gate** | G0 pass (navigation-point path), G1 pass (full computation, not sampled) |
| **Evidence** | `p05_feasibility.json`: the thin class is largest in frl_apartment_2 (2138 pairs, 7.15%) and largest in proportion in room_0 (2220 pairs, 24.18%); only office_0 (9 pairs) and room_1 (44 pairs) fall short |
| **Potential confounds** | See C-09: BRIR covers only 36–47% of navigation points, and the coverage pattern is scene-dependent |
| **Refutation condition** | If, recomputed on the nodes BRIR actually covers, more than half the scenes have fewer than 50 thin-class pairs, the question does not hold on the analysable sample |
| **Confidence** | Medium (high at the geometric level, limited by C-09) |
| **Status** | Valid |

### C-09 BRIR covers only 36–47% of navigation points, and the selection is scene-dependent

| Item | Content |
|---|---|
| **Conclusion** | BRIR node selection is neither random nor comprehensive but a scene-dependent subset, which directly determines the distribution of visible samples |
| **Gate** | G0 pass, G1 pass |
| **Evidence** | office_2: 104 nodes in `points.txt`, BRIR covers **37 (36%)**; hotel_0 102/48 (47%); room_0 136/51 (38%) |
| **Thin-class capture rate** | hotel_0 **103.6%** (essentially all), room_0 **42.3%**, office_2 **0%** |
| **Key implication** | All 87 of office_2's thin-class pairs fall on nodes BRIR does not cover, which is why [26] observed "thin class = 0" |
| **Refutation condition** | This entry dissolves automatically if the BRIR node-selection rule is found and shown to be independent of occlusion type |
| **Confidence** | High (measured counts) |
| **Status** | Valid — **this is the key constraint on the study design** |

### C-10 After controlling for distance, the independent contribution of chord is ≈ 0

| Item | Content |
|---|---|
| **Conclusion** | Over 21638 pairs in 4 scenes, adding chord on top of distance + scene gives an incremental R² of **−0.010** |
| **Gate** | G0 pass, G1 pass (n_eff = 9693), G2 pass (residual and incremental methods agree) |
| **Evidence** | `multi_scene_diag.json`: scene dummy alone R² = 0.136 → +distance increment **+0.591** → +chord increment −0.010 |
| **Superseded in part by C-11** | The reason chord shows no contribution is **not** that the information is absent but that it is **replaced by better features** (layer count and material). C-10's conclusion that chord must not be used as an independent metric still holds, but the stated reason needs correction |
| **Refutation condition** | See C-11 |
| **Confidence** | Medium |
| **Status** | Valid (must be read together with C-11) |

### C-11 🔴 [corrects C-10] The effective features are layer count + material, not thickness

| Item | Content |
|---|---|
| **Conclusion** | Once distance is controlled, **chord (total thickness) has no independent contribution (−0.010), but n_occ (number of occluders) contributes +0.064 and the material dummies together +0.096** |
| **Gate** | G0 pass, G1 pass (n = 21638), G2 pass (residual method and distance stratification agree) |
| **Evidence 1: incremental R² (baseline = distance + scene)** | chord **−0.0102** (FAIL); n_occ **+0.0638**; all materials **+0.0957** |
| **Evidence 2: distance stratification (dist ∈ [2.0, 2.5], n = 2676)** | chord −0.0171 (FAIL); n_occ **+0.0829** |
| **Evidence 3: monotonicity of n_occ** | 0 layers 46.02 → 1 layer 45.52 → 2 layers 44.42 → 3 layers **38.28 dB**, **strictly monotonic** |
| **Evidence 4: chord is not monotonic within one n_occ** | n_occ = 1: 44.77 → 42.64 → 43.89 → 41.10 (**non-monotonic**, spread only 3.7 dB) |
| **Physical mechanism** | Energy loss comes from the **transmission per layer** (set by material), not from geometric thickness. More layers means more transmission losses compounding |
| **Refutation condition** | If material transmission coefficients or first-reflection paths are added and chord again shows an independent increment > 0.05, this conclusion must be revised |
| **Confidence** | Medium-high (n_scene = 4, but the two methods agree and the mechanism is clear) |
| **Status** | **Valid** — the most substantive modelling result so far |

### C-12 Distance dominates the acoustic energy

| Item | Content |
|---|---|
| **Conclusion** | On top of scene, distance alone contributes R² **+0.591**; the residual method gives corr(dist, E) of −0.63 to −0.97 |
| **Gate** | G0 pass, G1 pass, G2 pass |
| **Evidence** | corr(dist, E) over 4 scenes: frl_apartment_2 −0.872, hotel_0 −0.631, office_2 −0.949, room_0 −0.969 |
| **Refutation condition** | If, after controlling for distance, other factors still explain more than 30% of the residual, "distance dominates" must be qualified |
| **Confidence** | High |
| **Status** | Valid |

### C-13 🔴 Material features do not generalise across scenes (key limitation)

| Item | Content |
|---|---|
| **Conclusion** | Material dummies contribute +0.096 incrementally **within** a scene, but contribute **zero** in cross-scene validation |
| **Gate** | G0 pass (training excludes scene identity), G1 pass (n = 21638), G2 pass |
| **Evidence 1: cross-scene comparison** | distance only **0.433**; distance + layers + all materials **0.433** (identical); distance + layers + wall only **0.472** |
| **Evidence 2: material distributions barely overlap** | office_2 has only wall; hotel_0 has rack 36.9% + panel 11.3%; room_0 has only wall + pillar; frl_apartment_2 has door 25.9% + blinds 8.9% + shelf 11.7% |
| **Evidence 3: worst combination** | testing hotel_0 + frl_apartment_2 gives R² of only **0.222** — the training set contains neither rack nor panel, so the model has no way to learn their transmission coefficients |
| **Root cause** | **Each scene's material combination is nearly unique**, so a dummy variable carries no information when the class is absent from training |
| **Refutation condition** | With 8 or more scenes and overlapping material distributions, cross-scene generalisation should improve markedly; if it is still 0, material features are inherently scene-local |
| **Confidence** | Medium-high (phenomenon clear, mechanism established) |
| **Status** | **Valid** — a key constraint on the modelling |

### C-14 Baseline model reaches cross-scene R² = 0.522 (signal present, target not met)

| Item | Content |
|---|---|
| **Conclusion** | The "distance + layers + material" model reaches a mean cross-scene R² of **0.522**, RMSE **3.87 dB** |
| **Gate** | All sanity checks pass (R² ∈ [−1, 1], RMSE > 0) |
| **Results by subset** | with frl_apartment_2: 0.78–0.79; without: 0.38–0.51 |
| **Ablation** | distance only 0.325 → +layers 0.433 → +material 0.522 |
| **Against the pre-written criterion** | 0.50 ≤ R² < 0.70 → **"signal present but more features needed"** |
| **Refutation condition** | If room acoustic attributes (RT60 / volume) still leave R² < 0.60, the linear-model route has to become non-linear |
| **Confidence** | Medium (n_scene = 4, ample samples but few scenes) |
| **Status** | Conditional |

### C-15 🔴 v1 had label leakage; AUC 0.918 was a spurious result

| Item | Content |
|---|---|
| **Problem** | In `p1_audibility.py` the label ΔE = baseline(rec, unobstructed) − E, but the **baseline is dominated by near-field samples**, so large ΔE simply means "far away" |
| **Evidence** | Positive-class dist median 3.2–7.0 m, negative class 2.0–3.5 m; "distance only" already reaches AUC **0.851** |
| **Conclusion** | The v1 AUC of 0.918 reflects **distance**, not occlusion |
| **Lesson** | **The label definition must be decoupled from the predictive features.** For any "relative to baseline" label, the positive and negative samples must be checked for comparable distributions on *every* feature |

### C-16 With distance conditioning, occlusion information adds +0.247 (real signal)

| Item | Content |
|---|---|
| **Conclusion** | With the label threshold taken **per distance stratum**, AUC reaches 0.724; "distance only" falls to **0.477** (chance), so occlusion information adds **+0.247** |
| **Gate** | G0 pass (distance leakage removed), G1 pass, G2 pass |
| **Evidence** | Per-scene relative difference of the positive/negative distance medians ≤ 1.5% (office_2 1.5%, room_0 **0.0%**); distance-only AUC 0.477 |
| **Per model** | distance only 0.477; +chord 0.665; +layers 0.717; **+material 0.724** |
| **Key comparison** | **chord (0.665) is clearly weaker than layers (0.717) and material (0.724)** — consistent with C-11 |
| **Against the pre-written criterion** | 0.65 ≤ AUC 0.724 < 0.80 → **"occlusion gives a weak signal"** |
| **Refutation condition** | If room acoustic attributes raise AUC to ≥ 0.80, this must be upgraded to "feature set sufficient" |
| **Confidence** | Medium (label decoupled, but n_scene = 4) |
| **Status** | Conditional — the C-route premise holds but the features are insufficient |

### C-17 🔴 Room acoustic attributes (D/L ratio) are useless — stop trying

| Item | Content |
|---|---|
| **Conclusion** | Adding room acoustic attributes moves AUC only from 0.724 to **0.730** (+0.006), far below the 0.02 threshold |
| **Gate** | All sanity checks pass (key names hit, hit rate 100%, no distance leakage) |
| **Per-model AUC** | distance only 0.477; room attributes only **0.554**; distance + layers + material 0.724; all + room **0.730** |
| **"Room attributes only" AUC 0.554** | Slightly above chance (0.5) but far from sufficient to support a decision |
| **Against the pre-written criterion** | Improvement < 0.02 → **"stop pursuing this class of features"** |
| **Why** | Room attributes are **rec-level** (shared by all src of the same rec), whereas the task is to predict whether **a given src** is audible — a **granularity mismatch** |
| **RT60 is unusable too** | Measured T20 / RIR length = 1.02–1.27; the RIR is too short for the decay to complete |
| **Refutation condition** | If **src-level** acoustic attributes are used (computed per (rec, src) pair instead of per-rec median) the improvement may exceed 0.05 |
| **Confidence** | Medium |
| **Status** | Valid — **an explicit negative result that prevents repeated attempts** |

### C-18 🔴 A genuine gap in the geometric information (0.73 is the ceiling for this data)

| Item | Content |
|---|---|
| **Conclusion** | For 10–20% of sample pairs, geometry cannot distinguish them but acoustics do, which caps the attainable AUC |
| **Gate** | G0 pass, G1 pass, G2 pass |
| **Evidence: indistinguishable pairs** | Same rec, same distance (± 0.3 m), but layer count differing by ≥ 2: **hotel_0 19.9%**, frl_apartment_2 9.5%, room_0 1.0%, office_2 0.0% |
| **Evidence: features already ruled out** | chord (incremental −0.010); material (0 across scenes); RT60 (T20/RIR = 1.02–1.27, unusable); room attributes (+0.006); angular energy range (weak); node_to_src_dist (corr −0.13 to +0.14) |
| **Physical reason** | Real attenuation also depends on per-layer thickness and incidence angle, diffraction and multiple reflections, and first-reflection paths — **these need acoustic simulation, and BRIR gives only the result, not the paths** |
| **Refutation condition** | With a dataset that provides acoustic path information, or with self-built simulation resolving diffraction detail, AUC can improve |
| **Confidence** | Medium-high |
| **Status** | **Valid** — **one of the most valuable scientific arguments in this study** |

### C-19 Constraints on how the paper may be framed

| Item | Content |
|---|---|
| **Must not claim** | "Geometric features suffice to decide existence" |
| **May claim** | "Geometry provides partial evidence (occlusion gain +0.247), but 10–20% of sample pairs are geometrically indistinguishable, which upper-bounds the inherent uncertainty of existence inference" |
| **Why the second is better** | It gives a quantified boundary of the unknowable, which is a stronger scientific claim |
| **Value for the research question** | **Uncertainty is not a deficiency of the model but a shortage of geometric information itself** — which is exactly what an explicit belief state is for |

### C-18 🔴 [RETRACTED] "There is a genuine gap in the geometric information" does not hold

| Item | Content |
|---|---|
| **Original conclusion** | 44–49% of sample groups are geometrically indistinguishable but acoustically different, giving an upper bound on uncertainty |
| **Reason for retraction** | **The criterion was wrong.** The original text used "within-group layer-count spread ≥ 2" as the definition of "geometrically indistinguishable", but when the layer count differs the geometric description **is** different, and the model has an `n_occ` feature that should be able to tell them apart |
| **Corrected test** | Pairs that are **geometrically identical** (same rec, \|Δd\| ≤ 0.15 m, same layer count, same material): |
| **Corrected result** | Median \|ΔE\|: **hotel_0 1.44 dB / frl_apartment_2 0.55 dB / room_0 0.43 dB**, against 6.11 / 3.66 / 2.27 dB for random pairing |
| **Conclusion** | **Pairs that are geometrically identical are acoustically nearly identical too.** The claim "many pairs are geometrically indistinguishable but acoustically different" **does not hold** |
| **Lesson** | Another instance of "reaching the desired conclusion with a faulty criterion" — the same root cause as "chord contaminated by the distance effect": **the criterion itself was never validated** |
| **New rule** | **Rule 31**: before using any new criterion, ask "does it actually measure what I claim?" and test it with **counter-examples** (if the criterion holds, extreme cases should be findable) |

### C-20 ✅ Route A: predict absolute energy directly (all gates pass, unbiased)

| Item | Content |
|---|---|
| **Conclusion** | Using **energy** as the label and distance as a feature gives cross-scene R² **0.622**, RMSE 3.84 dB, with all gates passed |
| **Gate** | All PASS: coefficient signs correct, overfitting gap +0.195 < 0.30 |
| **Why it is unbiased** | v1 / v2 / v4 used **occlusion** as the label → distance becomes a confounder → it has to be removed → bias is introduced. **Route A has no removal logic, so this bias cannot arise** |
| **Evidence 1** | corr(E, 20log d) = **−0.8364**; distance is a physically necessary term |
| **Evidence 2: coefficient signs** | 20log(d) −0.69, n_occ −1.19, both negative ✅ |
| **Evidence 3: chord is harmful** | distance + layers + material **0.622** → all of them (with chord) **0.521**, a drop of **0.100**. Independent confirmation of C-11 |
| **Feature ranking** | layers (0.572) > material (0.538) > **chord (0.514)** — consistent across scenes |
| **Overfitting** | in-sample 0.817 vs cross-scene 0.622, gap **+0.195** ✅ |
| **🔴 Per-scene spread 0.483** | frl_apartment_2 **0.794**; apartment_0 0.613; office_2 0.454; room_0 0.402; **hotel_0 only 0.312 (RMSE 6.44)** |
| **Why hotel_0 fails** | Its material composition is unique (rack 36.9% + panel 11.3%, neither present elsewhere) → material coefficients cannot transfer |
| **Refutation condition** | If hotel_0 R² stays below 0.5 after a material-transmission prior is introduced, geometry + material cannot generalise across scenes |
| **Confidence** | Medium-high (methodologically sound, n_scene = 5) |
| **Status** | **Valid** — the first result of this study with all gates passed and physical self-consistency |

### C-21 Feature ranking (🔴 corrected 2026-10-19: cross-scene and within-scene must be separated)

**Original statement (cross-scene setting):**
> number of occluding layers > occluding material > occluding thickness
> and thickness (chord) should not be used as a feature — adding it lowers cross-scene R² by 0.100

**🔴 After correction:**

| Setting | Feature effectiveness ranking | Evidence |
|---|---|---|
| **Cross-scene** | n_occ > material > chord | C-11: R² 0.622 → 0.521 (adding chord drops 0.100) |
| **Within a single scene** | **chord > n_occ** (strongly monotonic) | see below |

**Within-scene evidence** (distance stratum × thin occlusion, chord split into three bands):

| Scene | Thin chord | Medium chord | Thick chord | Monotonic |
|---|---|---|---|---|
| frl_apartment_4 | +1.36 | +5.46 | **+8.40** | ✅ |
| frl_apartment_2 | +1.26 | +2.06 | **+5.45** | ✅ |
| frl_apartment_1 | +0.69 | +1.06 | **+2.16** | ✅ |
| frl_apartment_3 | +4.48 | +1.44 | +4.24 | ❌ |

**3 of 4 scenes increase monotonically, with effect sizes up to 7 dB.**

🔴 **But this "monotonicity" is not "incremental information"** —
C-29 has already overturned "chord is better within a scene" with a
classification experiment: replacing n_occ with chord changes the gain by
−0.001. Stratified monotonicity only shows chord is correlated with energy;
it does not show it carries more *incremental* information.

✅ **The correct conclusion from C-29**: chord is not a **substitute** for
n_occ but a **complement** — using both together (0.750) beats either alone
(0.714 / 0.713). The optimal feature set is **distance + chord + material =
0.775**.

**Why the two settings give opposite conclusions:**
the `chord` coefficient is **scene-specific** (C-23 has already shown that
material coefficients differ across scenes by 10.9 dB), so in a cross-scene
regression it is treated as noise; but **within a single scene** it is a
continuous, monotonic, large-effect **real physical variable**.

> **`n_occ` is a coarse discrete proxy; `chord` is a continuous real description.**
> Which one to use depends on the setting and the two cannot be treated alike.

**Refutation condition**: If, within a scene, replacing n_occ with chord does
not improve the classification gain, "chord is better within a scene" does not
hold.

### C-22 ✅ Material transmission ranking (gates passed, physically consistent)

| Item | Content |
|---|---|
| **Conclusion** | After controlling for distance and layer count, the net material effect ranks **door > blinds > curtain > shelf > rack** (the more positive, the more transparent) |
| **Gate** | All PASS: corr(residual, dist) < 0.15; all three physical-ordering checks pass |
| **Δ vs wall per material** | door **−1.25**, blinds −3.85, curtain −4.77, shelf −5.30, wall-cabinet −9.12, **rack −10.02** |
| **Physical checks** | door should be more transparent than wall ✅; curtain attenuates more ✅; rack attenuates more ✅ |
| **🔴 Pre-correction** | The material coefficients in `solution_a.json` are **not trustworthy** — material and layer count are collinear (window mean layer count +3.10), so its +49.85 dB is a layer-count effect and not a real gain |
| **Residual confounding** | Most materials average 1.0–1.7 more layers than the global mean, so the coefficients are still partly contaminated; pillar (n = 74) has too few samples |
| **Refutation condition** | If the ordering changes under a strict same-layer-count control, this ordering does not hold |
| **Confidence** | Medium-high (method sound, residual confounding not fully removed) |
| **Status** | **Valid** — the first material-transmission ordering extracted reliably from the data |

### C-23 🔴 Material coefficients are scene-specific, not material properties

| Item | Content |
|---|---|
| **Conclusion** | The net effect of the same material label differs by up to **10.9 dB** across scenes (wall: hotel_0 **−7.83** vs room_0 **+3.07**) |
| **Gate** | The finding itself passed the material-effect script's gates, but the **generality check failed** |
| **Verification 1: is a prior useful?** | Strict causal check (prior extracted from training scenes only): fixed prior A2 **0.579** < freely fitted A1 **0.622**, so **A2 − A1 = −0.043**, with only 2 of 5 scenes improving; hotel_0 falls from 0.312 to **0.209** |
| **Verification 2: are the coefficients stable?** | Coefficient standard deviations across training subsets are 0.28–1.19 dB, with consistent sign and magnitude → the **coefficients themselves are fine** |
| **Verification 3: does linear superposition fail?** | I offered this explanation first, then **overturned it myself** — the measured per-scene wall net effect differs by 10.9 dB, so the problem is not how the effects are combined but that the coefficients themselves are scene-specific |
| **Refutation condition** | If materials and thicknesses are described by their true physical values rather than semantic labels, cross-scene coefficient consistency should improve markedly |
| **Confidence** | Medium-high |
| **Status** | **Valid** — C-22's "material transmission ranking" must be downgraded to "the average behaviour over 5 scenes" and **must not be treated as an intrinsic property of the material** |

### C-24 ✅ Inference within a single scene is feasible (gates passed, R² 0.83)

| Item | Content |
|---|---|
| **Conclusion** | With strict rec/src separation within a scene, the cross-scene baseline R² **0.515** rises to **0.831** within a single scene (**+0.316**) |
| **Gate** | All PASS: test rec/src and training have **zero overlap** (asserted in code), R² ∈ [0, 1], scene count ≥ 3 |
| **Three splits compared** | A random (within scene) 0.840; **B by rec (new position) 0.831**; **C by src (new source) 0.833** |
| **🔴 Key check** | **B ≈ A (0.831 vs 0.840)** — if the model were memorising a rec baseline, B should be markedly below A. The two are nearly identical, which **proves no leakage occurred** |
| **Scenes above 0.8** | room_0 **0.931**, office_2 **0.901**, frl_apartment_2 0.836 |
| **Still weaker** | hotel_0 0.735 (unique material composition), apartment_0 0.751 |
| **Overfitting** | in-sample and test R² differ by < 0.04 (e.g. room_0 0.930 vs 0.931), **very small** |
| **Meaning for the research question** | **A robot does not need to generalise across rooms.** Inference within a single scene is the real requirement, and it side-steps the "material coefficients do not transfer" dead end |
| **Refutation condition** | If the by-rec result falls more than 0.10 below the random split, there is rec leakage and this conclusion must be weakened |
| **Confidence** | Medium-high (methodologically sound, n_scene = 5) |
| **Status** | **Valid** — the strongest positive result so far |

### 🔴 C-25 RETRACTED (2026-10-19 18:50) — original "single-scene existence AUC 0.894"

| Item | Content |
|---|---|
| **Original conclusion** | Single-scene existence inference is feasible, mean AUC 0.894 |
| **Reason for retraction** | **The leakage test aggregated the wrong way** — pooling statistics mixed frl_apartment_2 (distance median 4.03 m) with the other scenes (2.24 m), and the **between-scene distance difference masked the within-scene leakage** |
| **Recomputed per scene** | office_2 **72.3%**, room_0 **60.8%**, hotel_0 11.8%, frl_apartment_2 6.7% — mean **37.9%** |
| **Consequential retraction** | The "distance only" AUC of 0.580 (averaged away) is likewise untrustworthy |
| **Why it was hidden** | Not a wrong number but a **wrong test**, and it **happened to produce a "pass"** |
| **Rule** | **The leakage test must be done per scene.** A wrong aggregation turns a failing test into a passing one |
| **⚠ Same-source error** | `verify_section33.py` reproduced the same wrong aggregation, so its "23/23 passed" was a **false positive**. **A verification script must not share its implementation with the script it verifies** |

---

### C-26 ✅ Within a single scene, geometric information is significantly better than a distance-only baseline (holds after the criterion revision)

| Item | Content |
|---|---|
| **Conclusion** | Across 8 scenes, the **gain of geometric information over a distance-only baseline is positive in all 20 (scene × pos_frac) settings** (100%), exact binomial test **p = 9.54e-07** |
| **Gate** | G0 pass, G1 pass (leakage checked per scene), G2 pass, G3 pass (8 scenes), G7 pass, G10 pass (criterion form check) |
| **Evidence** | `criterion_revision.json`: criteria 1 / 2 / 3 all PASS |
| **Per-scene gain** (main setting pos_frac = 0.20) | hotel_0 **+0.349**, frl_apartment_4 +0.273, frl_apartment_2 +0.263, frl_apartment_3 +0.195, apartment_0 +0.150, frl_apartment_1 +0.098, office_2 +0.063, room_0 +0.031 |
| 🔴 **Wording correction** | **Not "the task is unsolvable in some scenes" but "every scene has geometric signal, but in 4 scenes that signal is drowned by room-pattern effects"** — even room_0's gain is positive (+0.031) |
| **Refutation condition** | If the sign of the gain reverses in the `band` or `min_per_bin` sensitivity sweeps (see `open_optimization_items.md`, optimisation item 0), this statement must be downgraded |
| ✅ **Parameter independence verified** | Under 8 scenes × 5 pos_frac × **4 non-noise frequency bands** × **4 min_per_bin levels**, the sign of the gain is consistently positive (all five gates of `param_sensitivity.json` pass) |
| **Band sweep** | Smallest per-scene gain: 0–500 Hz **+0.261**, 500–2000 +0.189, 2000–8000 **+0.176**, 8k–20k +0.191 — all signs positive |
| **min_per_bin sweep** | The 30 / 40 / 60 / 80 levels give **identical results** (every stratum has far more than 80 samples, so the threshold never binds) |
| 🔴 **"Lower frequencies are better" is an artefact** | On the surface, the 0–500 Hz mean gain is +0.285 against +0.257 for 2000–8000 Hz; but comparing only on the **3 scenes solvable in both bands**, the difference is **+0.001** → a **selection effect from differing subsets** |
| **Excluded** | The 20–22 kHz band sits near the noise floor (median −12.7 dB, min −31.3); it is reported separately and not used for the main conclusion |
| **Confidence** | **High** (parameter independence measured; the 20–22 kHz noise band excluded and explained) |
| **Status** | Valid and parameter-independent. The absolute AUC value (0.748) **should still not be quoted** (it drifts by 0.083 with pos_frac) |

### C-27 A threshold criterion on absolute AUC is unusable (methodological conclusion)

| Item | Content |
|---|---|
| **Conclusion** | The criterion form "mean AUC over solvable scenes ≥ 0.80" is **unusable**: for the same model on the same data, AUC drifts over **0.716–0.799** with pos_frac (span **0.083**, in the solvable-4-scene convention) |
| **Implication** | Any fixed AUC threshold will be crossed by a **researcher-chosen free parameter**, so whether the criterion passes is decided by nothing but the method's quality |
| **Alternative** | Use **sign consistency of the gain**: no threshold, only the requirement that "geometric information beats the distance-only baseline" holds in every parameter setting |
| **Refutation condition** | If the conclusion still drifts with parameters after switching to relative gain, then "directional robustness" is itself an artefact |
| **Status** | **Valid** (verified by `criterion_revision.py`) |

---

### C-32 Online calibration works, but there are two classes of scene: calibratable and not

| Item | Content |
|---|---|
| **Conclusion** | Calibrating on 5 receivers raises cross-scene AUC from **0.525 → 0.640** (recovering **64.4%**); but the **recovery rate is extremely uneven** — hotel_0 recovers **150%**, office_2 **−28%** |
| **Gate** | G1 pass (test/calibration receivers do not overlap), G3 pass (8 scenes), G7 pass (label independent of features) |
| **Evidence** | `online_calibration.json`, `online_calibration_report.md` |
| **Key M1 control** | **Changing only the chord coefficient** (features untouched) already reaches 0.576 (+0.051) → **the feature set is transferable and does not need relearning** |
| **Recovery sequence** | 0 receivers: 0%, 1: 28.7%, 2: 43.6%, 3: 52.5%, 5: **64.4%** (monotone but not saturated) |
| 🔴 **Heterogeneity (core finding)** | **Calibratable**: hotel_0 (0.397 → 0.856, 150%), frl_apartment_2 (116%). **Not calibratable**: office_2 (0.555 → 0.513, **−28%**), apartment_0 (−17%) |
| **Pattern** | **Rich material / occlusion structure → large calibration gain** (there is something for θ to estimate); **simple structure → no gain or harm** (θ carries little information, so calibration merely overfits) |
| 🔴 **Direct support for the research question** | **The same algorithm needs completely different amounts of prior information in different scenes, and the system cannot know in advance which kind of room it has entered.** So the system must carry not only geometric evidence but a belief state about **how confident it is in this room's mapping** |
| **Important corollary** | One output of the belief state should be **"when should I probe actively"** — this shifts the problem from "raise cross-scene AUC" to **"when should I admit I do not know"** |
| **Gate decision** | 🔴 **Target not met** (pre-written criterion ≥ 0.70, measured 0.640). But uncalibratable scenes were never going to benefit from calibration → **the criterion has to be set per scene class** (recorded as G10) |
| ✅ **Curve extrapolated to saturation** | 20 calibration receivers reach only **0.676** (marginal gain falls from +0.016 to **+0.002**) → **the remaining 0.027 is structural, not a shortage of probes** |
| **Quantitative recommendation** | **5 receivers is the cost-performance knee** (25% of the budget buys 64% of the recovery); 3 is the minimum acceptable; 20+ has diminishing returns |
| **Refutation condition** | ✅ **Already triggered**: calibrating 20+ receivers still does not exceed 0.70 → **the number of probes is not the bottleneck, the scene structure is** |
| **Confidence** | High (8 scenes × 5 calibration levels × 5 repeats) |
| **Status** | **Valid**, but the criterion needs revision |

### C-31 The root cause of cross-scene failure is scene-specific mapping coefficients, not insufficient features

| Item | Content |
|---|---|
| **Conclusion** | Cross-scene inference fails **not because the features overfit and not because features are missing**, but because the **mapping coefficients θ from geometry to acoustics depend on the scene**. Within-scene AUC **0.703** → cross-scene **0.524** (a drop of **0.179**) |
| **Gate** | G1 pass (leave-one-out per scene), G2 pass (coefficients measured across scenes), G7 pass (label independent of features) |
| **Evidence** | `cross_scene_diagnostic.md` |
| **Evidence 1: overfitting ruled out** | With leave-one-receiver-out, in-sample → held-out drops on average only **0.017** (one of the 8 scenes even **rises** by +0.005) → the features are effective at positions never seen in training |
| **Evidence 2: scene-specific coefficients** | The chord coefficient learned separately in each scene spans **0.518** (2.7× relative variation) |
| **Evidence 3: cross-scene drop** | hotel_0 **−0.470** (down to 0.397 ≈ chance), frl_apartment_3 −0.295, frl_apartment_2 −0.226 |
| 🔴 **Why hotel_0 is worst** | It has the **most distinctive material composition** of the 8 scenes (rack 36.9% + panel 11.3%, neither present elsewhere) → it depends most on material priors → a direct consequence of C-23 |
| **Already ruled out** | ① Feature overfitting (leave-one-receiver-out) ② Missing features (4 attempts: room attributes +0.006, material prior −0.043, rec bias −0.002) |
| **Wording correction** | It cannot be said that "cross-scene is harder". The accurate statement is: **the features are effective, but the coefficients are not transferable** |
| **Meaning for the research question** | The bottleneck is **not "not knowing how many layers occlude" but "not knowing this room's mapping coefficients θ"**. θ depends on true material transmission (not provided by Replica) and on room acoustics → **precisely what a belief state should express** |
| **Refutation condition** | If the online-calibration experiment shows that very few samples suffice to recover performance, then "a scene-adaptive mechanism is needed" should be refined to "a small amount of calibration suffices" |
| **Confidence** | High (8 scenes, three independent lines of evidence) |
| **Status** | **Valid** |

### C-30 🔴 The feature set should be "distance + chord + material"; n_occ adds nothing

| Item | Content |
|---|---|
| **Conclusion** | Under the full criterion (8 scenes × 5 pos_frac), the **chord feature set beats the n_occ feature set**: gain **+0.196** vs +0.178, and the **AUC drift is smaller** (0.059 vs 0.083) |
| **Gate** | All three feature sets **pass** all three criteria (gain sign positive in 20/20, p = 9.54e-07) |
| **Evidence** | `criterion_chord_mat.json` / `criterion_nocc_mat.json` / `criterion_nocc_chord_mat.json` |
| 🔴 **Key finding** | **`nocc_chord_mat` and `chord_mat` give identical results** (AUC 0.683, gain +0.196, drift 0.059) → **n_occ contributes nothing once chord is present** |
| **Per-scene improvement** | apartment_0 0.636 → **0.701** (+0.065), frl_apartment_4 0.763 → **0.803** (+0.040), hotel_0 0.844 → **0.860** (+0.016); room_0 0.507 → 0.530 |
| **Regressing scenes** | office_2 0.553 → 0.549, frl_apartment_1 0.588 → 0.581 (both are "weak-signal" scenes) |
| **Correction to C-29** | C-29 said "the two are complementary (both together 0.750 > either alone 0.714 / 0.713)" — that holds **when material is absent**; once material is added, **the increment of n_occ goes to zero** |
| **Recommended feature set** | **distance + chord + material** (simplified to distance + chord, since the material contribution is already contained in the physical information of chord) |
| **Refutation condition** | If, after adding more scenes, n_occ again shows a significant increment, "n_occ contributes nothing" must be revised |
| **Confidence** | High (8 scenes × 5 pos_frac, complete three-way comparison) |
| **Status** | **Valid** |

### C-29 🔴 C-21's "chord is better within a scene" is overturned

| Item | Content |
|---|---|
| **Conclusion** | Within a scene, replacing n_occ with chord changes the gain by **−0.001** (0.714 → 0.713), i.e. **no improvement** → **C-21's within-scene ranking does not hold** |
| **Gate** | G1 pass, G2 pass, G5 pass, G7 pass, G10 pass (per-scene evaluation valid: 4 distinct values) |
| **Evidence** | `chord_vs_nocc.json`: core comparison difference **−0.001**; 3 of 4 scenes improve but the mean is **−0.001** (frl_apartment_2 **−0.136** cancels the improvements elsewhere) |
| 🔴 **But they are complementary** | **n_occ + chord used together = 0.750**, above either alone (0.714 / 0.713) by **+0.036** |
| **Optimal feature set** | **distance + chord + material = 0.775** (gain +0.282), better than distance + n_occ + material (0.747) |
| **Correct statement** | **chord is not a substitute for n_occ but its complement.** The two describe occlusion from different angles: n_occ is "number of layers", chord is "total path length", the latter including diffraction information |
| **Refutation condition** | If, on more scenes, "both together" still does not exceed "n_occ alone", the complementarity does not hold either |
| **Confidence** | High (4 scenes + per-scene detail + three-way feature-set comparison) |
| **Status** | **Valid** (the within-scene part of C-21 is superseded by this) |

### C-28 The geometry–acoustics mapping is scene-dependent (diagnostic conclusion)

| Item | Content |
|---|---|
| **Conclusion** | The low geometric gain in the 4 "weak-signal" scenes (frl_apartment_1 / 3, office_2, room_0) is **not caused by insufficient sample size and not by differing material composition**, but by corr(energy, layer count) being close to zero **within comparable distance strata** — **the layer count genuinely does not produce an energy difference** |
| **Gate** | G1 pass (sample-size explanation ruled out), G2 pass (material explanation ruled out) |
| **Evidence** | `optimisation-diagnostic-1` (Chinese working report, not shipped): within-stratum corr(E, n_occ) = frl_apartment_4 **−0.565**, frl_apartment_2 **−0.500** vs frl_apartment_1 −0.117, frl_apartment_3 **−0.033** |
| **Explanations already ruled out** | ① **Insufficient samples** — frl_apartment_3 has **7 comparable strata** yet corr is only −0.033; ② **Different material composition** — the top-3 materials (wall 38–45%, door 26–33%, shelf 7–26%) are nearly identical |
| **Secondary factor** | Thin-occlusion samples dry up with distance (farthest stratum: 69–170 in solvable scenes, **0–1** in weak-signal scenes), but this only affects distant strata |
| 🔴 **Wording correction** | It cannot be said "these scenes lack geometric information". The correct statement is **"the layer count is not sufficient to characterise this scene's actual acoustic attenuation"** — **the geometric information may well be sufficient; what has changed is the mapping** |
| **Unverified candidates** | ① The occluders' effective thickness is much smaller than the layer count suggests ② Multipath interference masks it ③ **The simulation engine's occlusion transmission is not proportional to the geometric layer count** (the most worth checking first) |
| **Refutation condition** | If testing shows the within-stratum energy difference is dominated by multipath interference rather than occlusion transmission, "the mapping is scene-dependent" should be refined to "multipath effects mask the geometric signal in complex scenes" |
| **Confidence** | Medium-high (three alternative explanations ruled out by measurement, but the main cause is not yet identified) |
| **Status** | **Valid (an exclusion result)** — main cause still open |

---

## 2. Conditional conclusions (limited scope of validity)

### C-07 The independent contribution of chord varies across scenes

| Item | Content |
|---|---|
| **Conclusion** | After controlling for distance, the independent contribution of chord to acoustic energy ranges from 2.5% to 47.8% across 3 scenes, **a factor of 19** |
| **Gate** | G0 pass, G1 pass, G2 pass, **G3 fail** (3 scenes < 8; between-scene spread 14.6 dB) |
| **Evidence** | Residual method: hotel_0 47.8%, office_2 19.2%, room_0 2.5% |
| **Potential confounds** | ⚠ Pooled statistics hide collinearity (pooled corr(chord, dist) = +0.275 passes, but office_2 alone at +0.615 does not) |
| **Refutation condition** | Re-measured on 8 or more scenes, if the distribution of residual R² concentrates (e.g. all > 30%), then "scene dependence" is itself overturned |
| **Confidence** | Low (gate G3 not passed) |
| **Status** | **Conditional** — the wording must be limited to "observed in these 3 scenes" |

---

## 3. Retracted conclusions (retained as lessons)

| # | Original conclusion | What overturned it | Lesson |
|---|---|---|---|
| X-01 | BRIR data is usable | The directory prefix was two levels short | Rule 1: probe before asserting |
| X-02 | Path detection is fixed | Not verified; it still returned None | Rule 2: a fix must be measured |
| X-03 | WAV is PCM16 / 16 kHz | Actually float32 / 44.1 kHz | Rule 3: read bytes, not documentation |
| X-04 | The BRIR src is an object id | It is a navigation-point id | Rule 4: id spaces must be compared |
| X-05 | ILD left = az > 180 | Actually az < 180 | Rule 5: coordinate conventions must be tested exhaustively |
| X-06 | chord has no acoustic predictive power | The geometric path and the BRIR path were misaligned | **G0 alignment gate** |
| X-07 | chord has a −6.34 dB/m predictive power | Distance effect leaked in (corr = +0.615) | **G2 collinearity gate** |

---

## 4. Pending review

### P-01 The path convention of the P0-1 thin-occlusion candidates 🔴

| Item | Content |
|---|---|
| **Problem** | P0-1 (`occlusion_stats.py`) used `node_a.center → node_b.center`, i.e. **object to object**, whereas the BRIR path is between navigation points. The 6663 "thin-occlusion candidates" were selected under that convention |
| **Gate** | G0 **failed** |
| **Risk** | 🔴 High — if the candidate set uses the wrong convention, every later analysis based on the "6663 thin-occlusion candidates" has to be redone |
| **To do** | Confirm whether the P0-1 candidate filter should use the navigation-point path, or state explicitly that the two conventions differ |
| **Status** | **Pending review** |

### P-02 The P0-2 geometric baselines (B1 / B3 / B9)

| Item | Content |
|---|---|
| **Conclusion** | B1 pure geometry Top-10 7.9% ≈ B3 random 7.6%; B9 through-wall Top-10 12.39% |
| **Gate** | G2 **not checked** for collinearity |
| **Risk** | 🟡 Medium — if chord is collinear with distance, the attribution may be wrong |
| **To do** | Back-test the feature set of P0-2 with the gate script |
| **Status** | Pending review |

---

*Last updated 2026-10-13. Created after repeated overturning of earlier conclusions, at which point the research risk was judged too high to continue without a written record.*
