# Supplementary Material

**Manuscript:** What Geometry Knows About Hidden Sound Sources: Within-Scene
Validity and the Structural Limits of Cross-Scene Transfer

**Target journal:** Robotics and Autonomous Systems (Elsevier)

---

## What is here, and why

This package is organised around one goal: a reviewer should be able to check
every number in the paper, and understand why some results were withdrawn.

| Directory | Contents | Purpose |
|---|---|---|
| `data/core/` | The nine result files the manuscript cites directly | Every table and figure traces to one of these |
| `data/paired_samples/` | 5% deterministic sample of the per-pair label files | Lets a reviewer inspect raw records without a 140 MB download |
| `scripts/` | The analysis scripts that produced all numbers | Reproducibility |
| `documentation/` | Conclusion registry, gate specification, open-problem list | Why withdrawn results were withdrawn |
| `figures/` | The three manuscript figures | Generated from `data/core/` |
| `MANIFEST.json` | SHA-256 for every file | Integrity check |

---

## Mapping from manuscript to files

| Manuscript location | Source file |
|---|---|
| Table I (per-scene AUC and gain) | `data/core/criterion_chord_mat.json` |
| Table II (parameter sensitivity) | `data/core/param_sensitivity.json` |
| Table III (feature-set comparison) | `data/core/chord_vs_nocc.json` |
| Table IV (online calibration) | `data/core/online_calibration.json`, `data/core/calibration_curve.json` |
| Table V (eighteen-scene recheck) | `data/core/criterion_merged14.json`, field `rows` |
| Figure 1 (leakage diagnostics) | Historical; see `documentation/conclusion_registry.md` entry C-25 |
| Figure 2 (gain across class balances) | `data/core/criterion_chord_mat.json`, field `rows` |
| Figure 3 (calibration curve) | `data/core/calibration_curve.json` |
| Sec. 4.4 leakage diagnostics | `data/core/existence_v3_8scenes.json`, field `leak_diag` |
| Sec. 5.3 feature-set ablation | `data/core/criterion_nocc_mat.json`, `criterion_nocc_chord_mat.json` |
| Threats to Validity, eighteen-scene recheck | `data/core/criterion_merged14.json`; raw records in `data/paired_samples/pair_labels_new10_sample.json` |

Figures are regenerated from these files by `scripts/` plus the figure script
shipped with the manuscript source; every plotted value therefore traces to a
specific output record rather than being retyped.

---

## The eighteen-scene recheck

Table V of the manuscript repeats the full criterion analysis after acquiring
the ten Replica scenes that carry BRIRs but were absent from the first pass.
Three things about this result are worth stating explicitly, because each is a
finding rather than a confirmation:

1. **The main claim survives.** The geometric gain over a distance-only
   baseline is positive in all 22 valid settings of the pooled set, exact
   binomial $p = 2.4\times10^{-7}$— stronger than the eight-scene
   $p = 9.5\times10^{-7}$ because the set is larger.

2. **Most new scenes are structurally unsolvable, not weakly informative.**
   Four of the ten added scenes yield fewer than 2100 pairs and a negative or
   near-zero separation between the constructed labels and occlusion depth.
   They do not contain the task. This is why the solvable count rises from
   four to five rather than to eighteen.

3. **The highest \AUC{} in the pooled set belongs to an excluded scene.**
   `apartment_1` reaches 0.892 yet fails the solvability diagnostic
   (gap $+0.216$): its labels do not track occlusion depth, so the accuracy
   reflects a separation geometry does not explain. The solvable
   subset separately throughout, and exclude it here for the same reason.

The solvability diagnostic admits a scene if it passes at any class balance.
Under that rule `room_2` qualifies on two of five balances ($+0.281$ at
$p_f = 0.20$ rising to $+0.394$ at $0.30$); counting only scenes that pass at
every balance gives four rather than five. The former is retained for
comparability and flag `room_2` as borderline in Table V.

`scripts/verify_new_scenes.py` checks the acquired binaural data independently
of the download path: for every scene it confirms that the number of impulse
responses equals the square of the covered navigation-point count, which is the
known structure of the dataset. All fourteen scenes pass.

---

## Reproducing the analysis

### Prerequisites

| Requirement | Version used |
|---|---|
| Python | 3.9+ |
| NumPy | 1.x or 2.x |
| PyTorch | not required for the analysis scripts |
| Acoustic data | SoundSpaces BRIR over Replica (public, not redistributed here) |

The per-pair label files are derived from rendered impulse responses, so the
full pipeline needs the SoundSpaces dataset. It is not redistributed in this
package because of its size and its upstream licence; it is available from the
SoundSpaces project.

### Regenerating the per-pair records

```
python scripts/export_pair_labels.py --scenes <list> --out <path.json>
```

This reads the BRIR files and the Replica semantic annotations and emits, for
each listener--source pair, the band energy, distance, occlusion layer count,
traversed thickness, and material labels used throughout.

### Regenerating the reported results

Each script writes a JSON file matching the corresponding entry in
`data/core/`. The scripts are the same ones used to produce the manuscript, so
output should be byte-identical given identical inputs and arguments
(defaults match the reported settings: band 2000--8000 Hz, positive-class
fraction 0.20, 12 distance strata, minimum 40 pairs per stratum).

The exact command lines are not restated here because several scripts carry
WSL-specific defaults for the acoustic data paths. The argument parser at the
top of each file documents its options; the defaults reproduce the reported
settings.

---

## Note on withdrawn results

This study reports several analyses whose conclusions were **retracted during
the work**, and the reasons are recorded in
`documentation/conclusion_registry.md` (entries C-25 and the section of
retracted findings). That registry is included deliberately: two of the paper's
methodological points---that leakage diagnostics must be computed per scene,
and that a verification script must not share implementation with the script
it verifies---come directly from those failures, and a reviewer is better served
read the account than infer the caution from the text alone.

---

## Integrity

`MANIFEST.json` records the SHA-256 of every shipped file. To verify:

```
python - <<'EOF'
import json, hashlib, os
mf = json.load(open("MANIFEST.json"))
for group, items in mf["files"].items():
    for it in items:
        p = os.path.join(".", group, it["file"])
        h = hashlib.sha256(open(p, "rb").read()).hexdigest()
        print("OK " if h == it["sha256"] else "BAD", group, it["file"])
EOF
```

---

## Sampling of per-pair files

The per-pair label files total about 143 MB. Rather than ship them whole or
omit them, a 5% sample per scene is shipped, selected by a deterministic shuffle
with seed 20261020. Each sampled file records its own rate, seed, and original
count under a `_sampling` key, so the selection can be reproduced exactly. The
full files regenerate from `scripts/export_pair_labels.py`.

`data/paired_samples/pair_labels_new10_sample.json` holds the ten scenes
acquired after the first pass; `pair_labels_5scenes_sample.json` holds the
original set. Neither is merged into a single file, so the provenance of every
scene stays visible.

---

## What is NOT in this package

`references/` sits alongside the package on the author's machine but is **not part of
the submission**. It holds PDF copies of the cited papers, downloaded for
internal verification only; the copyright is the original authors' and they must not be
redistributed. `MANIFEST.json` lists only `data/core`,
`data/paired_samples`, `scripts`, `documentation`, and `figures`, which is
exactly what a reviewer should receive. The payload proper is about 7.3 MB.

Two intermediate artifacts are also excluded from `outputs/`: a merged
fourteen-scene pair-label file, and an early full-volume baseline superseded by
the five-scene version. Both regenerate from the shipped scripts, and shipping
them would only duplicate data.

---

## Files uploaded separately (not part of this package)

Three items go to the submission system as their own upload fields and are
therefore **not** in the package or in `MANIFEST.json`:

| File | Upload field | Note |
|---|---|---|
| `cover_letter.docx` | Cover Letter | Full version, 3 pages; includes the suggested-reviewer list with justifications |
| `cover_letter_short.docx` | Cover Letter | Two pages, same text minus the reviewer list, for when reviewers are entered in the dedicated system field instead |
| `highlights.docx` | Highlights | Five bullet points, each at most 85 characters including spaces |

The plain-text sources of the two documents above (`cover_letter.md` and
`highlights.txt`) are kept on the author's side for editing and are **not**
included in this package, since they are not review material. The `.docx`
files are regenerated from them by `md2docx_cover.py` and by the highlights
builder, so the two never drift apart. A LaTeX copy of the highlights,
`../highlights.tex`, exists only as a reference and is deliberately **not**
`\input` by `main.tex`: in this build of `elsarticle` the `highlights`
environment swallows the abstract outright, with no error raised.

---

*Assembled 2026-10-20; updated same day with the eighteen-scene recheck.*