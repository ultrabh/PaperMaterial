#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""核验移动硬盘上 10 个新场景的 BRIR 完整性。

背景：2026-10-20 的批量下载曾报0/10 成功，根因是 fetch_all_scenes.py
的already_have() 按 <dest>/replica/<scene>/ 查找 wav，而 SoundSpaces 的
压缩包解压后是双层前缀 <dest>/data/binaural_rirs/replica/<scene>/，
导致校验全��失败。数据本身完好。

本脚本独立复核，不复用 fetch_all_scenes 的路径逻辑（避免同源错误），
并用「导航点对完整笛卡尔积」这一已知性质做交叉校验：
若某场景有 N 个导航点，则应有 N^2 个 wav。

用法（Windows 或 WSL 均可）：
    python verify_new_scenes.py                 # 自动找 F 盘
    python verify_new_scenes.py --dest /mnt/f/fenzhi1_brir
"""
import argparse
import json
import os
import sys
from math import isqrt

# 已知 BRIR 性质（见长期记忆）：BRIR 是导航点对的完整笛卡尔积，
# 即N 个导航点 -> N^2 个 RIR。若数目不是完全平方数，说明文件缺失。
EXPECT_SCENES = [
    "office_1", "room_1", "office_0", "room_2", "office_3",
    "office_4", "apartment_2", "frl_apartment_0",
    "frl_apartment_5", "apartment_1",
]

# 下载时记录的压缩包大小（字节），用于交叉核对
SIZES = {
    "office_1": 0.10, "room_1": 0.45, "office_0": 0.36, "room_2": 0.86,
    "office_3": 1.39, "office_4": 1.93, "apartment_2": 6.74,
    "frl_apartment_0": 7.44, "frl_apartment_5": 9.82, "apartment_1": 10.69,
}


def locate_replica(dest):
    """独立定位 replica 目录：从已知子串出发，不依赖固定层级。"""
    cur = dest
    for _ in range(5):
        if os.path.basename(cur) == "replica":
            return cur
        for sub in ("replica", "data"):
            nxt = os.path.join(cur, sub)
            if os.path.isdir(nxt):
                cur = nxt
                break
        else:
            break
    #兜底：受限深度的广度搜索
    for dp, dn, _ in os.walk(dest):
        if os.path.basename(dp) == "replica" and dn:
            return dp
        if dp[len(dest):].count(os.sep) > 4:
            dn[:] = []
    return None


def count_wav(scene_dir):
    """统计该场景的 wav 数，同时返回导航点数（= sqrt）。"""
    azis = [d for d in os.listdir(scene_dir)
            if os.path.isdir(os.path.join(scene_dir, d))]
    total = 0
    per_azi = []
    for a in azis:
        p = os.path.join(scene_dir, a)
        n = len([f for f in os.listdir(p) if f.endswith(".wav")])
        per_azi.append(n)
        total += n
    return total, len(azis), per_azi


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", default=None)
    ap.add_argument("--out", default=None, help="结果 JSON 输出路径")
    args = ap.parse_args()

    dest = args.dest
    if dest is None:
        for c in ("F:/fenzhi1_brir", "/mnt/f/fenzhi1_brir",
                  "/f/fenzhi1_brir"):
            if os.path.isdir(c):
                dest = c
                break
    if dest is None or not os.path.isdir(dest):
        print("找不到目标目录，请用 --dest 指定")
        sys.exit(2)

    root = locate_replica(dest)
    print("=" * 72)
    print("BRIR 新场景完整性核验")
    print("=" * 72)
    print(f"  目标    : {dest}")
    print(f"  replica : {root}")
    if root is None:
        print("\n未找到 replica 目录")
        sys.exit(2)
    print()

    rows, all_ok = [], True
    print(f"  {'场景':<20}{'方位角':>7}{'导航点':>8}{'wav':>10}"
          f"{'期望N²':>10}  判定")
    print("  " + "-" * 68)

    for sc in EXPECT_SCENES:
        sd = os.path.join(root, sc)
        if not os.path.isdir(sd):
            print(f"  {sc:<20}{'--':>7}{'--':>8}{'--':>10}{'--':>10}  缺失")
            rows.append({"scene": sc, "ok": False, "reason": "missing"})
            all_ok = False
            continue

        total, n_azi, per_azi = count_wav(sd)
        npt = isqrt(total)
        square = npt * npt == total
        consistent = (len(set(per_azi)) == 1) if per_azi else False

        if square and consistent and total > 0:
            verdict = "OK"
        else:
            verdict = "不完整" if total else "空"
            all_ok = False

        print(f"  {sc:<20}{n_azi:>7}{npt:>8}{total:>10}"
              f"{npt * npt:>10}  {verdict}")
        rows.append({
            "scene": sc, "azimuths": n_azi, "n_points": npt,
            "n_wav": total, "is_square": square,
            "uniform_across_azimuth": consistent,
            "archive_gb": SIZES.get(sc), "ok": verdict == "OK",
        })

    print("  " + "-" * 68)
    n_ok = sum(1 for r in rows if r.get("ok"))
    print(f"\n  结论: {n_ok}/{len(EXPECT_SCENES)} 个场景完整")
    if n_ok == len(EXPECT_SCENES):
        print("  全部通过。可进入pair_labels 导出阶段。")
        print("  下一步：把该目录挂载到 WSL 后运行导出脚本")
    print()

    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump({"dest": dest, "replica_root": root,
                       "scenes": rows, "all_ok": all_ok},
                      fh, ensure_ascii=False, indent=2)
        print(f"  结果已写入 {args.out}")

    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())