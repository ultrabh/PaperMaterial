# LaTeX 环境安装与论文编译说明

> **建立日期**：2026-10-20
> **用途**：在新机器（工作站）上一次性复现论文编译环境
> **当前状态**：本机**尚未安装**（截至 2026-10-20 00:10 实测无 pdflatex）

---

## 一、结论先行

**用 MiKTeX，不用 TeX Live。**

| | MiKTeX | TeX Live (scheme-full) |
|---|---|---|
| 体积 | ~1 GB（按需增长） | 约 7 GB |
| IEEEtran 类 | ✅ **内置** | ✅ 内置 |
| 安装时长 | 几分钟 | 20+ 分钟 |
| 适合 | ✅ 编译单篇论文 | 出版级批量编译 |

**唯一硬性要求**：必须有 **IEEEtran**（RA-L 模板的文档类）。
两者都内置，此项不构成差别。

---

## 二、装 MiKTeX

### 前置检查（已实测本机现状）

```powershell
where pdflatex          # 应输出「找不到」
where winget            # ✅ 存在
where choco             # ✅ 存在
```

本机实测可用包（2026-10-20）：

```
winget: MiKTeX.MiKTeX   版本 25.12
choco : miktex.install  版本 25.3.0
```

### 方式 A：winget（推荐，版本较新）

```powershell
winget install --id MiKTeX.MiKTeX -e
```

### 方式 B：Chocolatey（winget 失败时用）

```powershell
choco install miktex.install -y
```

### 🔴 安装界面必须手动改的三项

**默认值不对，直接点下一步会导致编译时缺宏包。**

| # | 选项 | 选什么 | 为什么 |
|---|---|---|---|
| 1 | 安装范围 | **Just for me** | All users 可能触发 UAC 且污染系统环境变量 |
| 2 | 包安装模式 | **Install missing packages on-the-fly** | 否则编译时报缺包还要手动补 |
| 3 | 安装路径 | 建议 `D:\tex\miktex` | C 盘余量有限（本机仅剩 53 GB） |

### 验证

**必须新开一个 PowerShell 窗口**（PATH 不刷新会找不到命令）：

```powershell
pdflatex --version
```

---

## 三、装编辑器（可选，强烈建议）

```powershell
choco install texstudio -y
```

比命令行顺手：语法高亮、公式预览、**PDF 正向同步**（改代码自动跳到对应位置）。
本机已确认可用：`texstudio` 4.9.8。

---

## 四、编译本文

```powershell
cd D:\fenzhi1\paper
latexmk -pdf main.tex
```

首次编译会自动下载缺失宏包（`IEEEtran`、`algpseudocode`、`hyperref` 等），
**需联网、可能几分钟**。

### 产物

| 文件 | 用途 |
|---|---|
| `main.pdf` | 投稿用 |
| `main.log` | **出错先看这个** |
| `main.aux` / `.bbl` / `.blg` | 中间文件，可删 |

### 常用参数

| 命令 | 用途 |
|---|---|
| `latexmk -pdf main.tex` | 完整编译（自动跑够次数） |
| `latexmk -pdf -C main.tex` | 清理中间文件后重编 |
| `latexmk -pdf -view=none main.tex` | 不弹 PDF 窗口（远程/工作站用） |
| `latexmk -pdf -interaction=nonstopmode main.tex` | 出错不停（便于看全部错误） |

---

## 五、⚠️ RA-L 页数限制（编译后必查）

**RA-L 是 6 页 + 最多 2 页超页费**。

初稿约 7 900 词 + 3 图 + 4 表，**估算大致吻合但未经验证**。
编译后必须确认实际页数。

若超页，删减优先级（预判）：

1. **Threats to Validity**（现写得最详细，可压缩最多）
2. Related Work 第四段（物理先验综述，可并入第一节）
3. Protocol 中的数据三项属性（第 3 项 RT60 不可测，可并入 Threats）

**不要删**：数据必须保留 Table~\ref{tab:main} 与 Fig.~\ref{fig:gain}，
它们是「单场景有效」这一核心主张的唯一证据。

---

## 六、工作站上的注意事项

工作站若要编译，**注意两点**：

| 项 | 说明 |
|---|---|
| **磁盘位置** | 项目在 D 盘。工作站若没有 D 盘，需改 `main.tex` 里的相对路径（目前全是相对路径，应可直接移植） |
| **不需要重新下载数据** | 编译只依赖 `.tex` / `.bib` / `figures/`，**与 BRIR 数据无关** |

> **不建议为编译专门在工作站上装 TeX Live。**
> 本机 MiKTeX 一小时能搞定的事，不值得折腾。
> 工作站留给补 10 个场景的 BRIR（约 19 GB），价值大得多。

---

## 七、常见问题

### 编译报 `LaTeX Error: File 'IEEEtran.cls' not found`

MiKTeX 没装 IEEEtran（选 Just for me 时）。手动装：

```powershell
mpm --install IEEEtran
```

`mpm` 是 MiKTeX 的包管理器，随 MiKTeX 一同安装。

> 若你当初选的是 All users，加 `--admin`：`mpm --admin --install IEEEtran`

### 编译报缺某个宏包，但 on-the-fly 模式已开

联网状态问题。先离线跑一次让 MiKTeX 列出缺什么：

```powershell
miktex --install-local-package <包名>
```

### `latexmk` 命令不存在

MiKTeX 自带 `latexmk`，但可能未进 PATH。本文用 **BibTeX**（`\bibliographystyle{IEEEtran}`），
不是 biblatex，手动编译顺序为：

```powershell
pdflatex main.tex     # 第1遍：生成 .aux
bibtex main            # 处理参考文献，生成 .bbl
pdflatex main.tex     # 第2遍：插入参考文献
pdflatex main.tex     # 第3遍：交叉引用收敛
```

### 中文乱码 / 编译中断

本文是纯英文 LaTeX，不涉及 CJK。若 `refs.bib` 里的中文注释引起问题，
删掉注释即可（当前 `.bib` 全英文，应无此问题）。

---

## 八、一页速查

```powershell
# 全新机器，从零到编译成功
winget install --id MiKTeX.MiKTeX -e     # 界面里改 3 项设置
choco install texstudio -y               # 可选
# 重开 PowerShell
cd D:\fenzhi1\paper
latexmk -pdf main.tex
```

---

*创建：2026-10-20。起因：论文写完但本机无 LaTeX，需编译验证页数。*