#!/usr/bin/env python
"""Generate the paper figures.

Every value is read from measured results in D:/fenzhi1/outputs/*.json.
Nothing is hard-coded except fig. 1, which replays a recorded historical
diagnostic (the pooled-vs-per-scene leakage recomputation of C-25) and is
labelled as such in the caption.

Run with the project venv:
    .venv\\Scripts\\python.exe make_figures.py
"""
import json
import os

import matplotlib
matplotlib.use("Agg")          # headless: must precede pyplot import
import matplotlib.pyplot as plt
import numpy as np

OUT = r"D:\fenzhi1\outputs"
FIG = r"D:\fenzhi1\paper\figures"
os.makedirs(FIG, exist_ok=True)

BLUE = "#1f6fb4"
RED = "#c0392b"
GREY = "#7f8c8d"
DARK = "#2c3e50"
TICK = "#5a6570"

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 7,
    "axes.labelsize": 7,
    "axes.titlesize": 7.5,
    "xtick.labelsize": 6.5,
    "ytick.labelsize": 6.5,
    "legend.fontsize": 6.2,
    "pdf.fonttype": 42,        # embed as TrueType, editable in Illustrator
    "ps.fonttype": 42,
    "axes.linewidth": 0.5,
    "xtick.major.width": 0.5,
    "ytick.major.width": 0.5,
    "xtick.major.size": 2.2,
    "ytick.major.size": 2.2,
})


def load(name):
    with open(os.path.join(OUT, name), "r", encoding="utf-8") as fh:
        return json.load(fh)


def style(ax, grid_axis="y"):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(DARK)
    ax.spines["bottom"].set_color(DARK)
    if grid_axis:
        ax.grid(axis=grid_axis, color="#e2e6ea", linewidth=0.4, zorder=0)
        ax.set_axisbelow(True)
    ax.tick_params(colors=TICK, labelcolor=DARK)


def save_fig(fig, name):
    """Save both PDF (vector, for LaTeX) and PNG (for the Word version).

    The Word version of the manuscript cannot embed the vector PDF directly,
    so both are produced from the same figure object -- they can never drift.
    """
    fig.savefig(os.path.join(FIG, name + ".pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(FIG, name + ".png"), bbox_inches="tight",
                dpi=400)


# ==================================================================== Fig 1
def fig_leakage():
    """Per-scene vs pooled leakage diagnostic (historical record)."""
    scenes = ["office_2", "room_0", "hotel_0", "frl_ap.2"]
    per_scene = [72.3, 60.8, 11.8, 6.7]
    pooled = 13.1

    fig, ax = plt.subplots(figsize=(3.25, 1.85))
    x = np.arange(len(scenes))
    w = 0.36

    ax.bar(x - w / 2, per_scene, w, color=RED, label="Per-scene",
           edgecolor="white", linewidth=0.4, zorder=3)
    ax.bar(x + w / 2, [pooled] * len(scenes), w, color=GREY, label="Pooled",
           edgecolor="white", linewidth=0.4, zorder=3)

    ax.axhline(20, color=DARK, linestyle=(0, (3, 2)), linewidth=0.7, zorder=4)
    ax.text(len(scenes) - 0.52, 22.5, "20% reject", fontsize=5.8,
            color=DARK, ha="right")

    for xi, v in zip(x - w / 2, per_scene):
        ax.text(xi, v + 1.8, f"{v:.0f}", ha="center", fontsize=6,
                color=RED, zorder=5)
    ax.text(x[0] + w / 2, pooled + 1.8, f"{pooled:.1f}", ha="center",
            fontsize=6, color=GREY, zorder=5)

    ax.set_xticks(x)
    ax.set_xticklabels(scenes)
    ax.set_ylabel("distance-median gap (%)")
    ax.set_ylim(0, 88)
    ax.set_xlabel("scene")
    style(ax)
    ax.legend(frameon=False, loc="upper right", handlelength=1.1,
              borderpad=0.2)
    fig.tight_layout(pad=0.35)
    save_fig(fig, "leakage")
    plt.close(fig)


# ==================================================================== Fig 2
def fig_calibration():
    """Online-calibration curve and per-scene heterogeneity."""
    cc = load("calibration_curve.json")
    keys = ["M0", "M1", "M2", "M3", "M5", "M8", "M12", "M20"]
    xs = [0, 1, 2, 3, 5, 8, 12, 20]
    ys = [cc["summary"][k]["mean_auc"] for k in keys]
    ref = cc["in_scene_reference"]

    per = {p["scene"]: p for p in cc["per_scene"]}
    deltas = sorted(((s, p["M5"] - p["M0"]) for s, p in per.items()),
                    key=lambda t: t[1])

    fig, axes = plt.subplots(1, 2, figsize=(3.45, 1.85),
                             gridspec_kw={"wspace": 0.62,
                                          "width_ratios": [1.0, 1.0]})

    # ---- left: calibration curve
    ax = axes[0]
    ax.plot(xs, ys, "o-", color=BLUE, markersize=3.0, linewidth=1.1,
            zorder=3, label="calibrated")
    ax.axhline(ref, color=RED, linestyle=(0, (3, 2)), linewidth=0.8,
               zorder=2, label="in-scene")
    ax.annotate(f"{ref:.3f}", (20, ref), xytext=(1.5, -3.2),
                textcoords="offset points", fontsize=5.8, color=RED)
    ax.annotate(f"{ys[-1]:.3f}", (20, ys[-1]), xytext=(1.5, -4.5),
                textcoords="offset points", fontsize=5.8, color=BLUE)
    ax.annotate(f"{ys[0]:.3f}", (0, ys[0]), xytext=(1.0, 2.0),
                textcoords="offset points", fontsize=5.8, color=BLUE)
    ax.set_xlabel("probe receivers")
    ax.set_ylabel("mean AUC (8 scenes)")
    ax.set_xlim(-1.2, 25)
    ax.set_ylim(0.49, 0.755)
    ax.set_xticks([0, 5, 10, 15, 20])
    ax.legend(frameon=False, loc="lower right", handlelength=1.4,
              borderpad=0.2)
    style(ax)

    # ---- right: per-scene gain
    ax = axes[1]
    names = [d[0].replace("frl_apartment_", "frl_apt_") for d in deltas]
    vals = [d[1] for d in deltas]
    yy = np.arange(len(vals))
    ax.barh(yy, vals, 0.6,
            color=[RED if v < 0 else BLUE for v in vals],
            edgecolor="white", linewidth=0.3, zorder=3)
    ax.axvline(0, color=DARK, linewidth=0.6, zorder=4)
    ax.set_yticks(yy)
    ax.set_yticklabels(names, fontsize=5.6)
    ax.set_xlabel(r"$\Delta$ AUC after 5 probes")
    # Value labels are placed to the right of every bar, including negative
    # ones, so they can never collide with the scene labels on the y axis.
    ax.set_xlim(-0.055, 0.60)
    for yi, v in zip(yy, vals):
        ax.text(max(v, 0.0) + 0.018, yi, f"{v:+.3f}",
                va="center", ha="left", fontsize=5.4, color=DARK, zorder=5)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)
    ax.spines["bottom"].set_color(DARK)
    ax.set_axisbelow(True)
    ax.tick_params(axis="y", length=0, pad=1.5)
    ax.tick_params(colors=TICK, labelcolor=DARK)

    fig.tight_layout(pad=0.35)
    save_fig(fig, "calibration")
    plt.close(fig)


# ==================================================================== Fig 3
def fig_gain_landscape():
    """Per-scene gain across positive-class fractions."""
    cm = load("criterion_chord_mat.json")
    rows = cm["rows"]
    scenes = sorted({r["scene"] for r in rows})
    pfs = cm["pos_fracs"]

    cmap = plt.get_cmap("viridis")
    fig, ax = plt.subplots(figsize=(3.45, 2.05))

    for i, sc in enumerate(scenes):
        rs = sorted([r for r in rows if r["scene"] == sc],
                    key=lambda r: r["pos_frac"])
        ax.plot([r["pos_frac"] for r in rs], [r["gain"] for r in rs],
                "o-", markersize=2.7, linewidth=1.0, zorder=3,
                color=cmap(i / max(len(scenes) - 1, 1)),
                label=sc.replace("frl_apartment_", "frl_apt_"))

    ax.axhline(0, color=RED, linestyle=(0, (3, 2)), linewidth=0.8, zorder=4)
    ax.text(0.303, 0.012, "no gain", fontsize=5.8, color=RED, ha="right")

    ax.set_xlabel("positive-class fraction  $p_f$")
    ax.set_ylabel("gain over distance-only baseline")
    ax.set_xticks(pfs)
    ax.set_xlim(0.093, 0.307)
    ax.set_ylim(-0.02, 0.46)
    style(ax)
    ax.legend(frameon=False, ncol=2, handlelength=1.3, columnspacing=0.9,
              borderpad=0.15, labelspacing=0.28,
              loc="upper center", bbox_to_anchor=(0.52, 1.0))
    fig.tight_layout(pad=0.35)
    save_fig(fig, "gain_landscape")
    plt.close(fig)


if __name__ == "__main__":
    for fn in (fig_leakage, fig_calibration, fig_gain_landscape):
        fn()
    print("written to", FIG)
    for f in sorted(os.listdir(FIG)):
        print(f"  {f:24s} {os.path.getsize(os.path.join(FIG, f)):8d} bytes")
