"""
在线校准实验：机器人进入新场景后需要多少探测样本才能恢复判断力
================================================================================
要回答什么
------------
C-31 已定位跨场景失败根因：**映射系数 θ 场景特异**
（场景内 AUC 0.703 → 跨场景 0.524；chord 系数跨度 0.518）。

现实中的机器人**不会瞬移到另一个房间**——
它进入新场景后，可以**先测几条已知声源**来估计 θ。

本实验定量回答：**需要多少校准样本？**

🔴 校准的真实约束
----------------
必须严格模拟「机器人只知道极少信息」：

| 真实约束 | 本实验的实现 |
|---|---|
| 校准样本来自**少数几个 rec** | 只给 1 / 2 / 3 / 5 个 rec |
| 校准样本的**标签已知**（能量可测） | 用该rec 的全部样本拟合 θ |
| 测试样本的rec **未参与校准** | 代码层面断言 |
| 训练场景**不含**目标场景 | 留一法|

🔴 四种基线（必须区分）
----------------------
| 方法 | 校准样本 | 回答的问题 |
|---|---|---|
| **M0 无校准** | 0个 rec | 完全跨场景（当前水平） |
| **M1 纯系数迁移** | 0 个 rec，但**允许改系数** | 只调 θ，特征不变 |
| **M2 校准 1 个 rec** | 1 个 rec | 探测一次够不够 |
| **M3 校准 k 个 rec** | k = 2, 3, 5 | 探测几次够 |

M1 很关键：它区分「**需要重新学特征**」与「**只需改系数**」。

若 M1 ≈ M2，说明**只要能估 θ 就行，特征不必动** —— 那是最理想的情况。

sanity check
------------
1. **测试 rec 与校准 rec 零重叠**（代码断言）
2. 训练场景不含目标场景（留一法）
3. 标签由【距离层内能量最低 pf】定义，**独立于特征**（G7）
4. 校准样本数须与测试样本数分开报告，防止混淆

输出：/mnt/d/fenzhi1/outputs/online_calibration.json
"""

import argparse
import json
import math
import os
import statistics
import sys

import numpy as np


def db(x):
    return 10.0 * math.log10(max(float(x), 1e-300))


def auc_score(y_true, score):
    y = np.asarray(y_true)
    s = np.asarray(score, dtype=float)
    n_pos = int((y == 1).sum())
    n_neg = int((y == 0).sum())
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    order = np.argsort(s)
    ranks = np.empty(len(s), dtype=float)
    ranks[order] = np.arange(1, len(s) + 1)
    _, inv, cnt = np.unique(s, return_inverse=True, return_counts=True)
    sums = np.zeros(len(cnt))
    np.add.at(sums, inv, ranks)
    ranks = (sums / cnt)[inv]
    return float((ranks[y == 1].sum()
                  - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def main():
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except Exception:      # noqa: BLE001
        pass

    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", nargs="+", required=True)
    ap.add_argument("--band", default="2000-8000")
    ap.add_argument("--n-bins", type=int, default=12)
    ap.add_argument("--pos-frac", type=float, default=0.20)
    ap.add_argument("--min-per-bin", type=int, default=40)
    ap.add_argument("--cal-recs", nargs="+", type=int,
                    default=[0, 1, 2, 3, 5])
    ap.add_argument("--n-repeats", type=int, default=5)
    ap.add_argument("--out",
                    default="/mnt/d/fenzhi1/outputs/online_calibration.json")
    args = ap.parse_args()

    data = {}
    for f in args.pairs:
        with open(f, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
        for sc, v in raw.get("scenes", {}).items():
            for p in v.get("pairs", []):
                if "energy" not in p:
                    continue
                data.setdefault(sc, []).append({
                    "rec": p["rec"], "dist": p["dist"],
                    "chord": p["chord"], "occ": p["occ_classes"],
                    "E": db(p["energy"][args.band]),
                })
    scenes = sorted(data)
    mats = sorted({m for rs in data.values() for r in rs
                   for m in r["occ"]})

    def make_labels(rs):
        d = np.array([r["dist"] for r in rs])
        E = np.array([r["E"] for r in rs])
        edges = np.unique(np.quantile(d, np.linspace(0, 1,
                                                     args.n_bins + 1)))
        lab = np.full(len(rs), -1, dtype=int)
        for i in range(len(edges) - 1):
            lo, hi = edges[i], edges[i + 1]
            m = (d >= lo) & ((d <= hi) if i == len(edges) - 2
                             else (d < hi))
            if m.sum() < args.min_per_bin:
                continue
            k = max(5, int(m.sum() * args.pos_frac))
            idx = np.where(m)[0]
            order = idx[np.argsort(E[idx])]
            lab[order[:k]] = 1
            lab[order[k:]] = 0
        return [dict(r, label=int(l)) for r, l in zip(rs, lab) if l >= 0]

    def design(rs):
        n = len(rs)
        X = np.zeros((n, 2 + len(mats)))
        X[:, 0] = 20 * np.log10(np.maximum([r["dist"] for r in rs], 1e-3))
        X[:, 1] = [float(r["chord"]) for r in rs]
        for j, m in enumerate(mats):
            X[:, 2 + j] = [1.0 if m in r["occ"] else 0.0 for r in rs]
        X[:, -1] = 1.0
        return X

    L = {sc: make_labels(data[sc]) for sc in scenes}
    L = {sc: v for sc, v in L.items() if len(v) >= 300}

    print("=" * 74)
    print("在线校准实验：需要多少探测样本？")
    print("=" * 74)
    print(f"  场景 {len(L)}，频带 {args.band}")
    print(f"  校准 rec 数：{args.cal_recs}")
    print()

    print("-" * 74)
    print("逐场景结果（留一法：训练 7 场景 + 校准 k 个 rec）")
    print("-" * 74)
    header = f"  {'场景':<20s}{'M0 无校准':>10s}{'M1 仅调θ':>10s}"
    for k in args.cal_recs:
        if k > 0:
            header += f"{f'M{k} 校准{k}rec':>13s}"
    print(header)
    print("  " + "-" * (30 + 13 * len([k for k in args.cal_recs if k > 0])))

    rows = []
    for sc in scenes:
        if sc not in L:
            continue
        rs = L[sc]
        y_te = np.array([r["label"] for r in rs])
        X_te = design(rs)
        recs = sorted({r["rec"] for r in rs})
        if len(recs) < 6:
            continue
        others = [r for s2 in scenes if s2 != sc for r in L.get(s2, [])]
        if not others:
            continue
        y_tr = np.array([r["label"] for r in others]).astype(float)
        X_tr = design(others)
        c_tr, *_ = np.linalg.lstsq(X_tr, y_tr, rcond=None)

        # M0：完全跨场景（系数也不调）
        a_m0 = auc_score(y_te, X_te @ c_tr)

        # M1：纯系数迁移 —— 特征不动，只调 chord 系数
        #做法：用「校准 rec 的残差」反推应调整多少
        res_m = {}
        rng0 = np.random.RandomState(8000)
        perm0 = rng0.permutation(len(recs))
        cal1 = {recs[perm0[0]]}
        a_m1 = []
        for _ in range(args.n_repeats):
            c_adj = c_tr.copy()
            cal_rs = [r for r in rs if r["rec"] in cal1]
            if not cal_rs:
                continue
            Xc = design(cal_rs)
            yc = np.array([r["label"] for r in cal_rs], dtype=float)
            cc, *_ = np.linalg.lstsq(Xc, yc, rcond=None)
            # 只调整 chord 系数（特征列），其余保持
            c_adj[1] = cc[1]
            a_m1.append(auc_score(y_te, X_te @ c_adj))
        a_m1 = statistics.mean(a_m1) if a_m1 else float("nan")

        row = {"scene": sc, "n": len(rs), "M0": a_m0, "M1": a_m1}

        # Mk：校准 k 个 rec，完全重估 θ
        for k in args.cal_recs:
            if k <= 0:
                continue
            acc = []
            for rep in range(args.n_repeats):
                rng = np.random.RandomState(8100 + rep)
                perm = rng.permutation(len(recs))
                cal = {recs[i] for i in perm[:k]}
                cal_rs = [r for r in rs if r["rec"] in cal]
                te_rs = [r for r in rs if r["rec"] not in cal]
                # ✅ sanity：校准 rec 与测试 rec 必须零重叠
                assert not (cal & {r["rec"] for r in te_rs}), \
                    "校准/测试 rec 重叠"
                if len(te_rs) < 100 or not cal_rs:
                    continue
                Xc = design(cal_rs)
                yc = np.array([r["label"] for r in cal_rs], dtype=float)
                cc, *_ = np.linalg.lstsq(Xc, yc, rcond=None)
                Xt = design(te_rs)
                yt = np.array([r["label"] for r in te_rs])
                acc.append(auc_score(yt, Xt @ cc))
            a = statistics.mean(acc) if acc else float("nan")
            row[f"M{k}"] = a
        rows.append(row)

        line = f"  {sc:<20s}{a_m0:>10.3f}{a_m1:>10.3f}"
        for k in args.cal_recs:
            if k > 0:
                v = row.get(f"M{k}", float("nan"))
                line += f"{v:>13.3f}"
        print(line)

    print()
    print("=" * 74)
    print("汇总（跨场景平均）")
    print("=" * 74)
    methods = ["M0", "M1"] + [f"M{k}" for k in args.cal_recs if k > 0]
    summary = {}
    print(f"\n  {'方法':<16s}{'平均AUC':>10s}{'vs M0':>9s}")
    print("  " + "-" * 35)
    base = statistics.mean(r["M0"] for r in rows)
    for m in methods:
        vals = [r[m] for r in rows if m in r and r[m] == r[m]]
        if not vals:
            continue
        mv = statistics.mean(vals)
        summary[m] = {"mean_auc": mv, "vs_M0": mv - base}
        print(f"  {m:<16s}{mv:>10.3f}{mv - base:>+9.3f}")
    print()

    # ---- 关键判读 ----
    print("  判读")
    print("  " + "-" * 50)
    m1 = summary.get("M1", {}).get("mean_auc", float("nan"))
    if not (m1 == m1) or abs(m1 - base) < 0.03:
        print("  → M1 ≈ M0：**系数完全不可迁移**，")
        print("    校准必须重新估计**整个 θ 向量**，不只是 chord 项")
    else:
        print(f"  → M1({m1:.3f}) 明显优于 M0({base:.3f})："
              "**只调 chord 系数就有效**")

    best_k = None
    for k in args.cal_recs:
        if k <= 0:
            continue
        v = summary.get(f"M{k}", {}).get("mean_auc")
        if v is not None and v == v and v >= 0.70:
            best_k = k if best_k is None else min(best_k, k)
    print()
    if best_k:
        print(f"  ✅ 校准 **{best_k} 个 rec** 即可达AUC ≥ 0.70")
        v = summary[f"M{best_k}"]["mean_auc"]
        print(f"     （M0={base:.3f} → M{best_k}={v:.3f}，恢复 "
              f"{(v-base)/(0.703-base)*100:.0f}% 场景内水平）")
        verdict = f"{best_k} 个 rec"
    else:
        print("  🔴 即使校准 5 个 rec 也未达 0.70")
        v5 = summary.get("M5", {}).get("mean_auc")
        if v5:
            print(f"     （M5={v5:.3f}，M0={base:.3f}）")
        verdict = "校准无效"

    ok = best_k is not None
    out = {"band": args.band, "scenes": sorted(L), "per_scene": rows,
           "summary": summary, "baseline_cross_scene": base,
           "in_scene_reference": 0.703,
           "cal_recs_tested": args.cal_recs,
           "min_recs_for_070": best_k, "verdict": verdict,
           "gate_pass": bool(ok)}
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print(f"\n  门禁：{'✅ 校准可行' if ok else '🔴 校准无效'}")
    print(f"\n结果已保存: {args.out}")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
