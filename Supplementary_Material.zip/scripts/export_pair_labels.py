"""
导出逐对几何标签 —— 声学交叉分析的前置
================================================================================
为什么需要这个
--------------
P0-1（`occlusion_stats.py`）只保存**聚合计数**，不保存逐对明细。
因此无法把 BRIR 能量按「无遮挡 / 薄 / 中等 / 厚」分组对比——
而这正是判定「几何薄遮挡 → 声学可达」的核心分析。

自测（`brir_selftest.json`）已证明：无筛选抽样的频带跨度仅 5.7–9.3 dB
（office_2 / room_0），远低于 20 dB 门槛。原因是样本混合了全部遮挡类型，
混样本总跨度 ≠ 组间差异。必须按几何标签分层后才能判断区分度。

本脚本做什么
------------
对指定场景，重跑 P0-1 的几何计算（复用同一套函数与阈值，保证口径一致），
导出**逐对**记录：

    {scene, rec, src, rec_pt_idx, src_pt_idx, dist, chord, chord_class,
     occluder_classes, angle}

其中 `angle` 记录该对在四个朝向（0/90/180/270）下**是否存在 BRIR**——
因为 BRIR 按角度分目录，不是所有对都有。

输出
----
`outputs/pair_labels_{scene}.json`  或  合并版 `pair_labels.json`

口径一致性（重要）
------------------
- chord 计算复用 `occlusion_stats.segment_aabb_chord`，不重写
- 分类阈值复用 config（薄 <0.15 m，中等 <0.50 m，其余厚）
- 遮挡物集合复用 config 的 `occluder_categories`

🔴🔴 BRIR 的编号含义（实测确定，2026-10-11）
-------------------------------------------
**BRIR 的 `rec` 与 `src` 都是 `points.txt` 的导航点编号，不是物体 id。**

实测证据：

| 场景 | points.txt 行数 | BRIR 每角度对数 | BRIR 涉及节点 | 关系 |
|---|---|---|---|---|
| office_2 | 104 | 1369 | 37 | 1369 = 37² |
| hotel_0 | 102 | 2304 | 48 | 2304 = 48² |
| room_0 | 136 | 2601 | 51 | 2601 = 51² |

且 office_2 的 1369 对经检验为**完整笛卡尔积**（含自配对 i,i）。
`rec`/`src` 编号 100% 落在 points.txt 的 id 范围内。

**正确对齐方式**：遍历导航点对。

🔴🔴 几何路径必须是「导航点→导航点」（2026-10-12 修正）
----------------------------------------------------
早期版本用「物体中心 → rec 导航点」，但 BRIR 声源在 **src 导航点**上，
两者不是同一条传播路径：

| 路径 | chord 中位 | 与能量的关系 |
|---|---|---|
| A 物体中心 → 导航点 | 0.644 m | 非单调 |
| **B 导航点 → 导航点** | **0.115 m** | **单调** |

A 路径 chord 是 B 的 **5.6 倍**，测的不是 BRIR 对应的路径，
曾据此得出「chord 无声学预测力」的**伪结论**
（证据清单 5.8、5.13）。

本脚本现同时输出两路径：`chord`/`chord_class` 为 **B 路径**（主判据），
`chord_A`/`chord_class_A` 供对比。

早期版本错误地假设 `src` 是物体 `id`，导致 1369 对只匹配上 1 对。

用法（WSL 内）
--------------
  /opt/conda/envs/habitat/bin/python export_pair_labels.py \
      --config ../configs/replica.yaml --scenes office_2 hotel_0 room_0
"""

import argparse
import json
import os
import sys
from collections import defaultdict

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from replica_objects import load_replica_objects   # noqa: E402
from occlusion_stats import segment_aabb_chord   # noqa: E402
from measure_acoustic_reachability import (   # noqa: E402
    find_rir_base, read_wav, band_energy, energy_db, parse_pair)


def load_points(meta_dir, scene):
    """读points.txt，返回坐标数组与索引列表。"""
    for cand in (os.path.join(meta_dir, "replica", scene, "points.txt"),
                 os.path.join(meta_dir, scene, "points.txt")):
        if os.path.exists(cand):
            pts = []
            with open(cand, "r") as fh:
                for line in fh:
                    p = line.split()
                    if len(p) >= 4:
                        try:
                            pts.append([int(float(p[0])),
                                        float(p[1]), float(p[2]), float(p[3])])
                        except ValueError:
                            continue
            if pts:
                return np.array(pts, dtype=float)
    return None


def build_rir_index(rir_root, scene):
    """
    扫描 BRIR 实际存在的 (rec, src) 对与角度。

    返回 {(rec, src): [angles...]}。**只记录真实存在的文件**，
    不假设全覆盖——这是与几何侧对齐的关键。

    🔴 文件名分隔符实测是 `_`（如 `39_91.wav`），
    官方 README 写的是 `-`。此处复用 `parse_pair`兼容两种。
    """
    base, ok = find_rir_base(rir_root, "replica", scene)
    if not ok:
        return {}, None
    idx = defaultdict(list)
    n_files = 0
    n_bad = 0
    for ang in sorted(d for d in os.listdir(base)
                      if os.path.isdir(os.path.join(base, d)) and d.isdigit()):
        ad = os.path.join(base, ang)
        for fn in os.listdir(ad):
            if not fn.endswith(".wav"):
                continue
            n_files += 1
            pr = parse_pair(fn)
            if pr is None:
                n_bad += 1
                continue
            # 同时记下**真实文件名**，后续读取时不靠拼接猜
            idx[pr].append((int(ang), fn))
    idx = dict(idx)
    if n_bad:
        print(f"    ⚠ {n_bad}/{n_files} 个文件名无法解析"
              f"（样例: {sorted(os.listdir(ad))[:2]}）")
    return idx, base


def main():
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except Exception:      # noqa: BLE001
        pass

    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--scenes", nargs="*", default=None)
    ap.add_argument("--rir-root", default=None)
    ap.add_argument("--measure-energy", action="store_true",
                    help="同时读 BRIR 算频带能量（较慢）")
    ap.add_argument("--out", default="/mnt/d/fenzhi1/outputs/pair_labels.json")
    # G5 门禁：小样本试跑用，避免首次运行直接上全量
    ap.add_argument("--max-pairs-per-scene", type=int, default=0,
                    help="每场景最多处理多少对；0 = 不限")
    ap.add_argument("--sample-src-per-rec", type=int, default=0,
                    help="按 rec 采样：每个 rec 取几个 src；"
                         "0 = 不采样（用 --max-pairs-per-scene）")
    args = ap.parse_args()

    try:
        import yaml
        with open(args.config, "r", encoding="utf-8") as fh:
            cfg = yaml.safe_load(fh)
    except Exception as e:      # noqa: BLE001
        print(f"读取配置失败: {e}")
        sys.exit(1)

    data_root = os.path.expanduser(str(cfg["data_root"]))
    meta_dir = os.path.join(data_root, cfg.get("metadata_dir", "metadata"))
    scene_dir = os.path.expanduser(str(cfg["scene_datasets_dir"]))
    rir_root = args.rir_root or os.path.join(data_root, "binaural_rirs")

    chord_thin = cfg["chord_thin_m"]
    chord_thick = cfg["chord_thick_m"]
    min_node_dist = cfg.get("min_node_distance", 0.5)
    occluder_set = set(cfg["occluder_categories"])
    sounding = set(cfg["sounding_categories"])
    bands = [tuple(b) for b in cfg["freq_bands"]]

    scenes = args.scenes or cfg["replica_scenes"]

    print("=" * 76)
    print("导出逐对几何标签")
    print("=" * 76)
    print(f"  场景          : {len(scenes)}")
    print(f"  遮挡物类别    : {len(occluder_set)}")
    print(f"  声源类别      : {len(sounding)}")
    print(f"  chord 阈值    : 薄<{chord_thin} 中等<{chord_thick} m")
    print(f"  测能量        : {args.measure_energy}")
    print()

    out = {"config": {
        "chord_thin_m": chord_thin, "chord_thick_m": chord_thick,
        "min_node_distance": min_node_dist,
        "freq_bands": [list(b) for b in bands],
        "match_mode": "3D 最近点（与 p0_baselines_v3.py 一致）",
    }, "scenes": {}}

    for sc in scenes:
        print(f"--- {sc} ---")
        P = load_points(meta_dir, sc)
        if P is None:
            print("  ✗ 无 points.txt，跳过")
            out["scenes"][sc] = {"error": "无 points.txt"}
            continue

        try:
            nodes, _ = load_replica_objects(scene_dir, sc)
        except Exception as e:      # noqa: BLE001
            print(f"  ✗ 加载物体失败: {e}")
            out["scenes"][sc] = {"error": str(e)}
            continue
        if not nodes:
            print("  ✗ 无有效节点")
            out["scenes"][sc] = {"error": "无有效节点"}
            continue

        # 只保留声源类节点（与 P0 的 pair_mode="sounding_to_all" 对齐）
        src_nodes = [n for n in nodes if n["class_name"] in sounding]
        if not src_nodes:
            print("  ✗ 无声源类节点")
            out["scenes"][sc] = {"error": "无声源类节点"}
            continue

        rir_idx, rir_base = build_rir_index(rir_root, sc)
        if not rir_idx:
            print("  ✗ 无可解析的 BRIR 索引")
            print(f"    探测路径: {rir_base}")
            print("    → 检查路径层级，或文件名格式是否既非 `a_b.wav` "
                  "也非 `a-b.wav`")
            out["scenes"][sc] = {"error": "无可解析的 BRIR",
                                  "rir_base": rir_base}
            continue
        print(f"  BRIR 索引: {len(rir_idx)} 对，路径 {rir_base}")

        # ---- 对齐自检：rec 须能在 points.txt 的 id 中找到 ----
        pt_ids = set(P[:, 0].astype(int))
        n_rec_hit = sum(1 for k in rir_idx if k[0] in pt_ids)
        n_src_hit_pts = sum(1 for k in rir_idx if k[1] in pt_ids)
        print(f"  对齐自检: rec 命中 {n_rec_hit}/{len(rir_idx)}，"
              f"src 命中 {n_src_hit_pts}/{len(rir_idx)}"
              f"（points 共 {len(P)} 行，id {min(pt_ids)}–{max(pt_ids)}）")
        if n_rec_hit == 0 or n_src_hit_pts == 0:
            print("  ✗ 编号与 points.txt 不匹配，编号空间可能不同")
            out["scenes"][sc] = {"error": "编号与 points.txt 不匹配",
                                  "rir_base": rir_base}
            continue
        print(f"  ✓ 确认：BRIR 的 rec/src **均为导航点编号**，"
              f"非物体 id")

        # 遮挡体盒（用于统计穿过的类别）
        occ_boxes = [(n["center"], n["bbox_size"], n["class_name"])
                     for n in nodes
                     if n["class_name"] in occluder_set]

        # 采样点坐标（BRIR 的 rec/src 编号 == points.txt 第一列的 id）
        PXYZ = P[:, 1:4]
        pt_id2row = {int(r[0]): i for i, r in enumerate(P)}

        # 🔴 **BRIR 的 rec 与 src 都是导航点编号，不是物体 id**（实测确认）
        #   office_2: 104 个导航点，但 BRIR 只用 37 个节点，
        #             1369 = 37² 为完整笛卡尔积（含自配对 i,i）
        #   → 正确对齐方式：**遍历导航点对**，
        #     声源物体用「离该 src 导航点最近的声源物体」代表
        brir_nodes = sorted({k[0] for k in rir_idx} | {k[1] for k in rir_idx})
        print(f"  BRIR 涉及导航节点: {len(brir_nodes)} 个 "
              f"（共 {len(P)} 个导航点）")

        rows = []
        n_matched = 0
        n_read_fail = 0
        n_src_hit = 0          # src 导航点附近找到声源物体的对数
        rec_src_count = {}# 按 rec 采样时的计数

        # 预先算：每个 BRIR src 导航点最近的声源物体
        src_pt_to_node = {}
        for sid in brir_nodes:
            row = pt_id2row.get(sid)
            if row is None:
                continue
            S = PXYZ[row]
            best, bestd = None, 1e18
            for node in src_nodes:
                d = float(np.linalg.norm(node["center"] - S))
                if d < bestd:
                    best, bestd = node, d
            if best is not None:
                src_pt_to_node[sid] = (best, bestd)

        for (rec_id, src_id), ang_files in sorted(rir_idx.items()):
            if rec_id == src_id:          # 跳过自配对
                continue
            if src_id not in src_pt_to_node:
                continue
            # 🔴 按 rec 采样：BRIR 是完整笛卡尔积（N² 对），
            #   按字典序截断会只覆盖前 √k 个 rec（实测 400 对→11/37）。
            #   故按 rec 计数，每个 rec 只取前 K 个 src，
            #   以保证**所有 rec 都被覆盖**。
            if args.sample_src_per_rec:
                cnt = rec_src_count.get(rec_id, 0)
                if cnt >= args.sample_src_per_rec:
                    continue
                rec_src_count[rec_id] = cnt + 1
            elif args.max_pairs_per_scene and n_matched >= \
                    args.max_pairs_per_scene:
                break
            node, hop = src_pt_to_node[src_id]
            n_matched += 1
            n_src_hit += 1

            rrow = pt_id2row.get(rec_id)
            srow = pt_id2row.get(src_id)
            if rrow is None or srow is None:
                continue

            # 🔴🔴 几何路径修正（2026-10-12，见证据清单5.13）
            #
            # 原实现用「物体中心 → rec 导航点」（A 路径），
            # 但 BRIR 的真实声源在 **src 导航点**上，
            # 两者不是同一条传播路径——实测 A 路径 chord 中位
            # 0.644 m 是 B 路径 0.115 m 的 5.6 倍，
            # 导致「chord 无声学预测力」的伪结论。
            #
            # 现改为**两条都算**并同时输出：
            #   chord_B（导航点→导航点）= 与 BRIR 对应，作为主判据
            #   chord_A（物体中心→导航点）= 保留供对比
            p1 = PXYZ[rrow]          # rec 导航点
            p_src = PXYZ[srow]       # src 导航点（BRIR 真实声源）
            C_obj = node["center"]   # 物体中心

            seg_B = float(np.linalg.norm(p1 - p_src))
            seg_A = float(np.linalg.norm(p1 - C_obj))

            def _chord(pa, pb, seg):
                tot, hits = 0.0, set()
                for cen, size, cname in occ_boxes:
                    iv = segment_aabb_chord(pa, pb, cen, size)
                    if iv is None:
                        continue
                    c = (iv[1] - iv[0]) * seg
                    if c > 1e-6:
                        tot += c
                        hits.add(cname)
                return tot, hits

            total_chord, occ_hits = _chord(p_src, p1, seg_B)   # B 路径
            chord_A, occ_A = _chord(C_obj, p1, seg_A)          # A 路径（对比）
            seg_len = seg_B

            if total_chord < 1e-6:
                cls = "无遮挡"
            elif total_chord < chord_thin:
                cls = "薄"
            elif total_chord < chord_thick:
                cls = "中等"
            else:
                cls = "厚"

            # A 路径的分类（对比用）
            if chord_A< 1e-6:
                cls_A = "无遮挡"
            elif chord_A < chord_thin:
                cls_A = "薄"
            elif chord_A < chord_thick:
                cls_A = "中等"
            else:
                cls_A = "厚"

            rec = {
                "rec": rec_id, "src": src_id,
                "src_class": node["class_name"],
                "src_obj_id": int(node["id"]),
                "node_to_src_dist": round(hop, 4),
                # dist/chord/chord_class 现为 **B 路径**（与 BRIR 对应）
                "dist": round(seg_B, 4),
                "chord": round(total_chord, 4),
                "chord_class": cls,
                # A 路径（物体中心→导航点），仅供对比
                "chord_A": round(chord_A, 4),
                "chord_class_A": cls_A,
                "dist_A": round(seg_A, 4),
                "n_occ": len(occ_hits),
                "occ_classes": sorted(occ_hits),
                "angles": sorted(a for a, _fn in ang_files),
            }

            # 可选：立即读 BRIR 算频带能量
            if args.measure_energy:
                e = {}
                for ang, fn in ang_files:
                    fp = os.path.join(rir_base, str(ang), fn)
                    try:
                        wav, sr, _info = read_wav(fp)
                    except Exception:      # noqa: BLE001
                        n_read_fail += 1
                        continue
                    mono = wav.mean(axis=1)
                    for lo, hi in bands:
                        k = f"{lo}-{hi}"
                        e.setdefault(k, {})[str(ang)] = float(
                            band_energy(mono, sr, (lo, hi)))
                if e:
                    # 四角度取能量均值作为该对的代表值
                    rec["energy"] = {k: float(np.mean(list(v.values())))
                                     for k, v in e.items()}
                    rec["energy_per_angle"] = e
            rows.append(rec)

            if len(rows) % 50 == 0:
                print(f"    已处理 {len(rows)} 对…")
                sys.stdout.flush()

        # 统计
        byc = defaultdict(int)
        for r in rows:
            byc[r["chord_class"]] += 1

        print(f"  导航点对（排除自配对）: {n_matched}，导出 {len(rows)} 对")
        print(f"  src 导航点均找到最近声源物体: {n_src_hit}/{n_matched}")
        if args.measure_energy:
            n_with_e = sum(1 for r in rows if "energy" in r)
            print(f"  含能量: {n_with_e} 对"
                  + (f"（读取失败 {n_read_fail}）" if n_read_fail else ""))
        print(f"  chord 分类: {dict(byc)}")

        out["scenes"][sc] = {
            "n_src_nodes": len(src_nodes),
            "n_navigation_points": len(P),
            "n_brir_nodes": len(brir_nodes),
            "n_brir_pairs_available": len(rir_idx),
            "n_rec_hit_points": n_rec_hit,
            "n_src_hit_points": n_src_hit_pts,
            "n_matched": n_matched,
            "n_exported": len(rows),
            "chord_class_counts": dict(byc),
            "rir_base": rir_base,
            "pairs": rows,
        }
        print()

    # ---------------- 汇总 ----------------
    tot = defaultdict(int)
    npair = 0
    for sc, v in out["scenes"].items():
        for k, n in v.get("chord_class_counts", {}).items():
            tot[k] += n
        npair += v.get("n_exported", 0)

    print("=" * 76)
    print("汇总")
    print("=" * 76)
    print(f"\n  导出总对数: {npair}")
    print("  chord 分类合计:")
    for k in ("无遮挡", "薄", "中等", "厚"):
        n = tot.get(k, 0)
        fr = n / npair * 100 if npair else 0
        print(f"    {k:8s} {n:6d} ({fr:5.1f}%)")

    if tot.get("薄", 0) == 0:
        print("\n  ⚠ 无「薄」类样本——无法做薄遮挡的声学验证")
    else:
        print(f"\n  ✓ 「薄」类 {tot['薄']} 对，可用于几何×声学交叉")

    # ---------------- 分层分析（核心）----------------
    if args.measure_energy:
        print()
        print("=" * 76)
        print("分层分析：chord 类别 × 频带能量")
        print("=" * 76)

        by_class = defaultdict(lambda: defaultdict(list))
        for sc, v in out["scenes"].items():
            for r in v.get("pairs", []):
                if "energy" not in r:
                    continue
                for k, e in r["energy"].items():
                    by_class[r["chord_class"]][k].append(e)

        if not by_class:
            print("  无可用能量数据")
        else:
            band_keys = [f"{lo}-{hi}" for lo, hi in bands]
            # 以「无遮挡」为基准，看各类相对衰减
            # 🔴 修正：基准必须**按频带分别取**，不能只取一次。
            #   原实现 base 只在第一个频带赋值，后续频带一律减它，
            #   导致「相对无遮挡」列出现 −50 dB 这类荒谬值。
            base_by_band = {}
            for k in band_keys:
                if "无遮挡" in by_class and k in by_class["无遮挡"]:
                    base_by_band[k] = energy_db(
                        np.median(np.array(by_class["无遮挡"][k])))
            print()
            for cls in ("无遮挡", "薄", "中等", "厚"):
                if cls not in by_class:
                    continue
                print(f"  【{cls}】n={len(next(iter(by_class[cls].values())))}")
                for k in band_keys:
                    if k not in by_class[cls]:
                        continue
                    a = np.array(by_class[cls][k])
                    p50 = energy_db(np.median(a))
                    b = base_by_band.get(k)
                    rel = f"{p50 - b:+6.1f}" if b is not None else "   —"
                    print(f"    {k:12s} 中位 {p50:7.2f} dB   "
                          f"相对无遮挡 {rel} dB")
                print()
            print("  ⚠ 上表**未控制距离**。薄组距离中位显著大于其余组，")
            print("    故「相对无遮挡」的差值不能直接当作遮挡效应。")
            print("    请跑 stratified_analysis_v2.py（菜单 [27]）做分层对比。")
            print()

            # 关键判据：薄 vs 厚的相对差
            if "薄" in by_class and "厚" in by_class:
                print("  核心判据 —— 薄 vs 厚 的 dB 差：")
                print(f"    {'频带':<14s}{'薄':>9s}{'厚':>9s}{'差值':>9s}")
                print(f"    {'频带':<14s}{'':>9s}{'':>9s}{'厚-薄':>9s}")
                for k in band_keys:
                    if k in by_class["薄"] and k in by_class["厚"]:
                        t = energy_db(np.median(by_class["薄"][k]))
                        h = energy_db(np.median(by_class["厚"][k]))
                        print(f"    {k:<14s}{t:>9.2f}{h:>9.2f}"
                              f"{h - t:>+9.2f}")
                print()
                print("    差值 > 0 说明厚遮挡能量更低（符合物理预期）")
                print("    差值越大 → 几何 chord 对声学可达性的预测力越强")

        out["stratified"] = {
            cls: {k: {"n": len(v), "median_db": float(
                energy_db(np.median(v)))}
                for k, v in km.items()}
            for cls, km in by_class.items()
        }

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False)
    print(f"\n结果已保存: {args.out}")


if __name__ == "__main__":
    main()