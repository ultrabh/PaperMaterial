# Open Optimisation Items and the Criterion Form

> **Purpose:** record the **known directions for improvement** together with
> their **preconditions**, so that failed paths are not explored twice and
> untried paths are not forgotten.
>
> **Created:** 2026-10-19 (the day the criterion was revised)
> **Maintenance rule:** on completing an item, update its status; on finding a
> new direction, append an entry.

---

## 📌 Why this document exists

On the day the criterion was revised it became clear that **the number 0.755
should never have been fixed** — it drifts over **0.716 to 0.795** as
`pos_frac` changes.

This exposes a more general problem:

> **All of our numerical results rest on a set of "picked on the spot" analysis
> parameters** (pos_frac = 0.20, n_bins = 12, band = 2000–8000, min_per_bin = 40).

The criterion revision changed it from an "absolute AUC" to a "sign
consistency of the gain", which made the conclusion **independent of the
threshold** but **still dependent on these parameters**.

**Optimisation item 0 is exactly this**: measure the sensitivity of each
parameter, and decide which are substantive and which can be chosen freely.

---

## ✅ Optimisation item 0: sensitivity mapping of the analysis parameters (completed 2026-10-19)

### Conclusion: the conclusion is parameter-insensitive; C-26 can be upgraded to "a parameter-independent conclusion"

Script `param_sensitivity.py`, all five gates passed.

### Band sweep (8 scenes)

| Band | Solvable scenes | Mean gain | Smallest per-scene gain |
|---|---|---|---|
| 0–500 | 3 | +0.285 | **+0.261** |
| 500–2000 | 4 | +0.260 | +0.189 |
| **2000–8000** (current default) | 4 | +0.257 | **+0.176** |
| 8000–20000 | 4 | +0.261 | +0.191 |
| 20–22000 🔇 | 4 | +0.255 | +0.174 |

**The sign of the gain is positive in every band**, with the smallest
per-scene gain above +0.176.

### 🔴 An artefact that must be watched for

On the surface, the 0–500 Hz mean gain is higher (+0.285 against +0.257), but
this is a **selection effect**:

| Scene | 0–500 | 2000–8000 |
|---|---|---|
| apartment_0 | +0.234 (**unsolvable**, n_occ differs by only +0.15) | +0.176 (solvable, +0.38) |
| office_2 | +0.173 (**unsolvable**, +0.22) | +0.022 (unsolvable, +0.14) |

**Comparing only on the 3 scenes solvable in both bands**:

| Band | Mean gain on the commonly solvable scenes |
|---|---|
| 0–500 | +0.285 |
| 2000–8000 | +0.283 |
| **Difference** | **+0.001** |

→ **No substantive difference between the two bands.** "Lower frequencies are
better" is an illusion created by the subsets differing.

### min_per_bin sweep: identical at all four levels

| min_per_bin | Solvable scenes | Mean gain |
|---|---|---|
| 30 / 40 / 60 / 80 | 4 | +0.257 (all four identical) |

**Not a bug** — every stratum has far more than 80 samples, so the threshold
never binds. This is itself a valid conclusion: **`min_per_bin` has no effect
on the current data**.

### The upgraded C-26

Original statement: "the gain is consistently positive across 8 scenes and 20
pos_frac settings".

**New statement**:

> Across **all** combinations of 8 scenes × 5 pos_frac × 4 non-noise frequency
> bands × 4 min_per_bin levels, the sign of the gain of geometric information
> over the distance-only baseline is consistently positive.
> The conclusion **does not depend on the choice of any analysis parameter**.

(The 20–22 kHz band is excluded because it is near the noise floor and is
reported separately.)

---

## 🟠 Optimisation item 1: making the four "weak signal" scenes solvable

### Current state

After the criterion revision **the gain is positive in all 8 scenes**, but the
magnitudes differ by a factor of 10:

| Scene | Gain | n_occ difference | Verdict |
|---|---|---|---|
| hotel_0 | **+0.349** | +1.03 | solvable |
| frl_apartment_4 | +0.273 | +0.65 | solvable |
| frl_apartment_2 | +0.263 | +0.77 | solvable |
| frl_apartment_3 | +0.195 | −0.08 | weak |
| apartment_0 | +0.150 | +0.38 | solvable |
| frl_apartment_1 | +0.098 | −0.02 | weak |
| office_2 | +0.063 | +0.14 | weak |
| room_0 | **+0.031** | +0.04 | weak |

🔴 **Wording correction:** it is not that "the task is unsolvable in these
scenes", but that **the geometric signal of these scenes is drowned by other
factors**.

### Diagnosis (known)

In `frl_apartment_1` the within-stratum energy difference is **unrelated to
occlusion** (33.3% of positive samples have n_occ ≥ 3, against 39.0% of
negative samples). The real reason for the low energy has not been found —
candidates:

| Candidate | How to test |
|---|---|
| **Room modes (modal)** | Whether the frequency of a low-frequency narrow peak correlates with that receiver's room dimensions |
| **Multipath interference** | Whether the variance of the energy distribution of one receiver grows with distance |
| **Reverberation-time differences** | RT60 cannot be estimated (RIR too short), but an early-reflection ratio can be used instead |
| **Insufficient geometric description** | The occluder material labels are too coarse (semantic class ≠ acoustic quantity, see C-23) |

### What is to be done

1. **First diagnose**: in `frl_apartment_1`, find the samples that are "low
   energy despite light occlusion" and identify what they have in common.
2. If room modes are confirmed → introduce a **room modal frequency** feature
   (computable from the room dimensions in the Replica mesh: f = c / 2L).
3. If insufficient material description is confirmed → extract **true geometry**
   from the scene mesh (not semantic labels).

### Preconditions

⚠ **A diagnosis must come first.** Adding features directly is a waste — three
consecutive "adding a feature failed" results are already on record (room
attributes +0.006, material prior −0.043, rec bias −0.002).

---

## 🟡 Optimisation item 2: a fundamental improvement of the material description (priority lowered)

### 🔴 Correction of 2026-10-19: the core request is already satisfied by the existing data

I had assumed that "chord is the total length of the geometric path, includes
diffraction, so a clean through-wall thickness must be extracted".

**After reading the code this is wrong.** The comment on `segment_aabb_chord`
in `occlusion_stats.py`:

> "the interval length t_exit − t_enter multiplied by the total segment length is
> the **chord** — **the solid thickness the sound actually has to pass through
> (metres)**."

It computes the exact intersection interval of the segment with the AABB by the
**slab method**, so `chord` **is the straight-through wall thickness** and
**does not include a diffracted path**.

→ **The request "extract the thickness without diffraction" is already
implemented.**

### Remaining possible increments (require re-export)

| Item | Current state | Potential value |
|---|---|---|
| **Per-layer thickness distribution** | only the sum `chord` is stored | may add an increment (a thick wall + a thin curtain is not the same as two walls of the same total thickness) |
| Occluder volume | not stored (approximable from the AABB volume) | may distinguish solid from hollow occluders |
| True physical material parameters | only semantic labels | 🔴 Replica does **not** provide acoustic materials; only a literature prior can help |

### New priority judgement

**C-30 has confirmed that chord is the core feature** (better than n_occ, with
n_occ adding nothing). If the cross-scene AUC is to be improved further,
**the per-layer thickness distribution is the only realistic data increment**.

**But it requires re-export** (currently only the sum is stored), at a cost of
about 20 minutes per scene.

### Preconditions (changed)

- 🔴 **The scene mesh files cannot be read from the Windows side**
  (the `\\wsl$\...\mnt\d` subdirectory is refused by DrvFs; they can only be
  read from within WSL)
- so this item **must be run by the user inside WSL** (menu entry)
- workload: about 1 hour to modify the export script, plus 20 minutes of
  runtime per scene

### Recommendation

**First check the feasibility of "per-layer thickness"** (export a single scene
and test whether it adds an increment). If it does not, move on to
optimisation item 3.

---

## ✅ Optimisation item 3 diagnostic completed (2026-10-19) → see `diagnostic_report_1.md`, `cross_scene_diagnostic.md` and C-31

**Root cause identified:** not insufficient features but **scene-specificity of
the mapping coefficients θ** (within-scene 0.703 → cross-scene 0.524; the chord
coefficient spans 0.518).

**Next step recommended: the online calibration experiment** — after entering a
room the robot measures a few known sources to estimate θ. It can answer
empirically "how many calibration samples are needed" and needs no new dataset.

---

## 🟢 Optimisation item 3: cross-scene existence inference (long-term goal)

### Current state

Cross-scene regression R² 0.515 (leave-one-out) against 0.831 within a single
scene. The **cross-scene version of the existence classification has not been
done**.

### Key obstacle

"Scene-local quantities cannot transfer" has now been confirmed three times —
on materials, on room attributes and on a receiver-level bias. So the
cross-scene version will very likely require an **explicit scene-adaptive
mechanism**:

- for example, measuring a few probes of the new scene first (online
  calibration);
- or meta-learning / domain adaptation.

### This is precisely the paper's theoretical contribution

> Cross-room existence inference requires **explicit belief management**,
> because the system knows nothing about the acoustic properties of a new
> scene.

---

## 📐 Explanation of the criterion form (important)

**Old criterion**: `mean AUC over solvable scenes ≥ 0.80`
🔴 **Problem**: AUC drifts by 0.079 with `pos_frac`, so any absolute threshold
is crossed.

**New criterion** (revised 2026-10-19, all three conditions must hold):

| # | Condition | Threshold | Why it is set this way |
|---|---|---|---|
| 1 | Leakage test (**per scene**) | Leakage < 20% and distance-only AUC ≈ 0.5 | Rules out spurious signal |
| 2 | **Sign consistency of the gain** | Across all (scene × pos_frac) settings, gain > 0 in ≥ 90% of cases | **No threshold**; only the direction has to be consistent |
| 3 | Significance of the gain | Exact binomial test p < 0.01 | Rules out chance |

**Measured**: gain positive in 20/20 (100%), p = 9.54e-07 → **passes**.

🔴 **The revision is not "lowering the threshold until it passes"** — the two
grounds are independent of the result:

1. the metric must be compared against a "do nothing" baseline (distance-only
   AUC ≈ 0.49);
2. the criterion must not depend on an arbitrary parameter (pf is a
   researcher-chosen quantity).

**What still remains dependent**: the new criterion is robust to `pf`, but its
robustness to `band` and `min_per_bin` was initially unknown → addressed by
optimisation item 0.

🔴 **Citation convention (added 2026-10-19)**
The summary of an AUC **must distinguish conventions**, otherwise the numbers
are diluted:

| Convention | pf = 0.20 | Drift span |
|---|---|---|
| **Solvable 4 scenes** ✅ quote this one | **0.748** | **0.083** |
| All 8 scenes | 0.665 | 0.039 |

Mixing in the unsolvable scenes dilutes the drift from 0.083 to 0.039, which
**makes the criterion look more robust than it is**. The script already outputs
the two conventions separately: `auc_by_pf[p].solvable` is the solvable
convention and `all` is the all-scenes convention.

---

## ✅ Directions already ruled out (do not explore again)

| Direction | Measured result | Gate |
|---|---|---|
| Room acoustic attributes (D/L ratio) | **+0.006** | ineffective |
| Material coefficient prior (fixed coefficients) | **−0.043** | worse |
| Receiver-level bias term | **−0.002** | ineffective |
| Absolute AUC threshold criterion | drifts **0.083** with pf (solvable convention) | unusable |
| RT60 as a room attribute | RIR too short to estimate | unusable |
| Cross-scene material transfer | 10.9 dB apart across scenes | non-transferable |

**The common failure mode:** all of these are **scene-local quantities**. A
coefficient estimated on the training side stops working at the test scene.
Confirmed three times.

---

## 📋 Checklist for the next session

1. Read this document → see which optimisation items have changed status
2. **Optimisation item 0 can be done immediately** (pure computation, no
   download)
3. Optimisation item 1 **requires a diagnosis first**
4. If a paper section is to be written, use the single-scene audibility
   draft held in the author's working notes (⚠ its old numbers have been
   retracted and must be rewritten under the new criterion)

---

*Maintainer: the author's working notes. Status updates must be accompanied by
measured numbers and gate results.*
