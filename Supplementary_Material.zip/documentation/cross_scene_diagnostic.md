# Cross-Scene Diagnostic Report

> **Date:** 2026-10-19
> **Question:** C-30 established that the cross-scene failure is not a feature
> problem but a scene-specificity of the mapping coefficients θ. Why exactly?
>
> **This document is the source for Table 4 of the manuscript.** It records the
> per-scene in-scene and cross-scene AUC values that the manuscript tabulates,
> together with the leave-one-receiver-out comparison.

---

## 1. Conclusion first

> **The features are not the problem; the mapping coefficients θ are
> scene-specific.**

Three lines of evidence:

1. **Leave-one-receiver-out barely degrades** → features do **not** overfit;
2. **within-scene 0.703 → cross-scene 0.524**, a drop of **0.179**;
3. the **chord** coefficient learned separately per scene spans **0.518**.

**Implication:** the geometric evidence itself is valid, but the mapping from
geometry to acoustics depends on the building.

---

## 2. Diagnostic 1: overfitting is ruled out

Splitting receivers within the same scene (the test receiver never appears in
training):

| Scene | In-sample | Leave-one-out | Difference |
|---|---|---|---|
| apartment_0 | 0.730 | 0.710 | −0.020 |
| frl_apartment_1 | 0.629 | 0.604 | −0.026 |
| frl_apartment_2 | 0.750 | 0.755 | **+0.005** |
| frl_apartment_3 | 0.708 | 0.657 | −0.051 |
| frl_apartment_4 | 0.800 | 0.786 | −0.014 |
| hotel_0 | 0.867 | 0.864 | −0.003 |
| office_2 | 0.595 | 0.587 | −0.007 |
| room_0 | 0.548 | 0.535 | −0.013 |

**The average drop is only 0.017**, and frl_apartment_2 even *rises*.

→ **The features remain effective at positions never seen in training, so
cross-scene failure is not caused by overfitting.**

---

## 3. Diagnostic 2: cross-scene vs in-scene

This is the table reproduced as Table 4 of the manuscript. The *n_mat* column
counts the distinct material classes present in the scene.

| Test scene | In-scene training | Cross-scene training | **Gap** | *n_mat* |
|---|---|---|---|---|
| apartment_0 | 0.730 | 0.615 | −0.116 | 6 |
| frl_apartment_1 | 0.629 | 0.457 | −0.173 | 5 |
| frl_apartment_2 | 0.750 | 0.524 | −0.226 | 5 |
| frl_apartment_3 | 0.708 | 0.413 | −0.295 | 6 |
| frl_apartment_4 | 0.800 | 0.743 | −0.057 | 7 |
| **hotel_0** | 0.867 | **0.397** | **−0.470** | 4 |
| office_2 | 0.595 | 0.555 | −0.040 | 1 |
| room_0 | 0.548 | 0.491 | −0.057 | 2 |
| **Mean** | **0.703** | **0.524** | **−0.179** | — |

🔴 **hotel_0 degrades most (−0.470), down to 0.397 (≈ chance).**

**Why is hotel_0 the worst?** It has the **most distinctive material
composition** of the 8 scenes (rack 36.9% + panel 11.3%, neither of which
appears elsewhere). C-23 has already shown that material coefficients are
scene-specific — **hotel_0 is precisely the scene that depends most on a
material prior.**

The small drops for room_0 and office_2 (−0.057 / −0.040) are because
**they are weak to begin with** (in-scene only 0.548 / 0.595), so there is
little left to lose in the cross-scene setting.

---

## 4. Diagnostic 3: the coefficients really are scene-specific

The **chord** coefficient learned separately in each scene, with the same
feature set (distance + chord + material):

**Range [−0.099, +0.418], a span of 0.518**

Relative variation is about **2.7×** (compared with the within-scene
discriminative power of chord, which is monotonic in 3 of 4 scenes).

---

## 5. Combined diagnosis: why cross-scene transfer fails

The three lines of evidence together give a clear picture:

```
                    ┌─────────────────────────┐
                    │  Feature set (distance + │
                    │  chord + material)      │
                    └───────────┬─────────────┘
                                │ ① leave-one-out barely degrades
                                │   → no overfitting, features valid
                                ▼
                    ┌─────────────────────────┐
                    │  Coefficients θ | scene │  ← ② span 0.518
                    └───────────┬─────────────┘    ③ cross-scene drop 0.179
                                │ θ unusable across scenes
                                ▼
                    ┌─────────────────────────┐
                    │  Need to know "this      │
                    │  room's θ" = material    │
                    │  transmission + room     │
                    │  acoustics               │
                    └─────────────────────────┘
```

**This is not a feature-engineering problem; it is a mechanism that has to be
scene-adaptive.**

---

## 6. Explanations already ruled out

| Hypothesis | Test | Result |
|---|---|---|
| Feature overfitting | Leave-one-out by receiver | ❌ drops only 0.017 |
| Features insufficient (missing room attributes) | 4 attempts | ❌ room attributes +0.006, material prior −0.043, rec bias −0.002 |
| Material coefficients do not transfer | C-23 | ✅ **holds** (10.9 dB across scenes) |
| Too few scenes | Learning curve | ⚠ already saturated (5 → 18 does not improve R²) |

---

## 7. Relation to the "existence belief node"

This diagnostic **supports the original research question, and more precisely
than the earlier argument**:

> **The bottleneck of cross-scene existence inference is not "not knowing how
> many layers occlude", but "not knowing this room's occlusion-to-acoustics
> mapping coefficient θ".**
>
> And θ depends on:
> - the true transmission coefficients of the materials (Replica does **not**
>   provide them; only the materials literature can help);
> - the room's acoustic properties (RT60, modal frequencies).
>
> **This is exactly what a belief state should express**:
> not "3 layers occlude, so existence is 0.6", but "3 layers occlude, but I
> do not know the transmission coefficient of this room's walls, so existence
> lies between 0.4 and 0.8".

**In other words:** the goal is not a stronger model but **admitting
ignorance**.

---

## 8. Three possible next steps

| Direction | Content | Feasibility |
|---|---|---|
| **A. Online calibration** | On entering a room, measure a few known sources and estimate θ | 🟢 Realistically feasible (this is what an actual robot does) |
| **B. Material prior + uncertainty** | Take transmission coefficients from the materials literature and give intervals rather than point values | 🟡 Replica does not provide them, but the literature can be consulted |
| **C. Domain adaptation / meta-learning** | Adapt quickly from a few samples of the target scene | 🟡 Needs more scenes |

**A is recommended** — three reasons:

1. it matches real robot behaviour (probe first on entering a new room);
2. it directly answers "how many calibration samples are needed";
3. it is experimentally decisive: if very few samples recover performance,
   calibration is an effective mechanism; if many are needed, cross-room
   generalisation really is out of reach.

**This is a question that can be answered experimentally, without a new
dataset.** The online-calibration experiment that followed is reported
separately in `online_calibration_report.md`.

---

*Reproduction notes: the per-scene values in Section 3 are those reported as
Table 4 of the manuscript. The leave-one-receiver-out values in Section 2 are
the in-sample and leave-one-out columns for the same eight scenes; the
*leave-one-out* row of Section 3 and the per-scene *In-scene* column of
Section 3 coincide because both are computed on the same in-scene fit.*
*The `n_mat` column counts the distinct material classes recorded per scene in
the per-pair label files (`data/paired_samples/` in this package).*
