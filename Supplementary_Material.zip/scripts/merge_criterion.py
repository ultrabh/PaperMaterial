#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把新导出的 10 个场景并入判据检验，与原有 8 场景对比。

背景
----
2026-10-20 补齐了剩余 10 个 Replica 场景的 BRIR（移动硬盘 F:），
场景数从 8 提到 18。本脚本回答一个问题：

    **新增场景是否可解？可解场景数能否从 4 提升？**

「可解」的判据沿用现有诊断（见 existence_v3.py）：
按距离分位数分层，每层取能量最低 20% 为「不可闻」，
若该标签与遮挡层数 n_occ 有足够关联，则任务良定义。

做法
----
不修改 criterion_revision.py——它按 scenes字典的 key 归并场景，
多文件传入本就不会冲突。这里只负责把文件列表组织好并调用，
同时输出**新旧对比**，便于判断是否值得更新论文。

用法（WSL 内）：
    python merge_criterion.py \
        --old /mnt/d/fenzhi1/outputs/pair_labels_5scenes.json \
        --new /mnt/d/fenzhi1/outputs/pair_labels_new10.json \
        --out /mnt/d/fenzhi1/outputs/criterion_merged18.json
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
CRITERION = os.path.join(HERE, "criterion_revision.py")

# 与论文表 I 一致的八个场景（判据检验的实际输入）
PAPER_SCENES = [
    "office_2", "hotel_0", "room_0", "apartment_0",
    "frl_apartment_1", "frl_apartment_2", "frl_apartment_3",
    "frl_apartment_4",
]
# 2026-10-20 新增的十个场景
NEW_SCENES = [
    "office_1", "room_1", "office_0", "room_2", "office_3",
    "office_4", "apartment_2", "frl_apartment_0",
    "frl_apartment_5", "apartment_1",
]


def scenes_in(path):
    """读取pair 文件，返回其中包含的场景名列表。"""
    with open(path, "r", encoding="utf-8") as fh:
        raw = json.load(fh)
    return sorted(raw.get("scenes", {}).keys()), raw


def summarize(json_path, label, feature_set="chord_mat", band="2000-8000"):
    """跑 criterion_revision.py 并提取关键结论。

    ⚠ feature_set 默认必须是 chord_mat——criterion_revision.py 自身的
    默认值是 nocc_mat，而论文表 I 用的是 chord_mat（距离+chord+材质）。
    若不显式传入，重跑结果会与论文不一致。
    """
    # 结果写到临时目录而非 outputs/：
    # `xxx.json -> xxx_stdout.json` 的命名会**覆盖**历史判据结果，
    # 而那些文件是论文数字的来源，不能被临时对比污染。
    tag = os.path.basename(json_path).replace(".json", "")
    out = os.path.join(tempfile.gettempdir(), f"_crit_{tag}.json")
    cmd = [sys.executable, CRITERION,
           "--pairs", json_path, "--out", out,
           "--feature-set", feature_set, "--band", band]
    print(f"\n{'=' * 70}")
    print(f"  {label}")
    print(f"{'=' * 70}")
    print(f"  特征集: {feature_set}   频段: {band}")
    p = subprocess.run(cmd, capture_output=True, text=True)

    # 🔴 2026-10-20 修正：不能用 returncode 判断成败。
    # criterion_revision.py 在门禁未通过时 sys.exit(1)，但结果 JSON
    # **已正常写出**——那是有效结果，不是运行失败。
    # 正确判据：输出文件是否存在且可解析。
    if not os.path.isfile(out):
        print("  ❌ 判据检验未能产出结果:")
        print((p.stderr or p.stdout)[-1500:])
        return None
    try:
        with open(out, "r", encoding="utf-8") as fh:
            res = json.load(fh)
    except (OSError, ValueError) as e:
        print(f"  ❌ 结果文件无法解析: {e}")
        return None
    if p.returncode != 0:
        print(f"  （门禁未通过，退出码 {p.returncode}，但结果有效）")
    c = res.get("criteria", {})
    solv = res.get("solvable_scenes", [])
    # 注意：判据输出里没有 all_scenes 字段，场景总数由 n_solvable
    # 与 per_scene/rows 反推。我用传入的场景数报，避免读不存在的键。
    n_all = res.get("n_scenes") or res.get("n_solvable") or len(solv)
    print(f"  可解场景      : {len(solv)}  {solv}")
    print(f"  特征集        : {res.get('feature_set')}")
    print(f"  总体判定      : gate_pass={res.get('gate_pass')}"
          f"  ({res.get('verdict')})")
    print(f"  AUC 漂移(跨pf): {res.get('auc_drift_across_pf', float('nan')):.4f}")
    c1 = c.get("1_leak_and_solvable", {})
    c2 = c.get("2_gain_sign_consistency", {})
    c3 = c.get("3_gain_significance", {})
    print(f"  判据1 泄漏/良定义: ok={c1.get('ok')}"
          f"  {c1.get('n_valid')}/{c1.get('n_total')}")
    print(f"  判据2 增益符号一致: ok={c2.get('ok')}"
          f"  {c2.get('n_pos')}/{c2.get('n_total')} ({c2.get('rate')})")
    pv = c3.get("p_value")
    pv_s = f"{pv:.3e}" if isinstance(pv, (int, float)) else "N/A"
    print(f"  判据3 精确二项    : ok={c3.get('ok')}  p={pv_s}")
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--old", required=True, help="原有 pair_labels 文件")
    ap.add_argument("--new", required=True, help="新导出的 pair_labels 文件")
    ap.add_argument("--out", default=None,
                    help="合并结果的对比 JSON")
    ap.add_argument("--skip-old", action="store_true",
                    help="只跑合并后的结果，不单独跑旧基线")
    ap.add_argument("--feature-set", default="chord_mat",
                    help="特征集；必须与论文一致（论文用 chord_mat，"
                         "脚本默认是 nocc_mat）")
    ap.add_argument("--band", default="2000-8000", help="频段")
    args = ap.parse_args()

    for f in (args.old, args.new):
        if not os.path.isfile(f):
            print(f"文件不存在: {f}")
            sys.exit(1)

    print("=" * 70)
    print("  新增场景并入判据检验")
    print("=" * 70)

    old_names, _ = scenes_in(args.old)
    new_names, _ = scenes_in(args.new)
    print(f"  旧文件 {os.path.basename(args.old)}")
    print(f"    场景 {len(old_names)}: {old_names}")
    print(f"  新文件 {os.path.basename(args.new)}")
    print(f"    场景 {len(new_names)}: {new_names}")

    dup = set(old_names) & set(new_names)
    if dup:
        print(f"\n  ⚠ 两文件重叠场景: {sorted(dup)}")
        print("    criterion_revision.py 按场景名归并，重叠会被合并而非报错，")
        print("    数据量翻倍但结论不变。若非预期请检查。")

    merged = "/tmp/_pairs_merged18.json"
    with open(merged, "w", encoding="utf-8") as fh:
        scenes = {}
        for f in (args.old, args.new):
            _, raw = scenes_in(f)
            scenes.update(raw.get("scenes", {}))
        json.dump({"scenes": scenes}, fh, ensure_ascii=False)
    print(f"\n  合并后共 {len(scenes)} 个场景 -> {merged}")

    results = {}
    if not args.skip_old:
        results["old"] = summarize(args.old, f"旧基线（{len(old_names)} 场景）",
                                   args.feature_set, args.band)
    results["merged"] = summarize(
        merged, f"合并后（{len(scenes)} 场景）",
        args.feature_set, args.band)

    # ---- 对比 ----
    print(f"\n{'=' * 70}")
    print("  对比")
    print("=" * 70)
    om = results.get("old")
    mn = results.get("merged")
    if om and mn:
        o_solv = set(om.get("solvable_scenes", []))
        m_solv = set(mn.get("solvable_scenes", []))
        print(f"  可解场景数: {len(o_solv)} → {len(m_solv)}")
        if m_solv - o_solv:
            print(f"  新增可解  : {sorted(m_solv - o_solv)}")
        if o_solv - m_solv:
            print(f"  失去可解  : {sorted(o_solv - m_solv)}")
        oc = om.get("criteria", {})
        mc = mn.get("criteria", {})
        print(f"  判据2 符号一致率: "
              f"{oc.get('2_gain_sign_consistency', {}).get('rate')} → "
              f"{mc.get('2_gain_sign_consistency', {}).get('rate')}")
        op = oc.get("3_gain_significance", {}).get("p_value")
        mp = mc.get("3_gain_significance", {}).get("p_value")
        if isinstance(op, (int, float)) and isinstance(mp, (int, float)):
            print(f"  判据3 二项 p  : {op:.3e} → {mp:.3e}")
        else:
            print(f"  判据3 二项 p  : {op} → {mp}")
        oa = om.get("auc_by_pf", {})
        ma = mn.get("auc_by_pf", {})
        if oa and ma:
            # 不硬编码键名——criterion_revision.py 的键形如 '0.2'
            common = sorted(set(oa) & set(ma))
            for k in common:
                if "solvable" in oa[k] and "solvable" in ma[k]:
                    print(f"  可解场景 AUC (pf={k}): "
                          f"{oa[k]['solvable']:.4f} → {ma[k]['solvable']:.4f}"
                          f"   仅距离基准: {ma[k].get('auc_dist', float('nan')):.4f}")
    print()
    print("  判读要点：")
    print("    · 可解场景数上升 → 场景数从 8 提到 18 确有价值，")
    print("      可回应审稿人「只用 8 个场景」的质疑")
    print("    · 可解场景数不变但判据2/3 仍成立 → 结论普适性增强，")
    print("      论文可补一句「在 18 个场景上重跑，结论不变」")
    print("    · 判据3 的 p 值变大 → 样本量增加后显著性被稀释，")
    print("      属正常（同一效应在更大样本下 p 上升不意味效应减弱）")

    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump({
                "old_file": args.old, "new_file": args.new,
                "old_scenes": old_names, "new_scenes": new_names,
                "old": om, "merged": mn,
            }, fh, ensure_ascii=False, indent=2)
        print(f"\n  对比结果已写入 {args.out}")


if __name__ == "__main__":
    main()