"""
存在性推断 v3：分位数分层 + 每层等比例（matched design）
================================================================================
演进脉络
--------
| 版本 | 标签构造 | 问题 | AUC |
|---|---|---|---|
| v1 | rec 内残差（斜率硬设 −1.0） | 过度校正；泄漏检验全局合并 | 0.894 **伪信号** |
| v2 | 固定距离分层 + 每层等比例 | 分层太粗（固定边界） | 0.748（3 场景） |
| **v3** | **分位数分层 + 每层等比例** | — | 见下 |

🔴 v3 解决的两个问题
------------------
**问题 1：v2 的固定边界不适合离散距离分布**

office_2 的距离分布高度离散（90% 分位只到 3.4 m），
固定边界（0–1, 1–2, ...）导致部分区间空或样本不足
→ 只有 4/8 层有效 → 泄漏 26.9%。

**解法**：改用**分位数分箱**，遇重复边界自动合并（np.unique）。

**问题 2：泄漏检验必须按场景做**

v1 用全局合并统计泄漏，场景间的距离差掩盖了场景内的泄漏
（13.1% vs 实际 37.9%）。
→ v3 的泄漏检验**逐场景**进行。

🔴 一个必须诚实报告的发现
------------------------
细分层后泄漏归零，但 office_2 / room_0 的 AUC 仅 0.52–0.63（≈随机）。

**原因不是方法问题，而是这两个场景任务不可解**：

| 场景 | n_occ 分布 | 层内能量差异与遮挡 |
|---|---|---|
| office_2 | {0: 544, 1: 788} —— **仅 0/1 层** | 无关 |
| room_0 | {0: 1326, 1: 1192, 2: 32} | 无关 |
| hotel_0 | 含 rack 36.9%、panel 11.3% | **相关**（正样本 n_occ 1.80 vs 负 0.76） |

0 层 = 无遮挡，1 层 = 单层墙。**在同距离、同层数下，
「不可闻」与「可闻」的区分本身没有信号**——
层内能量差异来自房间模式与混响，而非遮挡。

故v3 会把这类场景**标注为「任务不可解」**并单独报告，
而不是把它们混进平均值里拉低或拉高整体数字。

sanity check
------------
1. 泄漏检验逐场景（v1 教训）
2. 「仅距离」AUC ≈ 0.5
3. 测试 rec 零重叠
4. 额外报告：层内正/负样本的 n_occ 差异（任务可解性诊断）

输出：/mnt/d/fenzhi1/outputs/existence_v3.json
"""

import argparse
import json
import math
import os
import statistics
import sys
from collections import defaultdict

import numpy as np


def db(x):
    return 10.0 * math.log10(max(float(x), 1e-300))


def auc_score(y_true, score):
    y = np.asarray(y_true)
    s = np.asarray(score, dtype=float)
    n_pos = int((y == 1).sum())
    n_neg = int((y == 0).sum())
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    order = np.argsort(s)
    ranks = np.empty(len(s), dtype=float)
    ranks[order] = np.arange(1, len(s) + 1)
    _, inv, cnt = np.unique(s, return_inverse=True, return_counts=True)
    sums = np.zeros(len(cnt))
    np.add.at(sums, inv, ranks)
    ranks = (sums / cnt)[inv]
    return float((ranks[y == 1].sum()
                  - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


EDGES = [0, 1, 2, 3, 4, 5, 7, 10, 20]


def main():
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except Exception:      # noqa: BLE001
        pass

    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", nargs="+", required=True)
    ap.add_argument("--band", default="2000-8000")
    ap.add_argument("--pos-frac", type=float, default=0.20)
    ap.add_argument("--min-per-bin", type=int, default=40)
    ap.add_argument("--n-bins", type=int, default=12,
                    help="分位���箱数")
    ap.add_argument("--n-repeats", type=int, default=5)
    ap.add_argument("--out",
                    default="/mnt/d/fenzhi1/outputs/existence_v2.json")
    args = ap.parse_args()

    data = {}
    for f in args.pairs:
        with open(f, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
        for sc, v in raw.get("scenes", {}).items():
            for p in v.get("pairs", []):
                if "energy" not in p:
                    continue
                data.setdefault(sc, []).append({
                    "rec": p["rec"], "dist": p["dist"],
                    "n_occ": p["n_occ"], "occ": p["occ_classes"],
                    "E": db(p["energy"][args.band]),
                })

    scenes = sorted(data)
    allmats = sorted({m for rs in data.values() for r in rs
                      for m in r["occ"]})
    print("=" * 74)
    print("存在性推断 v2：距离分层 + 等比例标签")
    print("=" * 74)
    print(f"  场景 {len(scenes)}，层边界 {EDGES}")
    print(f"  每层内最低 {args.pos_frac * 100:.0f}% 为「不可闻」")
    print()

    def make_labels(rs, n_bins):
        """**分位数分箱** + 每层内取能量最低 pos_frac 为正样本。"""
        d = np.array([r["dist"] for r in rs])
        E = np.array([r["E"] for r in rs])
        # 🔴 分位数分箱：遇重复边界自动合并，适配离散距离分布
        edges = np.unique(np.quantile(d, np.linspace(0, 1, n_bins + 1)))
        lab = np.full(len(rs), -1, dtype=int)
        used = 0
        for i in range(len(edges) - 1):
            lo, hi = edges[i], edges[i + 1]
            m = (d >= lo) & ((d <= hi) if i == len(edges) - 2
                             else (d < hi))
            if m.sum() < args.min_per_bin:
                continue
            k = max(5, int(m.sum() * args.pos_frac))
            idx = np.where(m)[0]
            order = idx[np.argsort(E[idx])]
            lab[order[:k]] = 1
            lab[order[k:]] = 0
            used += 1
        return [dict(r, label=int(l))
                for r, l in zip(rs, lab) if l >= 0], used

    def feat(rs):
        n = len(rs)
        X = np.zeros((n, 3 + len(allmats)))
        X[:, 0] = 20 * np.log10(np.maximum([r["dist"] for r in rs], 1e-3))
        X[:, 1] = [float(r["n_occ"]) for r in rs]
        for j, m in enumerate(allmats):
            X[:, 2 + j] = [1.0 if m in r["occ"] else 0.0 for r in rs]
        X[:, 2 + len(allmats)] = 1.0
        return X

    # ---------- 1. 泄漏检验（按场景，v1 教训）----------
    print("-" * 74)
    print("1. 泄漏检验（**按场景**，不得全局合并）")
    print("-" * 74)
    lab_by_scene = {}
    diag = {}
    print(f"\n  {'场景':<20s}{'层数':>5s}{'n':>7s}{'正样本率':>9s}"
          f"{'泄漏%':>8s}{'仅距离AUC':>11s}")
    print("  " + "-" * 62)
    for sc in scenes:
        rs, used = make_labels(data[sc], args.n_bins)
        if len(rs) < 300:
            print(f"  {sc:<20s}{used:>5d}{len(rs):>7d}  样本不足")
            continue
        lab_by_scene[sc] = rs
        y = np.array([r["label"] for r in rs])
        d = np.array([r["dist"] for r in rs])
        dp = float(np.median(d[y == 1]))
        dn = float(np.median(d[y == 0]))
        leak = abs(dp - dn) / dn * 100
        a = auc_score(y, -d)
        ok = leak < 20.0 and abs(a - 0.5) < 0.15
        # 🔴 任务可解性诊断：层内正/负样本的 n_occ 差异
        pos_no = float(np.mean([r["n_occ"] for r in rs if r["label"] == 1]))
        neg_no = float(np.mean([r["n_occ"] for r in rs if r["label"] == 0]))
        no_gap = pos_no - neg_no
        diag[sc] = {"n_bins": used, "n": len(rs),
                    "pos_rate": float(y.mean()),
                    "leak_pct": leak, "auc_dist_only": a,
                    "pos_no": pos_no, "neg_no": neg_no,
                    "no_gap": no_gap, "pass": bool(ok)}
        print(f"  {sc:<20s}{used:>5d}{len(rs):>7d}{y.mean() * 100:>8.1f}%"
              f"{leak:>8.1f}{a:>11.3f}  n_occ差{no_gap:+5.2f}"
              f"  {'PASS' if ok else 'FAIL'}")

    ok_scenes = [k for k, v in diag.items() if v["pass"]]
    print(f"\n  通过场景：{len(ok_scenes)}/{len(diag)}  {ok_scenes}")
    print("  ⚠ 未通过的场景将被排除，不参与后续性能评估")

    if len(ok_scenes) < 3:
        print("\n  🔴 通过场景不足 3 个，门禁失败")
        sys.exit(1)

    # ---------- 2. 分类性能 ----------
    print()
    print("-" * 74)
    print("2. 分类性能（仅在通过泄漏检验的场景上评估）")
    print("-" * 74)
    print(f"\n  {'场景':<20s}{'n':>7s}{'AUC':>9s}{'标准差':>9s}")
    print("  " + "-" * 48)
    per = {}
    for sc in ok_scenes:
        rs = lab_by_scene[sc]
        recs = sorted({r["rec"] for r in rs})
        al = []
        for rep in range(args.n_repeats):
            rng = np.random.RandomState(3000 + rep)
            perm = rng.permutation(len(recs))
            trec = {recs[i] for i in perm[:len(recs) // 2]}
            tr = [r for r in rs if r["rec"] in trec]
            te = [r for r in rs if r["rec"] not in trec]
            if {r["rec"] for r in tr} & {r["rec"] for r in te}:
                continue
            if not tr or not te:
                continue
            Xtr, Xte = feat(tr), feat(te)
            c, *_ = np.linalg.lstsq(Xtr,
                                    np.array([r["label"] for r in tr]),
                                    rcond=None)
            al.append(auc_score([r["label"] for r in te], Xte @ c))
        if not al:
            continue
        a = statistics.mean(al)
        per[sc] = {"n": len(rs), "auc": a, "auc_std": float(np.std(al))}
        flag = " ★" if a >= 0.80 else ""
        print(f"  {sc:<20s}{len(rs):>7d}{a:>9.3f}"
              f"{np.std(al):>9.3f}{flag}")

    aucs = [v["auc"] for v in per.values()]
    print()
    print("=" * 74)
    print("汇总")
    print("=" * 74)

    # 🔴 区分「可解」与「不可解」场景
    solvable = {k: v for k, v in per.items() if diag[k]["no_gap"] > 0.3}
    unsolvable = {k: v for k, v in per.items() if diag[k]["no_gap"] <= 0.3}
    print("\n  【任务可解性诊断】层内正/负样本的遮挡层数差异：")
    for k in sorted(per):
        g = "✅ 可解" if k in solvable else "⚠ 不可解（层内能量差与遮挡无关）"
        print(f"     {k:<20s} n_occ 差 {diag[k]['no_gap']:+.2f}  {g}")
    if solvable:
        m_s = statistics.mean([v["auc"] for v in solvable.values()])
        print(f"\n  可解场景（{len(solvable)} 个）平均 AUC = **{m_s:.3f}**")
    if unsolvable:
        m_u = statistics.mean([v["auc"] for v in unsolvable.values()])
        print(f"  不可解场景（{len(unsolvable)} 个）平均 AUC = {m_u:.3f}")
    m = statistics.mean(aucs)
    print(f"\n  平均 AUC = {m:.3f}（{len(aucs)} 个通过场景）")
    print(f"\n  预写判据：AUC ≥ 0.80")
    if m >= 0.80:
        print(f"  ✓ **{m:.3f} ≥ 0.80**")
        verdict = "可行"
    elif m >= 0.70:
        print(f"  △ {m:.3f}（0.70–0.80）")
        verdict = "有信号"
    else:
        print(f"  ✗ {m:.3f} < 0.70")
        verdict = "不足"

    print()
    print("  ✅ sanity checks")
    print(f"     泄漏检验按场景做:      PASS")
    print(f"     通过场景 ≥ 3:         {'PASS' if len(ok_scenes) >= 3 else 'FAIL'} ({len(ok_scenes)})")
    print(f"     测试 rec 零重叠:      PASS")

    out = {"band": args.band, "pos_frac": args.pos_frac,
           "edges": EDGES, "scenes": scenes,
           "leak_diag": diag, "ok_scenes": ok_scenes,
           "per_scene": per, "auc_mean": m,
           "solvable": sorted(solvable), "unsolvable": sorted(unsolvable),
           "auc_mean_solvable": (statistics.mean(
               [v["auc"] for v in solvable.values()])
               if solvable else None),
           "verdict": verdict}
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print(f"\n结果已保存: {args.out}")
    print("\n⚠ 本结果建立在【仅通过泄漏检验的场景】上，"
          "不能与 v1 的 AUC 0.894 混用")


if __name__ == "__main__":
    main()
