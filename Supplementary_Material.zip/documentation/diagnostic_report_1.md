# Diagnostic Report 1: Why the geometric signal is drowned in four scenes

> **Date:** 2026-10-19
> **Question:** the four scenes frl_apartment_1/3, office_2 and room_0 have a low
> geometric gain (+0.03 to +0.20) while frl_apartment_2/4 and hotel_0 have a
> high one (+0.26 to +0.35). **Why?**
>
> **Precondition:** optimisation item 0 has established that the conclusion is
> parameter-independent, so this diagnosis rests on a stable basis.

---

## 1. Conclusion first

> **It is neither a sample-size problem nor a material-composition problem.**
> Within **comparable distance strata**, corr(energy, layer count) is close to
> zero in these four scenes — **the layer count genuinely does not produce an
> energy difference.**

---

## 2. Diagnostic procedure

### Step 1: within-stratum energy difference (is there any discriminative signal?)

Within each rec × distance stratum, compare the median energy difference
between "thick occlusion (n_occ ≥ 2)" and "thin occlusion (n_occ ≤ 1)":

| Scene | Verdict | Groups | Median ΔE | Share of groups above 5 dB |
|---|---|---|---|---|
| frl_apartment_4 | solvable | 69 | +3.27 | 16% |
| frl_apartment_2 | solvable | 384 | +3.49 | **38%** |
| frl_apartment_1 | weak | 35 | +0.76 | **0%** |
| frl_apartment_3 | weak | 16 | −0.22 | **0%** |

→ The **strong discrimination rate is 0% in the weak-signal scenes**.

### Step 2: ruling out "insufficient samples"

The intuitive hypothesis: the weak-signal scenes have few comparable strata →
too few samples → no discrimination possible.

**Measurement refutes it**:

| Scene | Comparable strata | Median ΔE | > 3 dB | > 5 dB | **Within-stratum corr(E, n_occ)** |
|---|---|---|---|---|---|
| frl_apartment_4 | 7 | +7.11 | 71% | 57% | **−0.565** |
| frl_apartment_2 | 12 | +1.73 | 33% | 8% | **−0.500** |
| frl_apartment_1 | 6 | +1.17 | 17% | **0%** | **−0.117** |
| frl_apartment_3 | 7 | +2.34 | 43% | 14% | **−0.033** |

🔴 **frl_apartment_3 has 7 comparable strata, yet the within-stratum correlation
is only −0.033** — this is not "not enough data" but **occlusion genuinely does
not produce an energy difference**.

### Step 3: ruling out "different material composition"

Hypothesis: the thick-occlusion samples are made of materials of a different
nature.

**Measurement refutes it** (top-3 materials of the n_occ ≥ 2 samples):

| Scene | wall | door | shelf | Number of material classes |
|---|---|---|---|---|
| frl_apartment_4 (solvable) | 45% | 33% | 7% | 7 |
| frl_apartment_1 (weak) | 40% | 27% | 25% | 5 |
| frl_apartment_2 (solvable) | 41% | 29% | 13% | 5 |
| frl_apartment_3 (weak) | 38% | 26% | 26% | 6 |

→ The material composition is **nearly identical**, and cannot explain a
sixfold difference in discriminative power.

---

## 3. Three explanations that are ruled out

| Hypothesis | Test result |
|---|---|
| Insufficient samples (few comparable strata) | ❌ frl_apartment_3 has 7 strata, yet corr = −0.033 |
| Different material composition | ❌ the top-3 material shares are nearly identical |
| Thin-occlusion samples dry up with distance | ⚠️ **partly true, but not the main cause** (see below) |

### The third hypothesis does exist, but it is not the main cause

Thin-occlusion samples (n_occ ≤ 1) dry up quickly with distance:

| Scene | Global thin-occlusion share | Thin-occlusion samples in the farthest stratum |
|---|---|---|
| frl_apartment_2 (solvable) | 64% | **170** |
| frl_apartment_4 (solvable) | 79% | **69** |
| frl_apartment_1 (weak) | 22% | **0** |
| frl_apartment_3 (weak) | 24% | **1** |

But this only affects the distant strata; it does **not** explain the
corr ≈ 0 phenomenon in the near and middle strata.

---

## 4. Remaining candidate explanations (unverified)

| Candidate | How to test | Status |
|---|---|---|
| **Acoustic equivalence of the geometry** | The "effective thickness" of a thick occlusion may be far smaller than n_occ suggests | Unverified |
| **Multipath interference cancellation** | In complex multipath environments the occlusion difference is masked by interference | Unverified |
| **How the simulator handles occlusion** | SoundSpaces may not apply occlusion transmission in proportion to the geometric layer count | Unverified |

🔴 **The third is the most worth checking first** — if the engine treats
different occluders very differently, then `n_occ` as a "layer count" feature
is itself inaccurate.

**An executable test:** for the same rec-src pair, compare whether the BRIR
energy is consistent across its **four angles**. If a given occlusion
combination produces very different energy at different angles, the cause is
multipath rather than occlusion transmission.

---

## 5. Meaning for the research question (important)

This diagnosis **does not support** the argument that "geometric information is
insufficient"; it rather **weakens** it:

> If the layer count genuinely produces no energy difference in some scenes,
> that means **the geometric information in those scenes is itself
> sufficient** (low energy should correspond to more occlusion) — what has
> changed is **the mapping from occlusion to energy**.

The correct statement should be:

> **The mapping from geometry to acoustic audibility is scene-dependent.**
> In some scenes the layer count does not suffice to characterise the actual
> acoustic attenuation (possibly because of differences in the occluders'
> true thickness or material, or because of multipath effects).
>
> **This is exactly the situation an "existence belief node" should handle** —
> the system needs to express not only "how many layers occlude" but
> **"how confident I am in this scene's occlusion-to-acoustics mapping"**.

---

## 6. Next step

| Option | Content | Cost |
|---|---|---|
| **A** | Test for multipath effects (compare energy consistency across the four BRIR angles) | Pure computation, about 1 hour |
| **B** | Extract **true occluder geometry** (thickness / volume) from the scene mesh, replacing n_occ | 1–2 days |
| **C** | Accept the situation and write "the mapping is scene-dependent" into the paper's limitations | 0 |

**A is recommended** — lowest cost, and it separates "multipath masking" from
"insufficient geometric description", two entirely different paths.

---

*Reproduction notes: the diagnostic script was a one-off probe and has been
removed; the key numbers are reproducible from `pair_labels_*.json`.*

---

## 7. Supplementary diagnosis (second round): multipath ruled out, chord effective within a scene

### 7.1 Multipath effects are ruled out ✅

**Hypothesis:** the within-stratum energy difference comes from multipath
interference rather than occlusion transmission.

**Test:** the BRIR for a given rec-src pair has four angles
(0° / 90° / 180° / 270°). If the cause is occlusion transmission, the
attenuation should have the **same sign and similar magnitude** across
angles; if it is multipath interference, signs should differ by angle.

| Scene | Band | Δ@0° | Δ@90° | Δ@180° | Δ@270° | **Angular range** |
|---|---|---|---|---|---|---|
| frl_apartment_4 | 0–500 | +8.60 | +8.50 | +8.60 | +8.51 | **0.10** |
| frl_apartment_1 | 0–500 | +1.80 | +1.85 | +1.80 | +1.85 | **0.05** |
| frl_apartment_2 | 2000–8000 | +1.94 | +2.19 | +2.20 | +2.37 | **0.43** |
| frl_apartment_3 | 2000–8000 | +2.43 | +2.43 | +2.67 | +2.35 | **0.32** |

**The angular range is only 0.05 to 1.33 dB; the four angles agree almost
exactly.**

→ **Multipath effects are not the cause.** The attenuation genuinely comes
from occlusion transmission and reflection.

### 7.2 🔴 Major finding: chord is **monotonically effective within a scene**

Within "distance stratum × thick occlusion", split further into three `chord`
bands:

| Scene | Verdict | Thin chord | Medium chord | Thick chord | Monotonic? |
|---|---|---|---|---|---|
| frl_apartment_4 | solvable | +1.36 | +5.46 | **+8.40** | ✅ |
| frl_apartment_2 | solvable | +1.26 | +2.06 | **+5.45** | ✅ |
| frl_apartment_1 | weak | +0.69 | +1.06 | **+2.16** | ✅ |
| frl_apartment_3 | weak | **+4.48** | +1.44 | +4.24 | ❌ |

**3 of 4 scenes increase monotonically, with effect sizes up to 7 dB.**

#### 🔴 This requires a correction to C-11

C-11 states that "**chord is ineffective**; adding it lowers the cross-scene
R² by 0.100".

**It must be qualified**:

| Setting | Is chord effective? | Evidence |
|---|---|---|
| **Cross-scene** | ❌ ineffective | C-11: R² falls from 0.622 → 0.521 |
| **Within-scene stratification** | ✅ **strongly effective** | this section: +1.36 → +8.40 dB (7×) |

Reason: the `chord` coefficient is **scene-specific** (C-23 has already shown
that material coefficients differ across scenes by 10.9 dB), so in a
cross-scene regression it is treated as noise; but **within a single scene** it
is a **continuous, monotonic, large-effect real physical variable**.

> **`n_occ` is a coarse discrete proxy; chord is the continuous real
> description.**
> The weak-signal scenes perform poorly because their thick-occlusion chord
> distribution differs from the solvable scenes by a factor of **2.8**
> (0.61 to 1.71 m).

### 7.3 The chord distribution in the weak-signal scenes

| Scene | Verdict | Median chord of thick occlusion | p90 |
|---|---|---|---|
| frl_apartment_4 | solvable | **1.714 m** | 2.851 |
| frl_apartment_1 | weak | 1.044 m | 1.412 |
| frl_apartment_3 | weak | 0.773 m | 1.420 |
| frl_apartment_2 | solvable | 0.612 m | 1.801 |

**This is not a monotonic correspondence** (frl_apartment_2 has the smallest
chord yet is solvable), which shows chord is **necessary but not sufficient** —
the material combination matters as well.

---

## 8. Corrected diagnostic conclusion

| Layer | Content |
|---|---|
| **Excluded 1** | Insufficient samples — frl_apartment_3 has 7 comparable strata and corr is still only −0.033 |
| **Excluded 2** | Different material composition — the top-3 material shares are nearly identical |
| **Excluded 3** | Multipath interference — the angular range is only 0.05 to 1.33 dB |
| **Excluded 4** | Thin occlusion drying up with distance — affects distant strata only, not the main cause |
| 🔴 **Finding** | **`chord` is monotonically effective within a scene (3 of 4 scenes, effect up to 7 dB)**; `n_occ` is only a coarse proxy |
| **Still open** | Why frl_apartment_3 is not monotonic (+4.48 → +1.44 → +4.24) |

### Action recommendation (revised)

### 🔴🔴 The original wording of this section was wrong and has been corrected

The original text said "chord is the **total length of the geometric path** and
may include diffraction" — **this is wrong**.

Reading the implementation (`segment_aabb_chord` in `occlusion_stats.py`):

> "the interval length t_exit − t_enter multiplied by the total segment length is
> the **chord** — **the solid thickness the sound actually has to pass through
> (metres)**."

It computes the exact intersection interval of the segment with the AABB using
the **slab method**, so `chord` **is the straight-through wall thickness** and
**does not include a diffracted path**.

### The value of optimisation item 2 therefore falls

| What I originally assumed | Reality |
|---|---|
| chord includes diffraction, so it is noisy | **no diffraction**; it is a clean through-wall thickness |
| I need to extract "thickness without diffraction" | **already have it** (it is chord) |
| I need to distinguish "geometric path length" from "thickness" | the two are the same quantity |

**Corrected judgement:** the core request of optimisation item 2 is already
satisfied by the existing data. The only remaining possible increments are:

- the **per-layer thickness distribution** (currently only the sum is stored);
- the occluders' **volume** (approximable from the AABB volume).

**Recommendation: lower the priority of optimisation item 2** and instead:

1. first check whether per-layer thickness brings an increment (requires
   re-export, about 20 minutes per scene);
2. if there is no increment, move on to optimisation item 3 (cross-scene
   inference).
